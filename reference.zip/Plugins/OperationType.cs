﻿namespace PluginProfiler
{
	/// <summary>
	/// Type of operation represented by the Profile
	/// </summary>
	public enum OperationType
	{
		/// <summary>
		/// Unknown Operation Type
		/// </summary>
		Unknown = 0,

		/// <summary>
		/// Plug-in
		/// </summary>
		Plugin = ProfilerSharedUtility.BaseOptionSetValue + 0,

		/// <summary>
		/// Workflow Activity
		/// </summary>
		WorkflowActivity = ProfilerSharedUtility.BaseOptionSetValue + 1
	}
}
