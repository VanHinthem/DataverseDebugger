﻿using System;
using System.Collections.Generic;

using Microsoft.Xrm.Sdk;

using PluginProfiler.Plugins;
using PluginProfiler.Library.Reporting;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Configuration for replaying a profiler session
	/// </summary>
	[Serializable]
	public sealed class ProfilerReplayExecutionConfiguration : ProfilerExecutionConfiguration
	{
		private readonly ITracingService Tracing;

		/// <summary>
		/// Instantiates an instance of the ProfilerReplayExecutionConfiguration class
		/// </summary>
		/// <param name="operation">Configuration for the operation</param>
		/// <param name="reporting">Reporting configuration for the profiler</param>
		/// <param name="tracing">Tracing service that should be used</param>
		public ProfilerReplayExecutionConfiguration(OperationConfiguration operation, ProfilerReportingConfiguration reporting,
			ITracingService tracing)
			: base(operation, reporting)
		{
			this.Tracing = tracing ?? new ProfilerConsoleTracingService();
		}

		internal override PluginServicesConfiguration GetServices(AppDomainProxy proxy, ProfilerExecutionConfiguration configuration,
			ProfilerExecutionReport executionReport, Guid currentUserId)
		{
			if (null == proxy)
			{
				throw new ArgumentNullException("proxy");
			}

			ProfilerPluginReport report = proxy.PluginReport;
			if (report.IsContextReplay)
			{
				throw new NotSupportedException("Replay is not supported for context replay.");
			}

			//Populate the properties from the report
			Queue<ProfilerReplayEvent> events = new Queue<ProfilerReplayEvent>(report.ReplayEvents);

			//Create the plug-in execution context
			return new PluginServicesConfiguration(this.Tracing,
				new ProfilerReplayOrganizationServiceFactory(executionReport, proxy.ProxyTypesAssembly, events),
				report.HasServiceEndpointNotificationService ? new ProfilerReplayServiceEndpointNotification(events) : null);
		}
	}
}