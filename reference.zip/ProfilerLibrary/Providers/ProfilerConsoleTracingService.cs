﻿using System;
using System.Globalization;

using Microsoft.Xrm.Sdk;

using PluginProfiler.Library.Reporting;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Implementation of the ITracingService that outputs to the console.
	/// </summary>
	[Serializable]
	public sealed class ProfilerConsoleTracingService : ITracingService, IProfilerTracingService
	{
		void ITracingService.Trace(string format, params object[] args)
		{
			string line;
			if (null == args || 0 == args.Length)
			{
				line = format;
			}
			else
			{
				line = string.Format(CultureInfo.InvariantCulture, format, args);
			}

			this.OutputLine("Plug-in", line);
		}

		void IProfilerTracingService.Trace(string format, params object[] args)
		{
			string line;
			if (null == args || 0 == args.Length)
			{
				line = format;
			}
			else
			{
				line = string.Format(CultureInfo.InvariantCulture, format, args);
			}

			this.OutputLine("Profiler", line);
		}

		#region Private Methods
		private void OutputLine(string type, string line)
		{
			Console.WriteLine("{0}> {1}", type, line);
		}
		#endregion
	}
}
