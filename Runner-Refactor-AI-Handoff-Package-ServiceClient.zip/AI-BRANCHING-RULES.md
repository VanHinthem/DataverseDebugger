# AI Branching Rules (Authoritative)

These rules define how AI agents must work with the Git repository during the
DataverseDebugger Runner refactor.

This document is **authoritative** for branching and PR workflow.

---

## Branching Model

### Long-lived branches
- `main`
  - Stable, production-ready code only
  - No AI PRs are allowed to target `main`
- `develop`
  - Integration branch for the refactor
  - All AI-generated PRs must target `develop`

---

## AI PR Rules (Non-Negotiable)

The AI **must**:

1. Create feature branches **from `develop`**
2. Open pull requests **targeting `develop`**
3. Execute PRs **strictly in the order defined in `PR-INDEX.md`**
4. Open **one PR at a time**
5. Wait for the current PR to be merged before starting the next
6. Ensure all acceptance criteria in the PR document are met before requesting merge

The AI **must NOT**:

- Push directly to `develop` or `main`
- Open PRs against `main`
- Combine multiple PR steps into a single PR
- Skip PRs or reorder them
- Continue work after a PR fails acceptance criteria
- Push to remote

---

## PR Naming Convention (Required)

Each PR must follow this naming pattern:

```
PR01-scaffolding-executionmode
PR02-extract-plugin-invocation-engine
PR03-executionmode-resolution-online-guard
PR04-offline-mvp
PR05-hybrid-correctness
PR06-regression-and-docs
```

This ensures traceability between:
- PR documents
- Git history
- Architectural intent

---

## Merge Policy

- Use **Squash Merge** for all AI-generated PRs
- The squash commit message should summarize:
  - what was changed
  - which PR document was executed
- Do not rebase `develop` between PRs

---

## Final Integration

After PR06 is merged into `develop`:

- A **human-reviewed PR** may be opened from `develop` → `main`
- No AI agent should merge into `main`

---

## Priority Rule

If there is any conflict between:
- this document
- PR-INDEX.md
- PR01–PR06 documents
- other instructions

👉 **This document and PR-INDEX.md take precedence.**

---

_End of document_
