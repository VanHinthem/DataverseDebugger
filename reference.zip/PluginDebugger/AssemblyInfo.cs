﻿using System;
using System.Diagnostics.CodeAnalysis;

//Namespace FxCop suppressions
[module: SuppressMessage("Microsoft.MSInternal", "CA904:DeclareTypesInMicrosoftOrSystemNamespace",
	Scope = "namespace", Target = "PluginProfiler.Debugger", Justification = "Namespace follows the same standard as the PluginRegistrationTool.")]