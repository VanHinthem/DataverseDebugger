# PR 2 — Extract Unified PluginInvocationEngine (Behavior-Preserving)

**Repo:** DataverseDebugger

## Global Non-Negotiables
1. No new external project references; reference ZIPs are conceptual only.
2. Do not refactor WebAPI entry wiring; only add a thin delegation seam when instructed.
3. Single-plugin execution only; no pipeline re-entry simulation.
4. Sender-controlled `ExecutionMode` is authoritative when provided; legacy fallback remains when absent.
5. Keep all changes inside existing `DataverseDebugger.Runner` project (no new projects).
6. Keep diffs minimal and reviewable; avoid opportunistic refactors.
7. Add deterministic errors for guards/NotSupported (include mode + operation + guidance).

## AI Implementation Rules
- Preserve current behavior unless this PR explicitly changes it.
- Maintain backward compatibility for request/response serialization.
- Add tests as specified; do not skip tests.



## Objective
Extract the existing plugin invocation logic out of `RunnerPipeServer.HandleExecutePlugin(...)` into `Pipeline/PluginInvocationEngine` **without changing behavior**.

## Scope
- Move code, do not redesign.
- Keep existing assembly loading, shadow-copy behavior, constructor selection (including string config constructors), tracing, and response shaping identical.

## Deliverables
### A) Engine return contract (locked)
- **PluginInvocationEngine must return the same response DTO currently produced by RunnerPipeServer** (behavior-preserving extraction).
- Do not switch to `ExecutionResult` in this PR. `ExecutionResult` remains scaffolding only.

### B) Preserve constructor selection (locked)
- Preserve existing plugin constructor selection behavior, including:
  - parameterless constructor
  - `(string unsecure)`
  - `(string unsecure, string secure)`
- Preserve existing configuration string values passed from the request.

### C) Implement PluginInvocationEngine
- `PluginInvocationEngine.Invoke(...)` should accept the data needed to execute a single plugin and return `ExecutionResult` (or current response DTO if easier, but the engine must exist).
- `RunnerPipeServer.HandleExecutePlugin(...)` becomes a thin delegator to the engine.

### B) No mode changes yet
- Ignore `ExecutionMode` in this PR.
- Preserve current behavior for FakeWrites/LiveWrites as-is.

### C) Tests
- Add a regression/integration test that executes an existing “known good” plugin path (or a minimal test plugin) and asserts:
  - plugin executes successfully
  - traces are captured
  - output parameters match expected values

(If you already have tests, extend them. If none exist, add one minimal integration test.)

### Acceptance criteria
- Behavior matches pre-PR2 for representative requests (output + trace)
- RunnerPipeServer diff is primarily “delegate to engine” (response shape unchanged)
- No new functional changes besides extraction

## AI Prompt (copy/paste)
> Implement PR2 by extracting the core execution logic from RunnerPipeServer.HandleExecutePlugin into Pipeline/PluginInvocationEngine. Preserve behavior exactly (assembly resolution, constructor selection, tracing, response). RunnerPipeServer should delegate to the engine. Do not implement ExecutionMode selection yet. Add/extend a regression test to prove output and traces remain unchanged.

