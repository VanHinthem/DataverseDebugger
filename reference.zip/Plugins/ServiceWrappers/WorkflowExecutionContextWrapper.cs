﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace PluginProfiler.Plugins.ServiceWrappers
{
	/// <summary>
	/// Wrapper for the IPluginExecutionContext provided by the IOrganizationServiceFactory during execution of a plug-in.
	/// </summary>
	/// <remarks>
	/// This class can be serialized into a string using the ToString() method and deserialized using the Deserialize method.
	/// </remarks>
	[DataContract(Name = "WorkflowExecutionContext", Namespace = "")]
	public sealed class WorkflowExecutionContextWrapper : ExecutionContextWrapper, IWorkflowContext
	{
		/// <summary>
		/// Instantiates an instance of the PluginExecutionContextWrapper.
		/// </summary>
		/// <remarks>
		/// This constructor is called by the static Deserialize method.
		/// </remarks>
		private WorkflowExecutionContextWrapper()
			: base()
		{
		}

		/// <summary>
		/// Instantiates an instance of the PluginExecutionContextWrapper for the given context.
		/// </summary>
		/// <param name="context">IPluginExecutionContext instance that should be wrapped.</param>
		public WorkflowExecutionContextWrapper(IWorkflowContext context)
			: base(context)
		{
			this.PopulateMethods<IWorkflowContext>();
		}

		#region IWorkflowContext Members
		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Setter is called via reflection when the properties are set.")]
		public IWorkflowContext ParentContext { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Setter is called via reflection when the properties are set.")]
		public string StageName { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Setter is called via reflection when the properties are set.")]
		public int WorkflowCategory { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Setter is called via reflection when the properties are set.")]
		public int WorkflowMode { get; private set; }
		#endregion

		#region ExecuteContextWrapper Members
		internal override OperationType OperationType
		{
			get
			{
				return OperationType.WorkflowActivity;
			}
		}

		protected override string SerializeContext()
		{
			return PartialTrustSerializer.Serialize<IWorkflowContext>(this);
		}
		#endregion

		#region Internal Methods
		internal override IExecutionContext InstantiateContextWrapper(IExecutionContext context)
		{
			return new WorkflowExecutionContextWrapper(context as IWorkflowContext);
		}

		protected override void SetContextProperty(System.Reflection.PropertyInfo property, object value)
		{
			property.SetValue(this, value, null);
		}
		#endregion
	}
}
