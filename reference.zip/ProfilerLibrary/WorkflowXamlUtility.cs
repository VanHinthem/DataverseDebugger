﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Xml;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

using PluginProfiler.Plugins;

using CrmSdk;
using System.Text.RegularExpressions;
using System.Text;

namespace PluginProfiler.Library
{
	internal static class WorkflowXamlUtility
	{
		private const string AssemblyQualifiedNameAttribute = "AssemblyQualifiedName";
		private const string DisplayNameAttribute = "DisplayName";
		private const string NameAttribute = "Name";

		/// <summary>
		/// Retrieve the Workflow Activity Steps in the given XAML
		/// </summary>
		/// <param name="service">Service to be used to retrieve the Ids</param>
		/// <param name="xaml">XAML to be instrumented</param>
		/// <returns>List of steps</returns>
		public static Dictionary<string, CustomActivityStep> GetWorkflowActivitySteps(IOrganizationService service, string xaml)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}
			else if (string.IsNullOrWhiteSpace(xaml))
			{
				throw new ArgumentNullException("xaml");
			}

			// Load the Workflow XAML
			XmlDocument workflow = LoadXaml(xaml);

			// Get the Namespace Manager for parsing the code
			XmlNamespaceManager ns = CreateXamlNamespaces(workflow.NameTable);

			// Retrieve the existing fully qualified names on the steps
			Dictionary<string, Tuple<FullyQualifiedTypeName, XmlNode>> parsedSteps = GetCustomActivityFullyQualifiedNames(service, workflow, ns);

			// Loop through each qualified name and convert it to a step
			Dictionary<string, CustomActivityStep> steps = new Dictionary<string, CustomActivityStep>();
			foreach (KeyValuePair<string, Tuple<FullyQualifiedTypeName, XmlNode>> step in parsedSteps)
			{
				FullyQualifiedTypeName type = step.Value.Item1;
				steps.Add(step.Key, new CustomActivityStep(step.Key, type.PluginAssemblyId, type.PluginTypeId, type.TypeName));
			}

			return steps;
		}

		/// <summary>
		/// Retrieve the Workflow Activity Steps in the given XAML
		/// </summary>
		/// <param name="service">Service to be used to retrieve the Ids</param>
		/// <param name="xaml">XAML to be instrumented</param>
		/// <param name="steps">Steps to be instrumented</param>
		/// <returns>List of steps</returns>
		public static string InstrumentXaml(IOrganizationService service, string xaml,
			IList<InstrumentedStepConfiguration> steps)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}
			else if (string.IsNullOrWhiteSpace(xaml))
			{
				throw new ArgumentNullException("xaml");
			}
			else if (null == steps || 0 == steps.Count)
			{
				throw new ArgumentNullException("steps");
			}

			// Load the Workflow XAML
			XmlDocument workflow = LoadXaml(xaml);

			// Get the Namespace Manager for parsing the code
			XmlNamespaceManager ns = CreateXamlNamespaces(workflow.NameTable);

			// Retrieve the existing custom workflow activities
			Dictionary<string, XmlNode> activityNodes = GetCustomActivityNodes(workflow, ns);

			// Loop through and instrument each step
			string workflowAssemblyName = null;
			foreach (InstrumentedStepConfiguration step in steps)
			{
				if (null == step)
				{
					continue;
				}

				// Retrieve the node for the step
				XmlNode node;
				if (!activityNodes.TryGetValue(step.StepId, out node))
				{
					throw new ArgumentOutOfRangeException("steps", step.StepId, "Id was invalid or was used multiple times.");
				}

				// If the fully qualified name for the workflow assembly name is unknown, it should be retrieved from the workflow XAML
				if (string.IsNullOrWhiteSpace(workflowAssemblyName))
				{
					FullyQualifiedTypeName fullTypeName = new FullyQualifiedTypeName(GetAttributeValue(node, AssemblyQualifiedNameAttribute));
					workflowAssemblyName = fullTypeName.FullAssemblyName;
				}

				// Instrument the step
				InstrumentStep(node, ns, step, workflowAssemblyName);
			}

			// Save the workflow back to XML
			using (StringWriter writer = new StringWriter(CultureInfo.InvariantCulture))
			{
				XmlWriterSettings settings = new XmlWriterSettings();
				settings.Indent = false;

				using (XmlWriter xmlWriter = XmlWriter.Create(writer, settings))
				{
					workflow.Save(xmlWriter);
				}

				return writer.ToString();
			}
		}

		#region Private Helper Methods
		private static Dictionary<string, XmlNode> GetCustomActivityNodes(XmlDocument workflow, XmlNamespaceManager ns)
		{
			// Locate all of the custom activity nodes
			XmlNodeList steps = workflow.DocumentElement.SelectNodes("//mxswa:ActivityReference[starts-with(@DisplayName, 'CustomActivityStep') and starts-with(@AssemblyQualifiedName, 'Microsoft.Crm.Workflow.Activities.Composite')]", ns);

			Dictionary<string, XmlNode> activityNodes = new Dictionary<string, XmlNode>();
			foreach (XmlNode node in steps)
			{
				// The id for the step is contained in the DisplayName attribute
				string stepId = GetAttributeValue(node, DisplayNameAttribute);
				if (string.IsNullOrWhiteSpace(stepId))
				{
					continue;
				}

				activityNodes.Add(stepId, node);
			}

			return activityNodes;
		}

		private static void InstrumentStep(XmlNode activityNode, XmlNamespaceManager ns, InstrumentedStepConfiguration step,
			string workflowAssemblyName)
		{
			// Strategy:
			// 1) Add the Input Parameter for Profiler Configuration
			//    a) Add two new variables for the new parameter (parameters are represented as two variables)
			//    b) Add a new create statement to create the string
			//    c) Add a new convert statement to convert the parameter to an internal type
			// 2) Replace the existing type with calls to the new profiled assembly
			Tuple<string, string> variables = CreateProfilerConfigurationVariables(activityNode, ns, step.StepId);

			// Locate the node that invokes the custom activity
			XmlNode invokeNode = activityNode.SelectSingleNode(string.Format(CultureInfo.InvariantCulture,
				"mxswa:ActivityReference.Properties/sco:Collection[@x:TypeArguments='Activity' and @x:Key='Activities']/mxswa:ActivityReference[@DisplayName='{0}']",
					step.StepId), ns);
			if (null == invokeNode)
			{
				throw new InvalidOperationException("Cannot locate the ActivityReference that invokes the Workflow Activity for step " + step.StepId);
			}

			// Create the conversion statements
			CreateConversionActivityReferences(invokeNode, ns, workflowAssemblyName, variables.Item1, variables.Item2, step.Configuration);

			// Replace the assembly qualified name
			SetAttributeValue(invokeNode, AssemblyQualifiedNameAttribute, new FullyQualifiedTypeName(step.ProfiledPluginType).FullName);

			// Append the new input argument
			XmlNode argumentsNode = invokeNode.SelectSingleNode("mxswa:ActivityReference.Arguments", ns);
			argumentsNode.AppendChild(CreateConfigurationInArgument(activityNode.OwnerDocument, ns,
				ProfilerCodeGenerationUtility.ProfilerConfigurationPropertyName, variables.Item2));
		}

		private static Dictionary<string, Tuple<FullyQualifiedTypeName, XmlNode>> GetCustomActivityFullyQualifiedNames(IOrganizationService service,
			XmlDocument workflow, XmlNamespaceManager ns)
		{
			// Extract the existing steps
			Dictionary<string, XmlNode> activityNodes = GetCustomActivityNodes(workflow, ns);

			// Convert each of the steps into a wrapper class
			FilterExpression criteria = new FilterExpression(LogicalOperator.Or);

			Dictionary<string, Tuple<FullyQualifiedTypeName, XmlNode>> parsedSteps = new Dictionary<string, Tuple<FullyQualifiedTypeName, XmlNode>>();
			Dictionary<string, FullyQualifiedTypeName> types = new Dictionary<string, FullyQualifiedTypeName>();
			foreach (KeyValuePair<string, XmlNode> pair in activityNodes)
			{
				FullyQualifiedTypeName typeName = GetCustomActivityFullyQualifiedName(pair.Key, pair.Value, ns);
				if (!types.ContainsKey(typeName.FullName))
				{
					types.Add(typeName.FullName, typeName);

					FilterExpression filter = criteria.AddFilter(LogicalOperator.And);
					filter.AddCondition("typename", ConditionOperator.Equal, typeName.TypeName);
					filter.AddCondition("assemblyname", ConditionOperator.Equal, typeName.AssemblyName);
					filter.AddCondition("culture", ConditionOperator.Equal, typeName.Culture);
					filter.AddCondition("version", ConditionOperator.Equal, typeName.Version);
					filter.AddCondition("publickeytoken", ConditionOperator.Equal, typeName.PublicKeyToken);
				}

				parsedSteps.Add(pair.Key, new Tuple<FullyQualifiedTypeName, XmlNode>(typeName, pair.Value));
			}

			// Retrieve the types from the DB
			QueryExpression query = new QueryExpression(PluginType.EntityLogicalName);
			query.ColumnSet = new ColumnSet("pluginassemblyid", "plugintypeid", "typename", "assemblyname", "version", "culture", "publickeytoken");
			query.Criteria = criteria;

			EntityCollection sdkTypes = service.RetrieveMultiple(query);

			// Loop through each type that was returned
			foreach (Entity entity in sdkTypes.Entities)
			{
				// Convert the name to a fully qualified name
				FullyQualifiedTypeName sdkType = new FullyQualifiedTypeName(entity.ToEntity<PluginType>());

				// Extract the existing type from the workflow
				FullyQualifiedTypeName existingType;
				if (types.TryGetValue(sdkType.FullName, out existingType))
				{
					existingType.PluginAssemblyId = sdkType.PluginAssemblyId;
					existingType.PluginTypeId = sdkType.PluginTypeId;

					types.Remove(sdkType.FullName);
				}
			}

			return parsedSteps;
		}

		private static FullyQualifiedTypeName GetCustomActivityFullyQualifiedName(string stepId, XmlNode activityNode, XmlNamespaceManager ns)
		{
			XmlNode invokeNode = activityNode.SelectSingleNode(string.Format(CultureInfo.InvariantCulture,
				"mxswa:ActivityReference.Properties/sco:Collection[@x:Key='Activities']/mxswa:ActivityReference[@DisplayName='{0}']",
				stepId), ns);
			if (null == invokeNode)
			{
				throw new ArgumentOutOfRangeException("stepId", stepId, "Unable to parse the ActivityReference that invokes the custom activity.");
			}

			// Extract the assembly qualified name for the type
			string name = GetAttributeValue(invokeNode, AssemblyQualifiedNameAttribute);
			if (string.IsNullOrWhiteSpace(name))
			{
				throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
					"Node for step {0} does not have an AssemblyQualifiedName attribute.", stepId));
			}

			return new FullyQualifiedTypeName(name);
		}

		[SuppressMessage("Microsoft.Security", "CA9876:AvoidLoadXmlUsage",
			Justification = "SharedUtil can't be used as this is an SDK assembly that is released to the customer.")]
		private static XmlDocument LoadXaml(string xaml)
		{
			XmlDocument workflow;
			using (StringReader reader = new StringReader(xaml))
			{
				XmlReaderSettings settings = new XmlReaderSettings();
				settings.CheckCharacters = true;
				settings.CloseInput = true;
				settings.ConformanceLevel = ConformanceLevel.Fragment;
				settings.IgnoreComments = true;
				settings.IgnoreWhitespace = true;

				using (XmlReader xmlReader = XmlReader.Create(reader, settings))
				{
					workflow = new XmlDocument();
					workflow.Load(xmlReader);
				}
			}

			return workflow;
		}

		private static XmlNamespaceManager CreateXamlNamespaces(XmlNameTable table)
		{
			XmlNamespaceManager ns = new XmlNamespaceManager(table);
			ns.AddNamespace("mxswa",
				"clr-namespace:Microsoft.Xrm.Sdk.Workflow.Activities;assembly=" + typeof(Microsoft.Xrm.Sdk.Workflow.InputAttribute).Assembly.FullName);
			ns.AddNamespace("sco",
				"clr-namespace:System.Collections.ObjectModel;assembly=" + typeof(System.Collections.ObjectModel.Collection<>).Assembly.FullName);
			ns.AddNamespace("x", "http://schemas.microsoft.com/winfx/2006/xaml");

			return ns;
		}

		private static Tuple<string, string> CreateProfilerConfigurationVariables(XmlNode activityNode, XmlNamespaceManager ns, string stepId)
		{
			const string VariableNameFormat = "{0}_{1}";
			const string ConvertedVariableNameFormat = "{0}_{1}_converted";
			const string ConvertedVariableSuffix = "_converted";

			XmlNode variablesNode = activityNode.SelectSingleNode("mxswa:ActivityReference.Properties/sco:Collection[@x:Key='Variables']", ns);
			if (null == variablesNode)
			{
				throw new InvalidOperationException("Unable to locate the Variables node for step = " + stepId);
			}

			// Loop through each of the variables to determine the new variable index
			string variablePrefix = stepId + "_";
			int newVariableIndex = 1;
			foreach (XmlNode variableNode in variablesNode.ChildNodes)
			{
				string variableName = GetAttributeValue(variableNode, NameAttribute);
				if (string.IsNullOrWhiteSpace(variableName))
				{
					continue;
				}

				// Check if this is a step variable that should be checked
				int startIndex = 0;
				if (variableName.StartsWith(variablePrefix, StringComparison.OrdinalIgnoreCase))
				{
					startIndex += variablePrefix.Length;
				}

				int endIndex = variableName.Length;
				if (variableName.EndsWith(ConvertedVariableSuffix, StringComparison.OrdinalIgnoreCase))
				{
					endIndex -= ConvertedVariableSuffix.Length;
				}

				// Resize the variable name for parsing
				variableName = variableName.Substring(startIndex, endIndex - startIndex);

				// Parse the index of the variable
				int variableIndex;
				if (int.TryParse(variableName, NumberStyles.Integer, CultureInfo.InvariantCulture, out variableIndex))
				{
					if (variableIndex >= newVariableIndex)
					{
						newVariableIndex = variableIndex + 1;
					}
				}
			}

			// Create the two variable nodes
			string newVariableName = string.Format(CultureInfo.InvariantCulture, VariableNameFormat, stepId, newVariableIndex);
			string newConvertedVariableName = string.Format(CultureInfo.InvariantCulture, ConvertedVariableNameFormat, stepId, newVariableIndex);

			variablesNode.AppendChild(CreateNewVariableNode(activityNode.OwnerDocument, ns, newVariableName));
			variablesNode.AppendChild(CreateNewVariableNode(activityNode.OwnerDocument, ns, newConvertedVariableName));

			return new Tuple<string, string>(newVariableName, newConvertedVariableName);
		}

		private static void CreateConversionActivityReferences(XmlNode invokeNode, XmlNamespaceManager ns, string workflowAssemblyName,
			string variableName, string convertedVariableName, ProfilerConfiguration configuration)
		{
			const string EvaluateExpression = "Microsoft.Crm.Workflow.Activities.EvaluateExpression, ";
			const string ConvertCrmXrmTypes = "Microsoft.Crm.Workflow.Activities.ConvertCrmXrmTypes, ";

			#region Add EvaluateExpression Node
			{
				XmlNode activityReference = CreateActivityReferenceNode(invokeNode.OwnerDocument, ns,
					EvaluateExpression + workflowAssemblyName, "EvaluateExpression");
				invokeNode.ParentNode.InsertBefore(activityReference, invokeNode);

				activityReference.InnerXml = string.Format(CultureInfo.InvariantCulture, @"
<mxswa:ActivityReference.Arguments>
	<InArgument x:TypeArguments=""x:String"" x:Key=""ExpressionOperator"">CreateCrmType</InArgument>
	<InArgument x:TypeArguments=""s:Object[]"" x:Key=""Parameters"">[New Object() {{ Microsoft.Xrm.Sdk.Workflow.WorkflowPropertyType.String, ""{0}"", ""String"" }}]</InArgument>
	<InArgument x:TypeArguments=""s:Type"" x:Key=""TargetType"">
		<mxswa:ReferenceLiteral x:TypeArguments=""s:Type"" Value=""x:String"" />
	</InArgument>
	<OutArgument x:TypeArguments=""x:Object"" x:Key=""Result"">[{1}]</OutArgument>
</mxswa:ActivityReference.Arguments>", VBScriptEncode(configuration.ToString()), variableName);
			}
			#endregion

			#region Add ConvertCrmXrmTypes Node
			{
				XmlNode activityReference = CreateActivityReferenceNode(invokeNode.OwnerDocument, ns,
					ConvertCrmXrmTypes + workflowAssemblyName, "ConvertCrmXrmTypes");
				invokeNode.ParentNode.InsertBefore(activityReference, invokeNode);

				activityReference.InnerXml = string.Format(CultureInfo.InvariantCulture, @"
<mxswa:ActivityReference.Arguments>
	<InArgument x:TypeArguments=""x:Object"" x:Key=""Value"">[{0}]</InArgument>
	<InArgument x:TypeArguments=""s:Type"" x:Key=""TargetType"">
		<mxswa:ReferenceLiteral x:TypeArguments=""s:Type"" Value=""x:String"" />
	</InArgument>
	<OutArgument x:TypeArguments=""x:Object"" x:Key=""Result"">[{1}]</OutArgument>
</mxswa:ActivityReference.Arguments>", variableName, convertedVariableName);
			}
			#endregion
		}

		private static XmlNode CreateActivityReferenceNode(XmlDocument document, XmlNamespaceManager ns, string assemblyQualifiedName,
			string displayName)
		{
			XmlNode activityReference = document.CreateElement("mxswa", "ActivityReference", ns.LookupNamespace("mxswa"));
			SetAttributeValue(activityReference, AssemblyQualifiedNameAttribute, assemblyQualifiedName);
			SetAttributeValue(activityReference, DisplayNameAttribute, displayName);

			return activityReference;
		}

		private static XmlNode CreateNewVariableNode(XmlDocument workflow, XmlNamespaceManager ns, string variableName)
		{
			// Create the variable node
			XmlNode newVariableNode = workflow.CreateElement("Variable", "http://schemas.microsoft.com/netfx/2009/xaml/activities");
			SetAttributeValue(newVariableNode, "x", "TypeArguments", ns.LookupNamespace("x"), "x:Object");
			SetAttributeValue(newVariableNode, NameAttribute, variableName);

			return newVariableNode;
		}

		private static XmlNode CreateConfigurationInArgument(XmlDocument workflow, XmlNamespaceManager ns, string propertyName, string variableName)
		{
			XmlNode inArgument = workflow.CreateElement("InArgument", "http://schemas.microsoft.com/netfx/2009/xaml/activities");
			SetAttributeValue(inArgument, "x", "TypeArguments", ns.LookupNamespace("x"), "x:String");
			SetAttributeValue(inArgument, "x", "Key", ns.LookupNamespace("x"), propertyName);
			inArgument.AppendChild(workflow.CreateTextNode(string.Format(CultureInfo.InvariantCulture,
				"[DirectCast({0}, System.String)]", variableName)));

			return inArgument;
		}

		private static void SetAttributeValue(XmlNode node, string name, string value)
		{
			XmlAttribute attribute = node.Attributes[name];
			if (null == attribute)
			{
				attribute = node.OwnerDocument.CreateAttribute(name);
				node.Attributes.Append(attribute);
			}

			attribute.Value = value;
		}

		private static void SetAttributeValue(XmlNode node, string prefix, string name, string ns, string value)
		{
			XmlAttribute attribute = node.Attributes[name];
			if (null == attribute)
			{
				attribute = node.OwnerDocument.CreateAttribute(prefix, name, ns);
				node.Attributes.Append(attribute);
			}

			attribute.Value = value;
		}

		private static string GetAttributeValue(XmlNode node, string name)
		{
			XmlAttribute attribute = node.Attributes[name];
			if (null == attribute)
			{
				return null;
			}

			return attribute.Value;
		}

		private static string VBScriptEncode(string value)
		{
			//TODO: Replace this with a better encoder
			string htmlEncoded = value.Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;");

			StringBuilder sb = new StringBuilder(htmlEncoded);
			sb.Replace("&quot;", "&#34;");	// &quot; == &#34; but replace to be able to find all occurrences
			sb.Replace("&#34;", "&#34;&#34;");	// Replace " by ""
			sb.Replace(",", "&#44;");	// HtmlEncode does not encode the ',' character so we need to do it here

			return sb.ToString().Replace("&", "&amp;");
		}
		#endregion

		#region Private Classes
		private sealed class FullyQualifiedTypeName
		{
			private string _fullName;
			private string _fullTypeName;

			public FullyQualifiedTypeName(PluginType type)
			{
				if (null == type)
				{
					throw new ArgumentNullException("type");
				}

				this.TypeName = type.TypeName ?? string.Empty;
				this.AssemblyName = type.AssemblyName ?? string.Empty;
				this.Version = type.Version ?? string.Empty;
				this.Culture = type.Culture ?? string.Empty;
				this.PublicKeyToken = type.PublicKeyToken ?? string.Empty;
				this.PluginTypeId = type.Id;

				if (null != type.PluginAssemblyId)
				{
					this.PluginAssemblyId = type.PluginAssemblyId.Id;
				}
			}

			public FullyQualifiedTypeName(string fullyQualifiedName)
			{
				if (string.IsNullOrWhiteSpace(fullyQualifiedName))
				{
					throw new ArgumentNullException("fullyQualifiedName");
				}

				// Example: Microsoft.Crm.QA.Workflow.SimpleSdkActivity, Microsoft.Crm.QA.Workflow.TestNet4Activity, Version=5.0.0.0, Culture=neutral, PublicKeyToken=2db8a640daea42cf
				// Parts:
				// [0] = Type Name
				// [1] = Assembly Name
				// [3] = Version
				// [5] = Culture
				// [7] = Public Key Token
				string[] parts = fullyQualifiedName.Split(new char[] { ',', '=' }, StringSplitOptions.RemoveEmptyEntries);
				if (parts.Length < 8)
				{
					throw new ArgumentException("Unable to parse the fully qualified name.", "fullyQualifiedName");
				}

				// Set the properties
				this.TypeName = (parts[0] ?? string.Empty).Trim();
				this.AssemblyName = (parts[1] ?? string.Empty).Trim();
				this.Version = (parts[3] ?? string.Empty).Trim();
				this.Culture = (parts[5] ?? string.Empty).Trim();
				this.PublicKeyToken = (parts[7] ?? string.Empty).Trim();
			}

			#region Properties
			public string FullName
			{
				get
				{
					if (string.IsNullOrWhiteSpace(this._fullTypeName))
					{
						this._fullTypeName = string.Format(CultureInfo.InvariantCulture,
							"{0}, {1}", this.TypeName, this.FullAssemblyName);
					}

					return this._fullTypeName;
				}
			}

			[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase",
				Justification = "XAML is setting with lower case.")]
			public string FullAssemblyName
			{
				get
				{
					if (string.IsNullOrWhiteSpace(this._fullName))
					{
						this._fullName = string.Format(CultureInfo.InvariantCulture,
							"{0}, Version={1}, Culture={2}, PublicKeyToken={3}",
							this.AssemblyName, this.Version, this.Culture, this.PublicKeyToken.ToLowerInvariant());
					}

					return this._fullName;
				}
			}

			public string TypeName { get; private set; }

			public string AssemblyName { get; private set; }

			public string Version { get; private set; }

			public string Culture { get; private set; }

			public string PublicKeyToken { get; private set; }

			public Guid PluginAssemblyId { get; set; }

			public Guid PluginTypeId { get; set; }
			#endregion
		}
		#endregion
	}

	#region Internal Classes
	internal sealed class InstrumentedStepConfiguration
	{
		public InstrumentedStepConfiguration(string stepId, ProfilerConfiguration configuration, PluginType profiledPluginType)
		{
			if (string.IsNullOrWhiteSpace(stepId))
			{
				throw new ArgumentNullException("stepId");
			}
			else if (null == configuration)
			{
				throw new ArgumentNullException("configuration");
			}
			else if (null == profiledPluginType)
			{
				throw new ArgumentNullException("profiledPluginType");
			}

			this.StepId = stepId;
			this.Configuration = configuration;
			this.ProfiledPluginType = profiledPluginType;
		}

		#region Properties
		public string StepId { get; private set; }

		public ProfilerConfiguration Configuration { get; private set; }

		public PluginType ProfiledPluginType { get; private set; }
		#endregion
	}
	#endregion
}
