﻿using System;
using System.Collections.Generic;

using PluginProfiler.Plugins;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Base class for all service implementations that replay events back to a plug-in
	/// </summary>
	/// <typeparam name="T">Type of service that is being used</typeparam>
	internal abstract class ProfilerReplayService<T>
		where T : ProfilerReplayEvent
	{
		private readonly Queue<ProfilerReplayEvent> EventQueue;

		/// <summary>
		/// Instantiates an instance of the ProfilerReplayService class
		/// </summary>
		/// <param name="events">Events that can be replayed.</param>
		internal ProfilerReplayService(Queue<ProfilerReplayEvent> events)
		{
			if (null == events)
			{
				throw new ArgumentNullException("events");
			}

			this.EventQueue = events;
		}

		#region Methods
		/// <summary>
		/// Retrieve the next event from the queue
		/// </summary>
		public T NextEvent()
		{
			if (0 == this.EventQueue.Count)
			{
				throw new InvalidOperationException("An event was requested after the recorded event queue has been completed.");
			}

			T replayEvent = this.EventQueue.Dequeue() as T;
			if (null == replayEvent)
			{
				throw new InvalidOperationException("A different event than the expected one occurred.");
			}

			return replayEvent;
		}
		#endregion
	}
}
