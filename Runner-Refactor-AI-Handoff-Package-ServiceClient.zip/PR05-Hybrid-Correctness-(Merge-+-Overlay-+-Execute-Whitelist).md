# PR 5 — Hybrid Correctness (Merge + Overlay + Execute Whitelist)

**Repo:** DataverseDebugger

## Global Non-Negotiables
1. No new external project references; reference ZIPs are conceptual only.
2. Do not refactor WebAPI entry wiring; only add a thin delegation seam when instructed.
3. Single-plugin execution only; no pipeline re-entry simulation.
4. Sender-controlled `ExecutionMode` is authoritative when provided; legacy fallback remains when absent.
5. Keep all changes inside existing `DataverseDebugger.Runner` project (no new projects).
6. Keep diffs minimal and reviewable; avoid opportunistic refactors.
7. Add deterministic errors for guards/NotSupported (include mode + operation + guidance).

## AI Implementation Rules
- Preserve current behavior unless this PR explicitly changes it.
- Maintain backward compatibility for request/response serialization.
- Add tests as specified; do not skip tests.



## Objective
Make Hybrid mode correct per spec: cached writes, live reads, cache-prevails merging, and correct RetrieveMultiple overlay.

## Scope
Hybrid is defined as (with ServiceClient live backend for debugging):
- Writes never hit live (Create/Update/Delete cached)
- Reads hit live when available
- Reads must reflect cached changes
- Live is used only to fill missing requested attributes for cached entities
- RetrieveMultiple overlays by ID:
  - remove cached deletes
  - replace cached updates (merge: cache overrides, live fills missing per ColumnSet)
  - cached creates injected only when explicitly ID-targeted (Option 4A)
- Hybrid Execute uses strict whitelist (initially WhoAmI only) and deterministic NotSupported otherwise.

## Deliverables
### Live backend (locked)
- Hybrid must be implemented as a wrapper over the **ServiceClient-backed live `IOrganizationService`** created by `ServiceClientOrganizationServiceFactory`.
- Hybrid must never write to the inner service.


### A) Retrieve merge (single)
If entity in cache (created/updated):
- If ColumnSet requests attributes missing in cache:
  - Retrieve from live and fill missing requested attributes only
- Cache prevails on conflicts
If deleted in cache:
- behave as not found; do not query live

### B) RetrieveMultiple overlay
- Query live first
- For each entity in result:
  - if deleted in cache → remove
  - if updated in cache → merge (cache overrides, live fills missing requested attrs as allowed)
- Cached creates:
  - Only add if query explicitly targets those IDs
  - No general criteria evaluation for cached-only entities

### C) Execute whitelist
- WhoAmI allowed
- All others throw `RunnerNotSupportedException` (include mode + request type + guidance)
- No passthrough of write-like requests
- **Important:** If any existing runner code path internally uses `Execute(Retrieve/RetrieveMultiple)`, refactor that internal runner path to call `Retrieve` / `RetrieveMultiple` directly rather than broadening the Hybrid whitelist.

### D) Logging hooks
- Log intercepted writes and overlay decisions (at least at debug/trace level)

### Tests
- Unit tests:
  - Retrieve merge fills missing attrs from live and cache prevails
  - RetrieveMultiple overlays updates and removes deletes
  - Cached creates appear only for ID-targeted queries
  - Writes never call live service
  - Execute whitelist enforced

### Acceptance criteria
- Hybrid reads reflect cached changes correctly
- Hybrid never writes to live
- Behavior deterministic and test-covered

## AI Prompt (copy/paste)
> Implement PR5 Hybrid correctness: update RunnerOrganizationService (or introduce Hybrid wrapper) so Hybrid mode caches all writes, performs live reads, and merges cached entities with live results: cache attributes override; live fills missing requested attributes only. Implement correct RetrieveMultiple overlay by ID (apply cached updates, remove cached deletes), and inject cached creates only for ID-targeted queries. Enforce strict Execute whitelist (WhoAmI only) with deterministic NotSupported for others. Add thorough unit tests verifying no live writes and correct merge/overlay behavior.

