﻿namespace Microsoft.Dynamics.ProjectOperations.PluginForge
{
    using System;
    using System.Runtime.Caching;
    using Cache = System.Runtime.Caching.MemoryCache;

    /// <summary>
    /// Class definition for a strongly typed memory cache of items.
    /// </summary>
    /// <typeparam name="TItem">The type of items contained within the cache.</typeparam>
    /// <remarks>
    /// Allows for conjunctive sliding and absolute expiration.  This implementation utilizes a system-wide
    /// caching mechanism.  Care is taken to 'unique-ify' cache key values specific to each instance of the class.
    /// </remarks>
    internal class MemoryCache<TItem>
        where TItem : class
    {
        private const string AbsoluteKeyPrefix = "Ω";
        private const string SlidingKeyPrefix = "∞";

        private readonly Func<Cache> cache;
        private readonly Guid instanceId = Guid.NewGuid();
        private readonly object lockObject = new object();
        private readonly TimeSpan slidingExpiration;

        /// <summary>
        /// Initializes a new instance of the <see cref="MemoryCache{TItem}"/> class.
        /// </summary>
        /// <param name="slidingExpiration">The window of time an element in the cache must be accessed in order
        /// to remain in the cache.</param>
        public MemoryCache(TimeSpan slidingExpiration)
        {
            this.cache = () => Cache.Default;
            this.slidingExpiration = slidingExpiration;
        }

        /// <summary>
        /// Gets the sliding expiration of the active cache instance.
        /// </summary>
        public TimeSpan SlidingExpiration
        {
            get { return this.slidingExpiration; }
        }

        /// <summary>
        /// Gets the active backing cache instance.
        /// </summary>
        protected Cache Cache
        {
            get { return this.cache(); }
        }

        /// <summary>
        /// Gets a value used to uniquely identify [and scope] the active cache instance.
        /// </summary>
        protected virtual string InstanceId
        {
            get { return this.instanceId.ToString("N"); }
        }

        /// <summary>
        /// Gets a value used to prefix an absolute key in the cache.
        /// </summary>
        protected virtual string PrefixAbsoluteKey
        {
            get { return MemoryCache<TItem>.AbsoluteKeyPrefix; }
        }

        /// <summary>
        /// Gets a value used to prefix a sliding key in the cache.
        /// </summary>
        protected virtual string PrefixSlidingKey
        {
            get { return MemoryCache<TItem>.SlidingKeyPrefix; }
        }

        /// <summary>
        /// Obtains the specified item from the cache.
        /// </summary>
        /// <param name="key">Key of the item being obtained.</param>
        /// <param name="valueFactory">Function used to create an instance of <typeparamref name="TItem"/>.</param>
        /// <returns>A cached instance of type <typeparamref name="TItem"/> associated with the key <paramref name="key"/>.</returns>
        /// <exception cref="ArgumentNullException">Thrown when <paramref name="key"/> is null, empty, or
        /// white space or when <paramref name="valueFactory"/> is null.</exception>
        /// <remarks>
        /// If the specified item is not present in the cache <paramref name="valueFactory"/> is invoked to create the item.
        /// It is then added to the cache and returned.
        /// </remarks>
        public TItem Obtain(string key, CreateCacheItem<TItem> valueFactory)
        {
            if (string.IsNullOrWhiteSpace(key))
            {
                throw new ArgumentNullException(nameof(key));
            }

            if (valueFactory == null)
            {
                throw new ArgumentNullException(nameof(valueFactory));
            }

            Cache activeCache = this.Cache;
            string absoluteKey = this.GetAbsoluteExpirationKey(key);
            string slidingKey = this.GetSlidingExpirationKey(key);

            TItem result = default(TItem);

            lock (this.lockObject)
            {
                if (activeCache.Contains(absoluteKey) &&
                    activeCache.Contains(slidingKey))
                {
                    result = (TItem)activeCache.Get(slidingKey);
                }

                if (result == default(TItem))
                {
                    CacheItem<TItem> item = valueFactory(key);

                    activeCache.Remove(absoluteKey);
                    activeCache.Add(absoluteKey, new object(), item.Expiration);

                    try
                    {
                        CacheItemPolicy slidingPolicy = new CacheItemPolicy()
                        {
                            ChangeMonitors = { activeCache.CreateCacheEntryChangeMonitor(new string[] { absoluteKey }) },
                            SlidingExpiration = this.SlidingExpiration
                        };

                        activeCache.Remove(slidingKey);
                        activeCache.Add(slidingKey, item.Item, slidingPolicy);

                        result = item.Item;
                    }
                    catch
                    {
                        activeCache.Remove(absoluteKey);
                        throw;
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Constructs an absolute expiration key based on the specified key.
        /// </summary>
        /// <param name="key">A key value.</param>
        /// <returns>An absolute expiration key value.</returns>
        /// <exception cref="ArgumentNullException">Thrown when <paramref name="key"/> is null, empty,
        /// or white space.</exception>
        protected virtual string GetAbsoluteExpirationKey(string key)
        {
            if (string.IsNullOrWhiteSpace(key))
            {
                throw new ArgumentNullException(nameof(key));
            }

            return $"{this.PrefixAbsoluteKey}{this.InstanceId}{key}";
        }

        /// <summary>
        /// Constructs a sliding expiration key based on the specified key. 
        /// </summary>
        /// <param name="key">A key value.</param>
        /// <returns>A sliding expiration key value.</returns>
        /// <exception cref="ArgumentNullException">Thrown when <paramref name="key"/> is null, empty,
        /// or whitespace.</exception>
        protected virtual string GetSlidingExpirationKey(string key)
        {
            if (string.IsNullOrWhiteSpace(key))
            {
                throw new ArgumentNullException(nameof(key));
            }

            return $"{this.PrefixSlidingKey}{this.InstanceId}{key}";
        }
    }
}