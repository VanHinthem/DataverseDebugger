﻿using System;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace Microsoft.Dynamics.ProjectOperations.PluginForge
{
    /// <summary>
    /// Static class container comprising a certificate provider.
    /// </summary>
    internal static class CertificateProvider
    {
        /// <summary>
        /// Finds a certificate with the specified subject name.
        /// </summary>
        /// <param name="subjectName">The subject name of a certificate.</param>
        /// <returns>A certificate with the specified subject name.</returns>
        /// <exception cref="ArgumentNullException">Thrown when <paramref name="subjectName"/> is null, empty, or white space.</exception>
        /// <exception cref="ArgumentException">Throw when no valid certificate was found with the specified subject name.</exception>
        /// <remarks>
        /// Certificates are queried within the current user's "my" store.  If not found, the local machine's "my" store is also queried.
        /// Only valid certificates are considered.
        /// If more than one certificate is found, the certificate with the longest time to expiry is returned.
        /// </remarks>
        public static X509Certificate2 FindBySubjectName(string subjectName)
        {
            if (string.IsNullOrWhiteSpace(subjectName))
            {
                throw new ArgumentNullException(nameof(subjectName));
            }

            X509Certificate2 certificate = default;

            if (TryFindCerts(StoreName.My, StoreLocation.CurrentUser, out X509Certificate2Collection certs) ||
                TryFindCerts(StoreName.My, StoreLocation.LocalMachine, out certs))
            {
                // If more than one certificate is found, select the one with the longest time to expiration.
                if (certs.Count > 1)
                {
                    certificate = certs.OfType<X509Certificate2>().OrderByDescending(c => c.NotAfter).FirstOrDefault();
                    if (certificate != default)
                    {
                        certs.Remove(certificate);
                    }

                    certs.Dispose();
                }
                else
                {
                    certificate = certs[0];
                }
            }

            return certificate != default
                        ? certificate
                        : throw new ArgumentException(
                                    $"A valid certificate matching the specified subject name '{subjectName}' could not be found.",
                                    nameof(subjectName));

            bool TryFindCerts(StoreName storeName, StoreLocation storeLocation, out X509Certificate2Collection certificates)
            {
                using (X509Store store = new X509Store(storeName, storeLocation))
                {
                    store.Open(OpenFlags.ReadOnly | OpenFlags.OpenExistingOnly);

                    // Find valid certificates by subject name (case-insensitive contains match).
                    certificates = store.Certificates?.Find(findType: X509FindType.FindBySubjectName, findValue: subjectName, validOnly: true);
                    store.Close();
                }

                return certificates?.Count > 0;
            }
        }

        /// <summary>
        /// Disposes of all the certificates contained within the specified collection.
        /// </summary>
        /// <param name="certs">A collection of certificates.</param>
        private static void Dispose(this X509Certificate2Collection certs)
        {
            if (certs != default)
            {
                foreach (var cert in certs)
                {
                    cert.Dispose();
                }
            }
        }
    }
}
