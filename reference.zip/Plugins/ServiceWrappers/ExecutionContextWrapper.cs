﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Runtime.Serialization;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace PluginProfiler.Plugins.ServiceWrappers
{
	/// <summary>
	/// Wrapper for the IPluginExecutionContext provided by the IOrganizationServiceFactory during execution of a plug-in.
	/// </summary>
	/// <remarks>
	/// This class can be serialized into a string using the ToString() method and deserialized using the Deserialize method.
	/// </remarks>
	[DataContract(Name = "ExecutionContext", Namespace = "")]
	[KnownType(typeof(PluginExecutionContextWrapper))]
	[KnownType(typeof(WorkflowExecutionContextWrapper))]
	public abstract class ExecutionContextWrapper : IExecutionContext
	{
		/// <summary>
		/// Instantiates an instance of the PluginExecutionContextWrapper.
		/// </summary>
		/// <remarks>
		/// This constructor is called by the static Deserialize method.
		/// </remarks>
		protected ExecutionContextWrapper()
		{
		}

		/// <summary>
		/// Instantiates an instance of the PluginExecutionContextWrapper in the plug-in profiler.
		/// </summary>
		/// <param name="context">IPluginExecutionContext instance that should be wrapped.</param>
		internal ExecutionContextWrapper(IExecutionContext context)
		{
			if (null == context)
			{
				throw new ArgumentNullException("context");
			}

			this.InnerContext = context;
		}

		#region IExecutionContext Members
		[DataMember]
		public Guid BusinessUnitId { get; protected set; }

		[DataMember]
		public Guid CorrelationId { get; protected set; }

		[DataMember]
		public int Depth { get; protected set; }

		[DataMember]
		public Guid InitiatingUserId { get; protected set; }

		[DataMember]
		public ParameterCollection InputParameters { get; protected set; }

		[DataMember]
		public bool IsExecutingOffline { get; protected set; }

		[DataMember]
		public bool IsInTransaction { get; protected set; }

		[DataMember]
		public bool IsOfflinePlayback { get; protected set; }

		[DataMember]
		public int IsolationMode { get; protected set; }

		[DataMember]
		public string MessageName { get; protected set; }

		[DataMember]
		public int Mode { get; protected set; }

		[DataMember]
		public DateTime OperationCreatedOn { get; protected set; }

		[DataMember]
		public Guid OperationId { get; protected set; }

		[DataMember]
		public Guid OrganizationId { get; protected set; }

		[DataMember]
		public string OrganizationName { get; protected set; }

		[DataMember]
		public ParameterCollection OutputParameters { get; protected set; }

		[DataMember]
		public EntityReference OwningExtension { get; protected set; }

		[DataMember]
		public EntityImageCollection PostEntityImages { get; protected set; }

		[DataMember]
		public EntityImageCollection PreEntityImages { get; protected set; }

		[DataMember]
		public Guid PrimaryEntityId { get; protected set; }

		[DataMember]
		public string PrimaryEntityName { get; protected set; }

		[DataMember]
		public Guid? RequestId { get; protected set; }

		[DataMember]
		public string SecondaryEntityName { get; protected set; }

		[DataMember]
		public ParameterCollection SharedVariables { get; protected set; }

		[DataMember]
		public Guid UserId { get; protected set; }
		#endregion

		#region Properties
		/// <summary>
		/// IPluginExecutionContext property that is wrapped by this instance of PluginExecutionContextWrapper.
		/// </summary>
		internal IExecutionContext InnerContext { get; private set; }

		/// <summary>
		/// Type of operation represented by this context type
		/// </summary>
		internal abstract OperationType OperationType { get; }
		#endregion

		#region Public Methods
		/// <summary>
		/// Converts the IPluginExecutionContext into a serialized value using the PartialTrustSerializer.
		/// </summary>
		public override string ToString()
		{
			//Write the object to the stream
			string value = this.SerializeContext(); //PartialTrustSerializer.Serialize(this.GetType(), this);

			//If the serialized copy does not start with the encoding, update it
			if (!value.StartsWith("<?", StringComparison.Ordinal))
			{
				value = ProfilerSharedUtility.XmlDocumentDeclaration + value;
			}

			return value;
		}

		/// <summary>
		/// Instantiates an instance of the PluginExecutionContext from the serialized value
		/// </summary>
		/// <param name="operation">Type of operation to be deserialized</param>
		/// <param name="serializedValue">Serialized version of the IPluginExecutionContext object.</param>
		public static IExecutionContext Deserialize(OperationType operation, string serializedValue)
		{
			if (string.IsNullOrWhiteSpace(serializedValue))
			{
				throw new ArgumentNullException("serializedValue");
			}

			Type contextType;
			switch (operation)
			{
				case OperationType.Plugin:
					contextType = typeof(PluginExecutionContextWrapper);
					break;
				case OperationType.WorkflowActivity:
					contextType = typeof(WorkflowExecutionContextWrapper);
					break;
				default:
					throw new NotImplementedException("OperationType = " + operation);
			}

			try
			{
				return (IExecutionContext)PartialTrustSerializer.Deserialize(contextType, serializedValue, (Assembly)null);
			}
			catch (Exception ex)
			{
				throw new InvalidOperationException("Unable to deserialize the serialized value.", ex);
			}
		}
		#endregion

		#region Protected Methods
		/// <summary>
		/// Populates all of the methods on the class
		/// </summary>
		/// <typeparam name="TContextInterface">Type of execution context interface</typeparam>
		[SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter",
			Justification = "Design forces a compile time check for the type of interface as it must be of type IExecutionContext.")]
		protected void PopulateMethods<TContextInterface>()
			where TContextInterface : IExecutionContext
		{
			//Loop through each property and set the value
			foreach (Tuple<PropertyInfo, PropertyInfo> propertyMap in LoadContextPropertyMap<TContextInterface>())
			{
				//Retrieve the property
				object value = propertyMap.Item1.GetValue(this.InnerContext, null);

				//Convert it to the current interface
				IExecutionContext contextValue = value as IExecutionContext;
				if (null != contextValue)
				{
					// Wrap a context property in a wrapper
					value = this.InstantiateContextWrapper(contextValue);
				}

				// Even though the properties are the same for all contexts, reflection security checks require the actual type
				// of the instance calling set (since this class is abstract, it will be the derived class) would have access to
				// the property type without reflection. Since that is not true when calling into the private set for 
				this.SetContextProperty(propertyMap.Item2, value);
			}
		}

		internal abstract IExecutionContext InstantiateContextWrapper(IExecutionContext context);

		/// <summary>
		/// Sets the context property with the specified value
		/// </summary>
		/// <param name="contextProperty">Property to be set</param>
		/// <param name="value">Value to be set</param>
		/// <remarks>
		/// Reflection security checks require the actual type of the instance calling set (since this class is abstract, 
		/// it will be the derived class) would have access to the property type without reflection. This is why the setters
		/// for all of the IExecutionContext members. 
		/// </remarks>
		protected abstract void SetContextProperty(PropertyInfo contextProperty, object value);

		/// <summary>
		/// Produces a serialized version of the context
		/// </summary>
		protected abstract string SerializeContext();
		#endregion

		#region Private Methods
		/// <summary>
		/// Populates the Property Mapping for the object
		/// </summary>
		/// <typeparam name="TInterface">Derived interface type</typeparam>
		private List<Tuple<PropertyInfo, PropertyInfo>> LoadContextPropertyMap<TInterface>()
		{
			//Loop through each of the properties on the wrapper class and map them to the corresponding property on the IPluginExecutContext
			//interface.
			List<Tuple<PropertyInfo, PropertyInfo>> propertyList = new List<Tuple<PropertyInfo, PropertyInfo>>();
			foreach (PropertyInfo wrapperProperty in this.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
			{
				//If this property is not a DataMember then it should not be included
				DataMemberAttribute[] attributes =
					(DataMemberAttribute[])wrapperProperty.GetCustomAttributes(typeof(DataMemberAttribute), true);
				if (null == attributes || 0 == attributes.Length)
				{
					continue;
				}

				//Retrieve the property on the interface. If it is not present, exclude the property
				PropertyInfo contextProperty = typeof(TInterface).GetProperty(wrapperProperty.Name);
				if (null == contextProperty)
				{
					contextProperty = typeof(IExecutionContext).GetProperty(wrapperProperty.Name);
					if (null == contextProperty)
					{
						continue;
					}
				}

				//Add the properties to the list
				propertyList.Add(new Tuple<PropertyInfo, PropertyInfo>(contextProperty, wrapperProperty));
			}

			return propertyList;
		}
		#endregion
	}
}
