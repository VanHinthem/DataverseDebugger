﻿using System;

using PluginProfiler.Library.Reporting;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Wraps the Profiler Tracing Service in case it was never supplied by the user
	/// </summary>
	internal sealed class ProfilerTracingService : MarshalByRefObject, IProfilerTracingService
	{
		private readonly IProfilerTracingService InternalService;

		/// <summary>
		/// Instantiates an instance of the ProfilerTracingService
		/// </summary>
		public ProfilerTracingService(IProfilerTracingService service)
		{
			this.InternalService = service;
		}

		/// <summary>
		/// Outputs traces
		/// </summary>
		public void Trace(string format, params object[] args)
		{
			if (null == this.InternalService)
			{
				return;
			}

			this.InternalService.Trace(format, args);
		}
	}
}