# PR-A03 – Deterministic Runner Copy on Build

## Objective
Copy Runner binaries into the App output folder on normal Build (Debug/Release), not only on Publish.

## Invariants
- Do not change Publish behavior.
- Do not add runtime copy logic.

## Target Files (In-Scope)
- `DataverseDebugger.App.csproj`

## Required Build Behavior (Authoritative)
After building the App:
- `$(OutDir)\runner\DataverseDebugger.Runner.exe` exists
- Runner dependencies exist alongside it

Expected Debug path example:
- `DataverseDebugger.App\bin\Debug\net8.0-windows\runner\DataverseDebugger.Runner.exe`

## Acceptance Criteria (Manual)
- Build Debug and confirm runner exists under output `runner\`.
- App runs from bin output without solution-root fallback.
