﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Reflection;

using Microsoft.Xrm.Sdk;

using PluginProfiler.Plugins.ServiceWrappers;

namespace PluginProfiler.Plugins
{
	/// <summary>
	/// Represents data required to initialize the plug-in.
	/// </summary>
	internal sealed class PluginInitializationContext
	{
		#region Methods
		/// <summary>
		/// Refreshes the assembly that is stored in the context
		/// </summary>
		/// <param name="assembly">Assembly that has been changed</param>
		/// <param name="modifiedDate">Modified date of the entity</param>
		public void RefreshAssembly(byte[] assembly, DateTime modifiedDate)
		{
			if (null == assembly || 0 == assembly.Length)
			{
				throw new ArgumentNullException("assembly");
			}

			this.AssemblyBytes = assembly;
			this.AssemblyModifiedDate = modifiedDate;
			this.Plugin = null;
		}

		/// <summary>
		/// Refreshes the step that is stored in the context
		/// </summary>
		/// <param name="configuration">Configuration attribute value</param>
		/// <param name="secureConfigId">ID of the secure configuration id</param>
		/// <param name="modifiedDate">Modified date of the entity</param>
		public void RefreshStep(string configuration, EntityReference secureConfigId, DateTime modifiedDate)
		{
			this.Configuration = configuration;
			this.StepModifiedDate = modifiedDate;
			if (null == secureConfigId)
			{
				this.SecureConfigurationId = Guid.Empty;
			}
			else
			{
				this.SecureConfigurationId = secureConfigId.Id;
			}
			this.Plugin = null;
		}

		/// <summary>
		/// Refreshes the step that is stored in the context
		/// </summary>
		/// <param name="configuration">Configuration attribute value</param>
		/// <param name="modifiedDate">Modified date of the entity</param>
		public void RefreshSecureConfig(string configuration, DateTime modifiedDate)
		{
			this.SecureConfiguration = configuration;
			this.SecureConfigModifiedDate = modifiedDate;
			this.Plugin = null;
		}

		/// <summary>
		/// Initializes the InitializationContext with the plug-in's constructor information
		/// </summary>
		/// <param name="config">Configuration for the profiler plug-in</param>
		public void InitializePluginConstructors(ProfilerConfiguration config)
		{
			if (null != this.Plugin)
			{
				return;
			}
			else if (null == config)
			{
				throw new ArgumentNullException("config");
			}

			Type pluginType = this.LoadPluginType(config);

			// If this is a workflow activity, only the default constructor should be used
			ConstructorInfo constructor;
			List<object> constructorParameters;
			if (typeof(Activity).IsAssignableFrom(pluginType))
			{
				this.IsWorkflowActivity = true;

				constructor = pluginType.GetConstructor(new Type[0]);
				constructorParameters = new List<object>(0);
			}
			else if (typeof(IPlugin).IsAssignableFrom(pluginType))
			{
				this.IsWorkflowActivity = false;

				constructor = pluginType.GetConstructor(new Type[] { typeof(string), typeof(string) });
				constructorParameters = new List<object>(new object[] { this.Configuration, this.SecureConfiguration });
				if (null == constructor)
				{
					constructorParameters.RemoveAt(constructorParameters.Count - 1);

					constructor = pluginType.GetConstructor(new Type[] { typeof(string) });
					if (null == constructor)
					{
						constructorParameters.RemoveAt(constructorParameters.Count - 1);

						constructor = pluginType.GetConstructor(new Type[0]);
					}
				}
			}
			else
			{
				throw new NotSupportedException(string.Format(CultureInfo.InvariantCulture,
					"Only classes implementing {0} and {1} are supported.", typeof(Activity).FullName, typeof(IPlugin).FullName));
			}

			if (null == constructor)
			{
				throw new InvalidPluginExecutionException(ProfilerSharedUtility.DefaultExceptionStatus,
					"No valid constructors exist for plug-in: " + pluginType.FullName);
			}

			this.Constructor = constructor;
			this.ConstructorParameters = constructorParameters.ToArray();
		}

		/// <summary>
		/// Instantiates the plug-in that is persisted in the PluginInitializationContext object.
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes",
			Justification = "Any exception that occurs during the constructor needs to be logged to the Plug-in Profile.")]
		public bool Instantiate(ProfilerPluginReport report)
		{
			if (null == report)
			{
				throw new ArgumentNullException("report");
			}
			else if (null == this.Constructor)
			{
				throw new InvalidPluginExecutionException(ProfilerSharedUtility.DefaultExceptionStatus,
					"Cannot call Instantiate before calling PrepareContext.");
			}

			// Setup the variables
			Stopwatch watch = new Stopwatch();
			DateTime startTime = DateTime.UtcNow;
			Exception executionException = null;

			// Invoke the plug-in's constructor with performance statistics
			object instance;
			try
			{
				watch.Start();
				instance = this.Constructor.Invoke(this.ConstructorParameters);
				watch.Stop();

				// Determine if this is a plug-in or a workflow activity
				if (this.IsWorkflowActivity)
				{
					this.Activity = (Activity)instance;
					this.Plugin = null;
				}
				else
				{
					this.Activity = null;
					this.Plugin = (IPlugin)instance;
				}
			}
			catch (Exception ex)
			{
				watch.Stop();

				// Save the exception that occurred
				executionException = ex;
			}

			// Report the result of the exception
			report.SetConstructorResult(startTime, watch.ElapsedMilliseconds, executionException);

			// If no exception occurred, then the plug-in executed successfully.
			return (null == executionException);
		}
		#endregion

		#region Properties
		/// <summary>
		/// Last modified date of the PluginAssembly record.
		/// </summary>
		public DateTime AssemblyModifiedDate { get; private set; }

		/// <summary>
		/// Last modified date of the SdkMessageProcessingStep record.
		/// </summary>
		public DateTime StepModifiedDate { get; private set; }

		/// <summary>
		/// Last modified date of the SdkMessageProcessingStepSecureConfig record.
		/// </summary>
		public DateTime SecureConfigModifiedDate { get; private set; }

		/// <summary>
		/// Id for the Secure Configuration entity
		/// </summary>
		public Guid SecureConfigurationId { get; private set; }

		/// <summary>
		/// Instantiated instance of the plug-in
		/// </summary>
		public IPlugin Plugin { get; private set; }

		/// <summary>
		/// Instantiated instance of the workflow activity
		/// </summary>
		public Activity Activity { get; private set; }

		/// <summary>
		/// Indicates that this is workflow activity
		/// </summary>
		private bool IsWorkflowActivity { get; set; }

		/// <summary>
		/// Wrapper for the proxy types behavior
		/// </summary>
		public ProxyTypesWrapper ProxyWrapper { get; private set; }

		/// <summary>
		/// Configuration value which needs to be provided to the plug-in
		/// </summary>
		public string Configuration { get; set; }

		/// <summary>
		/// Secure configuration which needs to be provided to the plug-in
		/// </summary>
		public string SecureConfiguration { get; set; }
		#endregion

		#region Private Methods
		private Type LoadPluginType(ProfilerConfiguration config)
		{
			if (null == this.AssemblyBytes)
			{
				throw new InvalidPluginExecutionException(ProfilerSharedUtility.DefaultExceptionStatus,
					"Cannot call LoadPluginType before calling RefreshAssembly.");
			}

			Assembly assembly = Assembly.Load(this.AssemblyBytes);
			this.ProxyWrapper = new ProxyTypesWrapper(assembly);
			Type proxyType = assembly.GetType(config.TypeName, false);
			if (null == proxyType)
			{
				throw new InvalidPluginExecutionException(ProfilerSharedUtility.DefaultExceptionStatus,
					"TypeName specified in the configuration is not valid: " + config.TypeName);
			}

			return proxyType;
		}
		#endregion

		#region Private Properties
		private byte[] AssemblyBytes { get; set; }

		private ConstructorInfo Constructor { get; set; }

		private object[] ConstructorParameters { get; set; }
		#endregion
	}
}
