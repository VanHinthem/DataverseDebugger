﻿using System;
using System.IO;
using System.Net;
using System.Reflection;
using System.Security;
using System.Security.Permissions;
using System.Text.RegularExpressions;

using PluginProfiler.Library.Reporting;

using Microsoft.Xrm.Sdk;
using System.Globalization;
using System.ServiceModel;
using PluginProfiler.Plugins;
using PluginProfiler.Plugins.ServiceWrappers;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Configuration to be used for the operation for replay or debug of the plug-in
	/// </summary>
	[Serializable]
	public sealed class WorkflowOperationConfiguration : OperationConfiguration
	{
		public WorkflowOperationConfiguration(string assemblyFilePath, string typeName, string logFilePath)
			: base(OperationType.WorkflowActivity, assemblyFilePath, typeName, logFilePath)
		{
		}
	}
}