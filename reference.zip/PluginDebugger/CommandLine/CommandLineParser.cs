﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Reflection;
using System.Globalization;

namespace Microsoft.Crm.Services.Utility
{
	internal interface ICommandLineArgumentSource
	{
		void OnUnknownArgument(string argumentName, string argumentValue);
		void OnInvalidArgument(string argument);
	}

	/// <remarks>
	/// Utility class to parse command line arguments.
	/// </remarks>
	internal sealed class CommandLineParser
	{
		#region Fields
		/// <summary>
		/// The object that contains the properties to set.
		/// </summary>
		private ICommandLineArgumentSource _argsSource;
		/// <summary>
		/// A mapping of argument switches to command line arguments.
		/// </summary>
		private Dictionary<string, CommandLineArgument> _argumentsMap;
		/// <summary>
		/// A list of all of the arguments that are supported 
		/// </summary>
		private List<CommandLineArgument> _arguments;
		#endregion

		#region Constructors
		/// <summary>
		/// Creates a new command line parser for the given object.
		/// </summary>
		/// <param name="argsSource">The object containing the properties representing the command line args to set.</param>
		internal CommandLineParser(ICommandLineArgumentSource argsSource)
		{
			Trace.TraceInformation("Entering {0}", MethodBase.GetCurrentMethod().Name);

			Debug.Assert(argsSource != null);
			Trace.TraceInformation("Creating CommandLineParser for {0}.", argsSource.GetType().Name);

			this._argsSource = argsSource;
			this._arguments = new List<CommandLineArgument>();
			this._argumentsMap = this.GetPropertyMap();

			Trace.TraceInformation("Exiting {0}", MethodBase.GetCurrentMethod().Name);
		}
		#endregion

		#region Properties
		private ICommandLineArgumentSource ArgumentsSource
		{
			get
			{
				return this._argsSource;
			}
		}

		private List<CommandLineArgument> Arguments
		{
			get
			{
				return this._arguments;
			}
		}

		private Dictionary<string, CommandLineArgument> ArgumentsMap
		{
			get
			{
				return this._argumentsMap;
			}
		}
		#endregion

		#region Methods
		internal void ParseArguments(string[] args)
		{
			Trace.TraceInformation("Entering {0}", MethodBase.GetCurrentMethod().Name);

			// Loop through all of the arguments
			if (args != null)
			{
				foreach (string argument in args)
				{
					if (CommandLineParser.IsArgument(argument))
					{
						// If we've got an argument, set that argument's value from the map.
						string argValue = null;
						string argName = CommandLineParser.GetArgumentName(argument, out argValue);
						if (!String.IsNullOrEmpty(argName) && this.ArgumentsMap.ContainsKey(argName))
						{
							Trace.TraceInformation("Setting argument {0} to value {1}", argName, argValue);
							this.ArgumentsMap[argName].SetValue(this.ArgumentsSource, argValue);
						}
						else
						{
							this.ArgumentsSource.OnUnknownArgument(argName, argValue);
						}
					}
					else
					{
						this.ArgumentsSource.OnInvalidArgument(argument);
					}
				}
			}

			this.ParseConfigArguments();

			Trace.TraceInformation("Exiting {0}", MethodBase.GetCurrentMethod().Name);
		}

		private void ParseConfigArguments()
		{
			Trace.TraceInformation("Entering {0}", MethodBase.GetCurrentMethod().Name);

			// Loop through all of the arguments in the app.config file.
			foreach (string appSettingKey in System.Configuration.ConfigurationManager.AppSettings.AllKeys)
			{
				// Try to find the argument in the possible list of args.  If it has not yet been
				// provided, use it.  If it was given on the command line, that one wins and we'll
				// skip the one from the config file.  If it isn't an arg, skip it as it may be
				// useful for something else.
				string argName = appSettingKey.ToUpperInvariant();
				string argValue = System.Configuration.ConfigurationManager.AppSettings[appSettingKey];
				if (this.ArgumentsMap.ContainsKey(argName) && !this.ArgumentsMap[argName].IsSet)
				{
					Trace.TraceInformation("Setting argument {0} to config value {1}", argName, argValue);
					this.ArgumentsMap[argName].SetValue(this.ArgumentsSource, argValue);
				}
				else
				{
					Trace.TraceInformation("Skipping config value {0} as it is an unknown argument.", argName);
				}
			}

			Trace.TraceInformation("Exiting {0}", MethodBase.GetCurrentMethod().Name);
		}

		internal bool VerifyArguments()
		{
			Trace.TraceInformation("Entering {0}", MethodBase.GetCurrentMethod().Name);

			foreach (CommandLineArgument argument in this.ArgumentsMap.Values)
			{
				if (argument.IsRequired && !argument.IsSet)
				{
					Trace.TraceInformation("Exiting {0} with false return value because argument {1} is not set.",
						MethodBase.GetCurrentMethod().Name, argument.Name);
					return false;
				}
			}

			Trace.TraceInformation("Exiting {0} with true return value", MethodBase.GetCurrentMethod().Name);
			return true;
		}

		internal void WriteUsage()
		{
			Trace.TraceInformation("Entering {0}", MethodBase.GetCurrentMethod().Name);

			Console.Out.WriteLine();
			Console.Out.WriteLine("Options:");

			foreach (CommandLineArgument argument in this.Arguments)
			{
				if (!argument.IsHidden)
					Console.Out.WriteLine(argument.ToString());
			}

			Console.Out.WriteLine();
			Console.Out.WriteLine("Example:");
			Console.Out.WriteLine(this.GetSampleUsage());
			Console.Out.WriteLine();

			Trace.TraceInformation("Exiting {0}", MethodBase.GetCurrentMethod().Name);
		}

		private string GetSampleUsage()
		{
			StringBuilder builder = new StringBuilder();
			builder.Append(System.IO.Path.GetFileName(Assembly.GetExecutingAssembly().Location));
			foreach (CommandLineArgument argument in this.Arguments)
			{
				if (!argument.IsHidden && argument.IsRequired && !String.IsNullOrEmpty(argument.SampleUsageValue))
				{
					builder.Append(argument.ToSampleString());
				}
			}
			return CommandLineArgument.WrapLine(builder.ToString());
		}

		/// <summary>
		/// Populates the command line arguments map.
		/// </summary>
		private Dictionary<string, CommandLineArgument> GetPropertyMap()
		{
			Trace.TraceInformation("Entering {0}", MethodBase.GetCurrentMethod().Name);

			Dictionary<string, CommandLineArgument> propertyMap = new Dictionary<string, CommandLineArgument>();

			// Get all instance properties for the represented object.
			PropertyInfo[] properties = this.ArgumentsSource.GetType().GetProperties(
				BindingFlags.Instance | BindingFlags.NonPublic |
				BindingFlags.Public | BindingFlags.SetProperty |
				BindingFlags.GetProperty);

			foreach (PropertyInfo property in properties)
			{
				Trace.TraceInformation("Checking property {0} for command line attribution", property.Name);

				// Check to see if it has the CommandLineArgumentAttribute.
				CommandLineArgumentAttribute attribute = GetCommandLineAttribute(property);
				if (attribute == null)
				{
					Trace.TraceInformation("Skipping property {0} since it does not have command line attribution", property.Name);
					continue;
				}

				// Create a new CommandLineArgument for the property.
				Trace.TraceInformation("Creating CommandLineArgument for Property {0}", property.Name);
				CommandLineArgument argument = new CommandLineArgument(property, attribute);
				this.Arguments.Add(argument);

				CreateMapEntry(propertyMap, property, argument, "shortcut", argument.Shortcut);
				CreateMapEntry(propertyMap, property, argument, "name", argument.Name);
			}

			Trace.TraceInformation("Exiting {0} with PropertyMap length of {1} ",
				MethodBase.GetCurrentMethod().Name, propertyMap.Count);
			return propertyMap;
		}

		private static bool CreateMapEntry(Dictionary<string, CommandLineArgument> propertyMap, PropertyInfo property, CommandLineArgument argument, string type, string value)
		{
			if (!String.IsNullOrEmpty(value))
			{
				if (propertyMap.ContainsKey(value.ToUpperInvariant()))
				{
					throw new ArgumentException("Duplicate Key: " + value, "value");
				}

				Trace.TraceInformation("Property {0} has defined a {1} {2}", property.Name, type, value);
				propertyMap.Add(value.ToUpperInvariant(), argument);
				return true;
			}
			else
			{
				Trace.TraceWarning("Property {0} does not have a {1} defined", property.Name, type);
				return false;
			}
		}

		private static CommandLineArgumentAttribute GetCommandLineAttribute(PropertyInfo property)
		{
			object[] attributes = property.GetCustomAttributes(typeof(CommandLineArgumentAttribute), false);
			if (attributes == null || attributes.Length == 0)
				return null;
			else
			{
				Debug.Assert(attributes.Length == 1);
				return (CommandLineArgumentAttribute)attributes[0];
			}
		}

		private static bool IsArgument(string argument)
		{
			return (argument[0] == CommandLineArgument.ArgumentStartChar);
		}

		private static string GetArgumentName(string argument, out string argumentValue)
		{
			argumentValue = null;
			string argumentName = null;
			if (argument[0] == CommandLineArgument.ArgumentStartChar)
			{
				int separatorPos = argument.IndexOf(CommandLineArgument.ArgumentSeparatorChar);


				if (separatorPos != -1)
				{
					argumentName = argument.Substring(1, separatorPos - 1);
					argumentValue = argument.Substring(separatorPos + 1);
				}
				else
				{
					argumentName = argument.Substring(1);
				}
			}
			// Case-Insensitive argument parsing.
			return argumentName.ToUpperInvariant();
		}
		#endregion
	}
}
