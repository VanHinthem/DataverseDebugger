﻿using System;
using System.Runtime.Serialization;

using Microsoft.Xrm.Sdk;

namespace PluginProfiler.Plugins
{
	/// <summary>
	/// Configuration for the profiler plug-in
	/// </summary>
	[DataContract(Name = "Configuration", Namespace = "")]
	public sealed class ProfilerConfiguration
	{
		#region Plug-in Configuration
		/// <summary>
		/// EntityReference for the PluginAssembly record that is being profiled.
		/// </summary>
		[DataMember]
		public EntityReference AssemblyId { get; set; }

		/// <summary>
		/// Name of the type in the PluginAssembly that is being profiled.
		/// </summary>
		[DataMember]
		public string TypeName { get; set; }

		/// <summary>
		/// EntityReference for the SdkMessageProcessingStep that is being profiled.
		/// </summary>
		[DataMember]
		public EntityReference EventHandler { get; set; }

		/// <summary>
		/// Original name of the Event Handler
		/// </summary>
		[DataMember]
		public string OriginalEventHandlerName { get; set; }

		/// <summary>
		/// Indicates the maximum number of executions before the plug-in is automatically disabled
		/// </summary>
		[DataMember]
		public int? MaxNumberOfExecutions { get; set; }

		/// <summary>
		/// Indicates the key for the session when persisting the data
		/// </summary>
		[DataMember]
		public string PersistenceSessionKey { get; set; }

		/// <summary>
		/// Indicates the configuration for the plug-in that should be used in the case of ContextReplay
		/// </summary>
		[DataMember]
		public string Configuration { get; set; }

		/// <summary>
		/// Id of the Workflow Step
		/// </summary>
		[DataMember]
		public string WorkflowStepId { get; set; }
		#endregion

		#region Reporting Configuration
		/// <summary>
		/// Indicates that the context is being retrieved (no plug-in will be executed)
		/// </summary>
		[DataMember]
		public bool? IsContextReplay { get; set; }

		/// <summary>
		/// Indicates that secure and potentially sensitive information should be included (such as SecureConfiguration)
		/// </summary>
		[DataMember]
		public bool? IncludeSecureInformation { get; set; }

		/// <summary>
		/// Indicates that the profile should be persisted to an entity
		/// </summary>
		[DataMember]
		public bool? IsProfilePersistedToEntity { get; set; }
		#endregion

		#region Methods
		/// <summary>
		/// Deserializes the serialized ProfilerConfiguration into a valid object
		/// </summary>
		/// <param name="configuration">Serialized version of the configuration</param>
		public static ProfilerConfiguration Deserialize(string configuration)
		{
			if (string.IsNullOrWhiteSpace(configuration))
			{
				throw new InvalidPluginExecutionException(ProfilerSharedUtility.DefaultExceptionStatus, "Plug-in must have Configuration set");
			}

			return PartialTrustSerializer.Deserialize<ProfilerConfiguration>(configuration);
		}

		/// <summary>
		/// Serializes the ProfilerConfiguration into a string
		/// </summary>
		public override string ToString()
		{
			return PartialTrustSerializer.Serialize<ProfilerConfiguration>(this);
		}
		#endregion
	}
}
