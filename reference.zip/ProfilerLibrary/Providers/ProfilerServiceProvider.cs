﻿using System;
using System.Collections.Generic;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace PluginProfiler.Library
{
	/// <summary>
	/// IServiceProvider implementation that can be used when setting up the profiler.
	/// </summary>
	public sealed class ProfilerServiceProvider : IServiceProvider
	{
		private readonly Dictionary<Type, object> ServiceList = new Dictionary<Type, object>();

		/// <summary>
		/// Instantiates an instance of the ProfilerServiceProvider
		/// </summary>
		public ProfilerServiceProvider(IExecutionContext context, PluginServicesConfiguration services)
		{
			if (null == services)
			{
				throw new ArgumentNullException("services");
			}

			this.Initialize(context, services.Tracing, services.ServiceFactory, services.ServiceEndpointNotification);
		}

		/// <summary>
		/// Instantiates an instance of the ProfilerServiceProvider
		/// </summary>
		public ProfilerServiceProvider(IExecutionContext context, ITracingService tracing, IOrganizationServiceFactory factory,
			IServiceEndpointNotificationService endpointNotification)
		{
			this.Initialize(context, tracing, factory, endpointNotification);
		}

		#region IServiceProvider Members
		/// <summary>
		/// Retrieves a service of the given type
		/// </summary>
		/// <param name="serviceType">Type of service to be retrieved</param>
		public object GetService(Type serviceType)
		{
			if (null == serviceType)
			{
				throw new ArgumentNullException("serviceType");
			}

			object service;
			if (this.ServiceList.TryGetValue(serviceType, out service))
			{
				return service;
			}

			return null;
		}
		#endregion

		#region Private Methods
		private void Initialize(IExecutionContext context, ITracingService tracing, IOrganizationServiceFactory factory,
			IServiceEndpointNotificationService endpointNotification)
		{
			if (null == context)
			{
				throw new ArgumentNullException("context");
			}
			else if (null == tracing)
			{
				throw new ArgumentNullException("tracing");
			}
			else if (null == factory)
			{
				throw new ArgumentNullException("factory");
			}

			this.ServiceList.Add(typeof(ITracingService), tracing);
			this.ServiceList.Add(typeof(IPluginExecutionContext), context as IPluginExecutionContext);
			this.ServiceList.Add(typeof(IWorkflowContext), context as IWorkflowContext);
			this.ServiceList.Add(typeof(IExecutionContext), context as IExecutionContext);
			this.ServiceList.Add(typeof(IOrganizationServiceFactory), factory);

			if (null != endpointNotification)
			{
				this.ServiceList.Add(typeof(IServiceEndpointNotificationService), endpointNotification);
			}
		}
		#endregion
	}
}