﻿using System;

namespace PluginProfiler.Library.Reporting
{
	/// <summary>
	/// Configuration for the execution report
	/// </summary>
	[Serializable]
	public sealed class ProfilerReportingConfiguration
	{
		/// <summary>
		/// Instantiates an instance of the ProfilerReportingConfiguration class
		/// </summary>
		public ProfilerReportingConfiguration()
			: this(null)
		{
		}

		/// <summary>
		/// Instantiates an instance of the ProfilerReportingConfiguration class
		/// </summary>
		/// <param name="tracing">Tracing that should be used for the profiler</param>
		public ProfilerReportingConfiguration(IProfilerTracingService tracing)
		{
			this.ProfilerTracingService = new ProfilerTracingService(tracing ?? new ProfilerConsoleTracingService());
		}

		#region Properties
		/// <summary>
		/// Tracing service for the profiler itself
		/// </summary>
		public IProfilerTracingService ProfilerTracingService { get; private set; }

		/// <summary>
		/// Indicates that the strong types should be loaded in the app domain
		/// </summary>
		public bool IncludeProxyTypes { get; set; }
		#endregion
	}
}
