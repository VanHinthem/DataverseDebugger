﻿using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;

using Microsoft.Xrm.Sdk;

using PluginProfiler.Plugins.ServiceWrappers;
using System.Collections.Generic;

namespace PluginProfiler.Plugins
{
	/// <summary>
	/// Entry point for the server-side profiler component
	/// </summary>
	public sealed class ProfilerPlugin : ProfilerBase<PluginExecutionContextWrapper>, IPlugin
	{
		/// <summary>
		/// Instantiates an instance of the PluginProfilerPlugin class.
		/// </summary>
		/// <param name="configuration">Serialized version of the ProfilerConfiguration class</param>
		public ProfilerPlugin(string configuration)
			: base(configuration)
		{
		}

		/// <summary>
		/// Executes the profiler plug-in
		/// </summary>
		/// <param name="serviceProvider">IServiceProvider that should be used</param>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes",
			Justification = "Any exception that occurs as part of plug-in execution should be logged to the report.")]
		public void Execute(IServiceProvider serviceProvider)
		{
			// Extract the services from the provider
			Dictionary<Type, object> services = ServiceProviderWrapper.ExtractServices(serviceProvider);
			PluginExecutionContextWrapper pluginContext =
				new PluginExecutionContextWrapper(serviceProvider.GetService<IPluginExecutionContext>());

			// Initialize the profiler
			ProfilerPluginContext context;
			ProfilerPluginReport report = this.InitializeProfiler(services, pluginContext, out context);

			// Execute the Profiler
			this.Execute(pluginContext, context, report, null);
		}

		internal override void ExecuteInternal(Stopwatch watch, ProfilerPluginContext context, ProfilerPluginReport report,
			object inputParameter, ref object result)
		{
			watch.Start();
			this.InitializationContext.Plugin.Execute(context.ServiceProvider);
			watch.Stop();
		}
	}
}
