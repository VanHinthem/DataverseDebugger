﻿namespace Microsoft.Dynamics.ProjectOperations.PluginForge
{
    public interface IConnectionSettings
    {
        string Profile { get; set; }

        string OrganizationUrl { get; set; }

        string FQDNOrgUrl { get; set; }

        string Audience { get; set; }

        string UserPrincipalName { get; set; }

        string Password { get; set; }

        string TenantId { get; set; }

        string SubjectName { get; set; }

        string TestUserPrincipalName { get; set; }

        string TestUserSubjectName { get; set; }

        string TokenCacheStorePath { get; set; }
    }
}
