﻿using System;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace PluginProfiler.Plugins
{
	/// <summary>
	/// Utility that will manages the PluginInitializationContext to ensure that the most up-to-date plug-in has been instantiated.
	/// </summary>
	internal static class PluginLoaderUtility
	{
		/// <summary>
		/// Refreshes the plug-in initialization context using the profiler's configuration and the current context.
		/// </summary>
		/// <param name="factory">IOrganizationServiceFactory for the event handler</param>
		/// <param name="config">Configuration of the profiler plug-in</param>
		/// <param name="currentContext">Current initialization context (can be null)</param>
		/// <returns>Updated PluginInitializationContext</returns>
		public static PluginInitializationContext RefreshPluginInitializationContext(IOrganizationServiceFactory factory,
			ProfilerConfiguration config, PluginInitializationContext currentContext)
		{
			if (null == factory)
			{
				throw new ArgumentNullException("factory");
			}
			else if (config.IsContextReplay.GetValueOrDefault())
			{
				throw new NotSupportedException("The plug-in initialization context cannot be refreshed for ContextExecutions.");
			}

			IOrganizationService service = factory.CreateOrganizationService(null);

			PluginInitializationContext context = RefreshAssembly(service, config, currentContext ?? new PluginInitializationContext());
			if (null != config.EventHandler && "sdkmessageprocessingstep" == config.EventHandler.LogicalName)
			{
				context = RefreshStep(service, config, context);
				context = RefreshSecureConfig(service, context);
			}

			return context;
		}

		#region Private Methods
		private static PluginInitializationContext RefreshAssembly(IOrganizationService service, ProfilerConfiguration config,
			PluginInitializationContext context)
		{
			ColumnSet cols = new ColumnSet("content", "modifiedon");

			Entity assembly;
			if (null == context || DateTime.MinValue == context.AssemblyModifiedDate)
			{
				assembly = service.Retrieve(config.AssemblyId.LogicalName, config.AssemblyId.Id, cols);
			}
			else
			{
				//Only retrieve the entity if the modified date is greater than the last time the entity was retrieved.
				//This reduces the amount of data that has to be retrieved.
				QueryExpression query = new QueryExpression(config.AssemblyId.LogicalName);
				query.Criteria.AddCondition("pluginassemblyid", ConditionOperator.Equal, config.AssemblyId.Id);
				query.Criteria.AddCondition("modifiedon", ConditionOperator.GreaterThan, context.AssemblyModifiedDate);
				query.ColumnSet = cols;

				EntityCollection results = service.RetrieveMultiple(query);
				if (0 == results.Entities.Count)
				{
					return context;
				}

				assembly = results[0];
			}

			context.RefreshAssembly(Convert.FromBase64String(assembly.GetAttributeValue<string>("content")),
				assembly.GetAttributeValue<DateTime?>("modifiedon").GetValueOrDefault());

			return context;
		}

		private static PluginInitializationContext RefreshStep(IOrganizationService service, ProfilerConfiguration config,
			PluginInitializationContext context)
		{
			ColumnSet cols = new ColumnSet("configuration", "modifiedon", "sdkmessageprocessingstepsecureconfigid");

			Entity step;
			if (null == context || DateTime.MinValue == context.StepModifiedDate)
			{
				step = service.Retrieve(config.EventHandler.LogicalName, config.EventHandler.Id, cols);
			}
			else
			{
				//Only retrieve the entity if the modified date is greater than the last time the entity was retrieved.
				//This reduces the amount of data that has to be retrieved.
				QueryExpression query = new QueryExpression(config.EventHandler.LogicalName);
				query.Criteria.AddCondition("sdkmessageprocessingstepid", ConditionOperator.Equal, config.EventHandler.Id);
				query.Criteria.AddCondition("modifiedon", ConditionOperator.GreaterThan, context.StepModifiedDate);
				query.ColumnSet = cols;

				EntityCollection results = service.RetrieveMultiple(query);
				if (0 == results.Entities.Count)
				{
					return context;
				}

				step = results[0];
			}

			context.RefreshStep(step.GetAttributeValue<string>("configuration"),
				step.GetAttributeValue<EntityReference>("sdkmessageprocessingstepsecureconfigid"),
				step.GetAttributeValue<DateTime?>("modifiedon").GetValueOrDefault());

			return context;
		}

		private static PluginInitializationContext RefreshSecureConfig(IOrganizationService service,
			PluginInitializationContext context)
		{
			if (null == context || Guid.Empty == context.SecureConfigurationId)
			{
				return context;
			}

			ColumnSet cols = new ColumnSet("secureconfig", "modifiedon");

			Entity secureConfig;
			if (DateTime.MinValue == context.SecureConfigModifiedDate)
			{
				secureConfig = service.Retrieve("sdkmessageprocessingstepsecureconfig", context.SecureConfigurationId, cols);
			}
			else
			{
				//Only retrieve the entity if the modified date is greater than the last time the entity was retrieved.
				//This reduces the amount of data that has to be retrieved.
				QueryExpression query = new QueryExpression("sdkmessageprocessingstepsecureconfig");
				query.Criteria.AddCondition("sdkmessageprocessingstepsecureconfigid", ConditionOperator.Equal,
					context.SecureConfigurationId);
				query.Criteria.AddCondition("modifiedon", ConditionOperator.GreaterThan, context.SecureConfigModifiedDate);
				query.ColumnSet = cols;

				EntityCollection results = service.RetrieveMultiple(query);
				if (0 == results.Entities.Count)
				{
					return context;
				}

				secureConfig = results[0];
			}

			context.RefreshSecureConfig(secureConfig.GetAttributeValue<string>("secureconfig"),
				secureConfig.GetAttributeValue<DateTime?>("modifiedon").GetValueOrDefault());

			return context;
		}
		#endregion
	}
}
