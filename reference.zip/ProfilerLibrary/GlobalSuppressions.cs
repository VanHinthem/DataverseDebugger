using System.Diagnostics.CodeAnalysis;

//////////////////////////////////////////////////////////////////////////////
// Date: Tuesday, January 27, 2015 10:26:47 AM
// Description: Exclusion Backlog
// User: REDMOND\tobinz
//////////////////////////////////////////////////////////////////////////////

[module: SuppressMessage("Microsoft.Usage", "CA9888:DisposeObjectsCorrectly", Scope = "member", Target = "PluginProfiler.Library.WorkflowXamlUtility.#GetCustomActivityNodes(System.Xml.XmlDocument,System.Xml.XmlNamespaceManager)", MessageId = "steps")]

