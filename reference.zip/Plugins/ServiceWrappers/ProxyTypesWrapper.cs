﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;

namespace PluginProfiler.Plugins.ServiceWrappers
{
	/// <summary>
	/// Simulates the behavior of the ProxyTypesBehavior in a way that can be used in partial trust.
	/// </summary>
	/// <remarks>
	/// This class is used in conjunction with the OrganizationServiceWrapper to simulate the behavior of the ProxyTypesBehavior. The
	/// plug-in infrastructure does not automatically enable strong-types due to the method used to load the actual plug-in. The plug-in
	/// which is being executed is actually the profiler plug-in, which does not have strong types enabled. Another check for strong
	/// types is not performed by the infrastructure when the plug-in under test is loaded. Ideally, the ProxyTypesBehavior class
	/// would be used to serialize the strong-types, but the serialization is outside of the control of the profiler. Therefore,
	/// the types have to be converted to late bound types before being sent to the server and converted back to early-bound types
	/// when it is returned from the server.
	/// </remarks>
	internal sealed class ProxyTypesWrapper
	{
		private readonly Dictionary<string, Type> ProxyTypesList;
		private readonly MethodInfo ToEntityMethod;

		/// <summary>
		/// Instantiates an instance of the class with the given proxy types assembly.
		/// </summary>
		/// <param name="assembly">Assembly that contains the product types</param>
		/// <remarks>
		/// If the given assembly does not contain any proxy types, all calls to this class have no effect.
		/// </remarks>
		public ProxyTypesWrapper(Assembly assembly)
		{
			if (null == assembly)
			{
				throw new ArgumentNullException("assembly");
			}

			// If the assembly that was specified is the profiler assembly, then there is no need to allow strong types on this method
			if (this.GetType().Assembly == assembly)
			{
				this.ProxyTypesList = null;
				this.ToEntityMethod = null;
			}

			ProxyTypesAssemblyAttribute[] assemblyAttributes = (ProxyTypesAssemblyAttribute[])assembly.GetCustomAttributes(
				typeof(ProxyTypesAssemblyAttribute), false);
			if (null == assemblyAttributes || 0 == assemblyAttributes.Length)
			{
				return;
			}

			this.ProxyTypesList = new Dictionary<string, Type>();
			this.ToEntityMethod = typeof(Entity).GetMethod("ToEntity");

			foreach (Type type in assembly.GetExportedTypes())
			{
				EntityLogicalNameAttribute[] attributes = (EntityLogicalNameAttribute[])type.GetCustomAttributes(
					typeof(EntityLogicalNameAttribute), false);
				if (null == attributes || 0 == attributes.Length)
				{
					continue;
				}

				string name = attributes[0].LogicalName;
				if (this.ProxyTypesList.ContainsKey(name))
				{
					throw new ArgumentException(string.Format(CultureInfo.InvariantCulture,
						"A proxy type with the name {0} has been defined by an assembly.", name));
				}

				ProxyTypesList.Add(name, type);
			}
		}

		#region Methods
		/// <summary>
		/// Converts the given value into its early bound equivalent
		/// </summary>
		/// <param name="value">Late bound value that needs to be converted</param>
		/// <returns>Early bound version of the class</returns>
		/// <remarks>
		/// The method will create a copy of the entity to avoid changing the original reference.
		/// </remarks>
		public object ConvertToEarlyBound(object value)
		{
			if (null == this.ProxyTypesList || null == value)
			{
				return value;
			}

			EntityCollection collection = value as EntityCollection;
			if (null != collection)
			{
				return this.ConvertToEarlyBound(collection);
			}

			Entity entity = value as Entity;
			if (null != entity)
			{
				return this.ConvertToEarlyBound(entity);
			}

			ParameterCollection parameters = value as ParameterCollection;
			if (null != parameters)
			{
				return this.ConvertToEarlyBound(parameters);
			}

			return value;
		}

		/// <summary>
		/// Converts the given value into its late bound equivalent
		/// </summary>
		/// <param name="value">Early bound value that needs to be converted</param>
		/// <returns>late bound version of the class</returns>
		/// <remarks>
		/// The method will create a copy of the entity to avoid changing the original reference.
		/// </remarks>
		public object ConvertToLateBound(object value)
		{
			if (null == this.ProxyTypesList || null == value)
			{
				return value;
			}

			EntityCollection collection = value as EntityCollection;
			if (null != collection)
			{
				return this.ConvertToLateBound(collection);
			}

			Entity entity = value as Entity;
			if (null != entity)
			{
				return this.ConvertToLateBound(entity);
			}

			ParameterCollection parameters = value as ParameterCollection;
			if (null != parameters)
			{
				return this.ConvertToLateBound(parameters);
			}

			return value;
		}
		#endregion

		#region Private Methods
		private ParameterCollection ConvertToEarlyBound(ParameterCollection value)
		{
			ParameterCollection collection = new ParameterCollection();
			foreach (KeyValuePair<string, object> pair in value)
			{
				collection.Add(pair.Key, this.ConvertToEarlyBound(pair.Value));
			}

			return collection;
		}

		private ParameterCollection ConvertToLateBound(ParameterCollection value)
		{
			ParameterCollection collection = new ParameterCollection();
			foreach (KeyValuePair<string, object> pair in value)
			{
				collection.Add(pair.Key, this.ConvertToLateBound(pair.Value));
			}

			return collection;
		}

		private EntityCollection ConvertToEarlyBound(EntityCollection value)
		{
			EntityCollection collection = this.CloneCollection(value);

			for (int i = 0; i < value.Entities.Count; i++)
			{
				collection.Entities.Add(this.ConvertToEarlyBound(value[i]));
			}

			return collection;
		}

		private EntityCollection ConvertToLateBound(EntityCollection value)
		{
			EntityCollection collection = this.CloneCollection(value);

			for (int i = 0; i < value.Entities.Count; i++)
			{
				collection.Entities.Add(this.ConvertToLateBound(value[i]));
			}

			return collection;
		}

		private Entity ConvertToEarlyBound(Entity value)
		{
			//Convert the root entity
			Entity entity;
			if (string.IsNullOrWhiteSpace(value.LogicalName))
			{
				entity = value.ToEntity<Entity>();
			}
			else
			{
				Type proxyType;
				if (this.ProxyTypesList.TryGetValue(value.LogicalName, out proxyType))
				{
					entity = (Entity)this.ToEntityMethod.MakeGenericMethod(proxyType).Invoke(value, new object[0]);
				}
				else
				{
					entity = value.ToEntity<Entity>();
				}
			}

			//Convert the related entities
			foreach (KeyValuePair<Relationship, EntityCollection> pair in value.RelatedEntities)
			{
				EntityCollection collection = this.ConvertToEarlyBound(pair.Value);
				entity.RelatedEntities[pair.Key] = collection;
			}

			return entity;
		}

		private Entity ConvertToLateBound(Entity value)
		{
			Entity entity = value.ToEntity<Entity>();
			foreach (KeyValuePair<Relationship, EntityCollection> pair in value.RelatedEntities)
			{
				EntityCollection collection = this.ConvertToLateBound(pair.Value);
				entity.RelatedEntities[pair.Key] = collection;
			}

			return entity;
		}

		private EntityCollection CloneCollection(EntityCollection value)
		{
			return new EntityCollection()
			{
				EntityName = value.EntityName,
				ExtensionData = value.ExtensionData,
				MinActiveRowVersion = value.MinActiveRowVersion,
				MoreRecords = value.MoreRecords,
				PagingCookie = value.PagingCookie,
				TotalRecordCount = value.TotalRecordCount,
				TotalRecordCountLimitExceeded = value.TotalRecordCountLimitExceeded
			};
		}
		#endregion
	}
}
