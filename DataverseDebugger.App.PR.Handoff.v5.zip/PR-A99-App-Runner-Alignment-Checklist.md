# PR-A99 – Final Validation Checklist (App/Runner Alignment)

## Build & Packaging
- [ ] Debug build produces `bin\Debug\net8.0-windows\runner\DataverseDebugger.Runner.exe`
- [ ] Release build produces corresponding `runner\` folder
- [ ] Publish behavior unchanged

## Settings UX
- [ ] Default ExecutionMode is Hybrid
- [ ] Default AllowLiveWrites is false
- [ ] AllowLiveWrites toggle only interactive in Online mode
- [ ] Enabling AllowLiveWrites requires confirmation

## Async Step Safety
- [ ] Enabling AllowLiveWrites disables async steps
- [ ] Disabling AllowLiveWrites re-enables async steps
- [ ] Switching away from Online forces AllowLiveWrites false and re-enables async steps

## Runner Start Configuration
- [ ] Runner receives `DATAVERSE_DEBUGGER_ALLOW_LIVE_WRITES` via env var at process start
- [ ] Runner restarts when AllowLiveWrites changes

## Request Semantics
- [ ] `PluginInvokeRequest.ExecutionMode` is always populated from settings
- [ ] Legacy `WriteMode` remains derived and populated for compatibility
