﻿using System;

namespace PluginProfiler.Debugger
{
	internal static class Program
	{
		[STAThread]
		public static void Main(string[] args)
		{
			PluginDebuggerParameters parameters = new PluginDebuggerParameters();
			parameters.LoadArguments(args);
			if (!parameters.VerifyArguments() || parameters.ShowHelp)
			{
				parameters.ShowUsage();
				return;
			}

			PluginDebugger debugger = new PluginDebugger(parameters);
			debugger.Execute();
		}
	}
}
