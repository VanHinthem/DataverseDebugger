# DataverseDebugger.App — PR Execution Index (Authoritative)

This index defines the **mandatory execution order** for App alignment PRs.

## Execution Order (Do Not Reorder)
1. PR-A01 – ExecutionMode-First App Model
2. PR-A02 – Live Write Safety Gate
3. PR-A03 – Deterministic Runner Copy
4. PR-A04 – Centralized Runner Start Configuration
5. PR-A05 – App Contract Validation

## Rules
- For Each PR, create a feature branch based on the develop branch 
- PRs MUST be executed in order.
- Each PR must compile and pass before starting the next.
- Do not merge PRs.
- Do not skip PRs.

Violation of these rules invalidates the handoff.
