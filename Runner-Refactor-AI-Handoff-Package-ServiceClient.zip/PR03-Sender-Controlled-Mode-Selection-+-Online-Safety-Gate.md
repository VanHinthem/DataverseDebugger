# PR 3 — Sender-Controlled Mode Selection + Online Safety Gate

**Repo:** DataverseDebugger

## Global Non-Negotiables
1. No new external project references; reference ZIPs are conceptual only.
2. Do not refactor WebAPI entry wiring; only add a thin delegation seam when instructed.
3. Single-plugin execution only; no pipeline re-entry simulation.
4. Sender-controlled `ExecutionMode` is authoritative when provided; legacy fallback remains when absent.
5. Keep all changes inside existing `DataverseDebugger.Runner` project (no new projects).
6. Keep diffs minimal and reviewable; avoid opportunistic refactors.
7. Add deterministic errors for guards/NotSupported (include mode + operation + guidance).

## AI Implementation Rules
- Preserve current behavior unless this PR explicitly changes it.
- Maintain backward compatibility for request/response serialization.
- Add tests as specified; do not skip tests.



## Objective
Enable sender-controlled execution mode selection using the new `ExecutionMode` field, while preserving legacy fallback to `WriteMode`. Add Online safety gate, and introduce **ServiceClient-backed live connectivity for plugin debugging**.

## Scope
- Introduce a single resolver function (e.g., `ExecutionModeResolver.Resolve(request)`).
- If `ExecutionMode` is provided, it is authoritative.
- If absent, fall back to legacy mapping: FakeWrites→Hybrid, LiveWrites→Online.
- Do not implement Offline yet; Offline requests should fail deterministically with a clear message (temporary) or return NotSupported.

## Deliverables
### A) Mode resolution
- Parse `ExecutionMode` case-insensitively.
- Validate allowed values; reject invalid values deterministically.

### C) Online safety gate
- **AllowLiveWrites source (locked):** Use the Runner's existing configuration pattern (e.g., environment variable and/or existing config file) with a default of `false`.
- The implementation must not introduce a new configuration framework.

- If resolved mode is Online and `RunnerExecutionOptions.AllowLiveWrites != true`, fail deterministically (prefer RunnerNotSupportedException or a single deterministic guard exception type):
  - message includes: mode=Online, guidance to set AllowLiveWrites=true.

### D) Wire resolution into PluginInvocationEngine
- Engine selects:
  - Hybrid → existing FakeWrites behavior (current RunnerOrganizationService mode)
  - Online → existing LiveWrites behavior (current RunnerOrganizationService mode)
  - Offline → NotSupported (until PR4)

### Tests
- Unit tests:
  - ExecutionMode parsing/validation
  - Legacy fallback mapping when ExecutionMode is absent
  - Online gate blocks unless AllowLiveWrites=true

### Acceptance criteria
- Sender can force Hybrid/Online behavior deterministically
- Online is blocked unless AllowLiveWrites=true
- Legacy clients continue to work via WriteMode fallback

## AI Prompt (copy/paste)
> Implement PR3: add centralized ExecutionMode resolution (case-insensitive Offline/Hybrid/Online), with fallback to WriteMode when absent. Wire it into PluginInvocationEngine so Hybrid uses current FakeWrites behavior and Online uses current LiveWrites behavior. Add an Online safety gate controlled by RunnerExecutionOptions.AllowLiveWrites; fail deterministically when false. Offline may return NotSupported for now. Add unit tests for parsing, fallback, and gating.



### Known limitation (document and test accordingly)
- The Runner uses the sender-provided access token for ServiceClient. Token refresh is not implemented initially; assume a fresh token per execution request.
