﻿using System;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;

using PluginProfiler.Library.Reporting;
using System.Reflection;
using Microsoft.Xrm.Sdk.Messages;
using System.ServiceModel;
using System.Diagnostics.CodeAnalysis;
using System.Security;
using System.Security.Permissions;

namespace PluginProfiler.Library
{
	/// <summary>
	/// IOrganizationService that executes in an AppDomain
	/// </summary>
	internal sealed class ProfilerContextOrganizationService : MarshalByRefObject, IDisposable
	{
		private bool _disposed;
		private readonly OrganizationServiceProxy InnerProxy;
		private readonly ProfilerExecutionReport Report;

		/// <summary>
		/// Instantiates an instance of the AppDomainOrganizationService class.
		/// </summary>
		public ProfilerContextOrganizationService(OrganizationServiceProxy proxy, ProfilerExecutionReport report)
		{
			if (null == proxy)
			{
				throw new ArgumentNullException("proxy");
			}

			this.InnerProxy = proxy;
			this.Report = report;
		}

		#region IDisposable Members
		~ProfilerContextOrganizationService()
		{
			this.Dispose(false);
		}

		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}
		#endregion

		#region IOrganizationService Members
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes",
			Justification = "Message is logged and returned to the user.")]
		public Tuple<Type, string> Associate(Tuple<Type, string> serializedValue, Assembly proxyTypesAssembly)
		{
			//Create the operation
			ProfilerAssociateClientOperation operation = (ProfilerAssociateClientOperation)this.DeserializeRequest(serializedValue,
				proxyTypesAssembly);

			//Add the operation to the report
			this.Report.AddOperation(operation);

			try
			{
				//Execute the operation
				this.InnerProxy.Associate(operation.InputEntityName, operation.InputEntityId,
					operation.InputRelationship, operation.InputRelatedEntities);

				//Return the result
				return this.SerializeResponse(null, proxyTypesAssembly);
			}
			catch (Exception ex)
			{
				//Process the exception and return the result
				return this.SerializeException(ex, operation);
			}
		}

		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes",
			Justification = "Message is logged and returned to the user.")]
		public Tuple<Type, string> Create(Tuple<Type, string> serializedValue, Assembly proxyTypesAssembly)
		{
			//Create the operation
			ProfilerCreateClientOperation operation = (ProfilerCreateClientOperation)this.DeserializeRequest(serializedValue,
				proxyTypesAssembly);

			//Add the operation to the report
			this.Report.AddOperation(operation);

			try
			{
				//Execute the operation
				operation.Output = this.InnerProxy.Create(operation.InputEntity);

				//Return the result
				return this.SerializeResponse(operation.Output, proxyTypesAssembly);
			}
			catch (Exception ex)
			{
				//Process the exception and return the result
				return this.SerializeException(ex, operation);
			}
		}

		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes",
			Justification = "Message is logged and returned to the user.")]
		public Tuple<Type, string> Delete(Tuple<Type, string> serializedValue, Assembly proxyTypesAssembly)
		{
			//Create the operation
			ProfilerDeleteClientOperation operation = (ProfilerDeleteClientOperation)this.DeserializeRequest(serializedValue,
				proxyTypesAssembly);

			//Add the operation to the report
			this.Report.AddOperation(operation);

			try
			{
				//Execute the operation
				this.InnerProxy.Delete(operation.InputEntityName, operation.InputId);

				//Return the result
				return this.SerializeResponse(null, proxyTypesAssembly);
			}
			catch (Exception ex)
			{
				//Process the exception and return the result
				return this.SerializeException(ex, operation);
			}
		}

		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes",
			Justification = "Message is logged and returned to the user.")]
		public Tuple<Type, string> Disassociate(Tuple<Type, string> serializedValue, Assembly proxyTypesAssembly)
		{
			//Create the operation
			ProfilerDisassociateClientOperation operation = (ProfilerDisassociateClientOperation)this.DeserializeRequest(serializedValue,
				proxyTypesAssembly);

			//Add the operation to the report
			this.Report.AddOperation(operation);

			try
			{
				//Execute the operation
				this.InnerProxy.Disassociate(operation.InputEntityName, operation.InputEntityId,
					operation.InputRelationship, operation.InputRelatedEntities);

				//Return the result
				return this.SerializeResponse(null, proxyTypesAssembly);
			}
			catch (Exception ex)
			{
				//Process the exception and return the result
				return this.SerializeException(ex, operation);
			}
		}

		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes",
			Justification = "Message is logged and returned to the user.")]
		public Tuple<Type, string> Execute(Tuple<Type, string> serializedValue, Assembly proxyTypesAssembly)
		{
			//Create the operation
			ProfilerExecuteClientOperation operation = (ProfilerExecuteClientOperation)this.DeserializeRequest(serializedValue,
				proxyTypesAssembly);

			//Add the operation to the report
			this.Report.AddOperation(operation);

			try
			{
				//Execute the operation
				operation.Output = this.InnerProxy.Execute(operation.InputRequest);

				//Return the result
				return this.SerializeResponse(operation.Output, proxyTypesAssembly);
			}
			catch (Exception ex)
			{
				//Process the exception and return the result
				return this.SerializeException(ex, operation);
			}
		}

		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes",
			Justification = "Message is logged and returned to the user.")]
		public Tuple<Type, string> Retrieve(Tuple<Type, string> serializedValue, Assembly proxyTypesAssembly)
		{
			//Create the operation
			ProfilerRetrieveClientOperation operation = (ProfilerRetrieveClientOperation)this.DeserializeRequest(serializedValue,
				proxyTypesAssembly);

			//Add the operation to the report
			this.Report.AddOperation(operation);

			try
			{
				//Execute the operation
				operation.Output = this.InnerProxy.Retrieve(operation.InputEntityName, operation.InputId, operation.InputColumnSet);

				//Return the result
				return this.SerializeResponse(operation.Output, proxyTypesAssembly);
			}
			catch (Exception ex)
			{
				//Process the exception and return the result
				return this.SerializeException(ex, operation);
			}
		}

		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes",
			Justification = "Message is logged and returned to the user.")]
		public Tuple<Type, string> RetrieveMultiple(Tuple<Type, string> serializedValue, Assembly proxyTypesAssembly)
		{
			//Create the operation
			ProfilerRetrieveMultipleClientOperation operation = (ProfilerRetrieveMultipleClientOperation)this.DeserializeRequest(serializedValue,
				proxyTypesAssembly);

			//Add the operation to the report
			this.Report.AddOperation(operation);

			try
			{
				//Execute the operation
				operation.Output = this.InnerProxy.RetrieveMultiple(operation.InputQuery);

				//Return the result
				return this.SerializeResponse(operation.Output, proxyTypesAssembly);
			}
			catch (Exception ex)
			{
				//Process the exception and return the result
				return this.SerializeException(ex, operation);
			}
		}

		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes",
			Justification = "Message is logged and returned to the user.")]
		public Tuple<Type, string> Update(Tuple<Type, string> serializedValue, Assembly proxyTypesAssembly)
		{
			//Create the operation
			ProfilerUpdateClientOperation operation = (ProfilerUpdateClientOperation)this.DeserializeRequest(serializedValue,
				proxyTypesAssembly);

			//Add the operation to the report
			this.Report.AddOperation(operation);

			try
			{
				//Execute the operation
				this.InnerProxy.Update(operation.InputEntity);

				//Return the result
				return this.SerializeResponse(null, proxyTypesAssembly);
			}
			catch (Exception ex)
			{
				//Process the exception and return the result
				return this.SerializeException(ex, operation);
			}
		}
		#endregion

		#region Private Methods
		private ProfilerClientOperationBase DeserializeRequest(Tuple<Type, string> serializedValue, Assembly proxyTypesAssembly)
		{
			if (null == serializedValue)
			{
				throw new ArgumentNullException("serializedValue");
			}

			PermissionSet set = new PermissionSet(PermissionState.Unrestricted);
			set.Assert();

			ProfilerClientOperationBase operation = (ProfilerClientOperationBase)ProfilerSharedUtility.Deserialize(serializedValue.Item1,
				serializedValue.Item2, proxyTypesAssembly);
			if (null == operation)
			{
				throw new ArgumentNullException("serializedValue");
			}

			return operation;
		}

		private Tuple<Type, string> SerializeResponse(object value, Assembly proxyTypesAssembly)
		{
			if (null == value)
			{
				return null;
			}

			// Check if this is a strongly typed entity that is of the wrong data type
			Type valueType = value.GetType();
			if (typeof(Entity) != valueType && typeof(Entity).IsAssignableFrom(valueType) &&
				valueType.Assembly != proxyTypesAssembly)
			{
				value = ((Entity)value).ToEntity<Entity>();
				valueType = typeof(Entity);
			}

			return new Tuple<Type, string>(valueType, ProfilerSharedUtility.Serialize(value.GetType(), value));
		}

		private Tuple<Type, string> SerializeException(Exception ex, ProfilerOrganizationServiceClientOperationBase operation)
		{
			FaultException<OrganizationServiceFault> faultException = ex as FaultException<OrganizationServiceFault>;

			//Convert the exception to a fault
			if (null != faultException)
			{
				operation.Fault = faultException.Detail;
			}
			else
			{
				operation.Fault = ProfilerUtility.ConvertToFault(ex);
			}

			return this.SerializeResponse(operation.Fault, null);
		}

		private void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (!this._disposed)
				{
					this.InnerProxy.Dispose();
					this._disposed = true;
				}
			}
		}
		#endregion
	}
}
