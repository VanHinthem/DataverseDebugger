﻿using System;
using System.Collections.Generic;
using System.ServiceModel;

using PluginProfiler.Plugins;

using Microsoft.Xrm.Sdk;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Implementation of the IServiceEndpointNotificationService interface that plays back to the plug-in code
	/// </summary>
	internal sealed class ProfilerReplayServiceEndpointNotification : ProfilerReplayService<ServiceEndpointNotificationReplayEvent>,
		IServiceEndpointNotificationService
	{
		/// <summary>
		/// Instantiates an instance of the ProfilerReplayServiceEndpointNotification class
		/// </summary>
		/// <param name="events">Events that need to be played back.</param>
		public ProfilerReplayServiceEndpointNotification(Queue<ProfilerReplayEvent> events)
			: base(events)
		{
		}

		#region IServiceEndpointNotificationService Members
		public string Execute(EntityReference serviceEndpoint, IExecutionContext context)
		{
			ServiceEndpointNotificationReplayEvent replayEvent = this.NextEvent();
			if (null == replayEvent.Fault)
			{
				return replayEvent.Result;
			}
			else
			{
				throw new FaultException<OrganizationServiceFault>(replayEvent.Fault);
			}
		}
		#endregion
	}
}
