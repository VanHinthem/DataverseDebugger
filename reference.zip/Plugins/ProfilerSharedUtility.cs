﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.ServiceModel;
using System.Text;

using PluginProfiler.Plugins;

using Microsoft.Xrm.Sdk;

namespace PluginProfiler
{
	/// <summary>
	/// Utility that is shared across the core profiler components
	/// </summary>
	public static class ProfilerSharedUtility
	{
		/// <summary>
		/// Base value for option set values in the profiler entity
		/// </summary>
		internal const int BaseOptionSetValue = 864340000;

		/// <summary>
		/// Default exception status to be returned to the caller.
		/// </summary>
		internal const OperationStatus DefaultExceptionStatus = OperationStatus.Suspended;

		/// <summary>
		/// Default error code to be returned to the caller
		/// </summary>
		public const int DefaultExceptionErrorCode = -2147220891;

		/// <summary>
		/// Prefix for the error message that will be thrown
		/// </summary>
		public const string ProfilerErrorMessagePrefix = "Download the details and load with Plug-in Profiler.\r\n";

		/// <summary>
		/// Prefix for the error message that will be thrown
		/// </summary>
		public const char ProfilerErrorMessageSeparator = '|';

		/// <summary>
		/// Format for the message that will be thrown
		/// </summary>
		internal const string ProfilerErrorMessageFormat = ProfilerErrorMessagePrefix + "|{0}|";

		/// <summary>
		/// Logical Name for the Plug-in Profiler
		/// </summary>
		public const string ProfilerEntityLogicalName = "mbs_pluginprofile";

		/// <summary>
		/// XML Declaration that should be added to serialized XML documents
		/// </summary>
		internal const string XmlDocumentDeclaration = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>";

		/// <summary>
		/// Converts an Exception into a string representation
		/// </summary>
		/// <param name="ex">Exception to be converted</param>
		public static string ConvertExceptionToString(Exception ex)
		{
			if (null == ex)
			{
				return "NULL";
			}

			//Create an exception builder
			StringBuilder builder = new StringBuilder(1024);

			//Set the prefix that will be output
			string prefix = "Unhandled ";

			//Set the exception to be the current exception
			Exception currentException = ex;
			while (null != currentException)
			{
				//Append the prefix and the exception's type
				builder.AppendFormat(
					CultureInfo.InvariantCulture,
					"{0}Exception: {1}",
					prefix,
					currentException.GetType().FullName);

				//Check if the message is set. If so, output it
				if (currentException.Message.Length > 0)
				{
					builder.AppendFormat(
						CultureInfo.InvariantCulture,
						": {0}",
						currentException.Message);
				}

				//Add a new line
				builder.Append(Environment.NewLine);

				FaultException<OrganizationServiceFault> fault = ex as FaultException<OrganizationServiceFault>;
				if (null != fault)
				{
					builder.AppendLine(PartialTrustSerializer.Serialize(fault.Detail));
				}

				//Append the stack trace of the current exception
				builder.AppendLine(currentException.StackTrace);

				//Update the prefix
				prefix = "Inner ";

				//Process the inner exception
				currentException = currentException.InnerException;
			}

			//Return the output
			return builder.ToString();
		}

		/// <summary>
		/// Compresses a string
		/// </summary>
		/// <param name="data">Data to be compressed.</param>
		[SuppressMessage("Microsoft.Usage", "CA2202:Do not dispose objects multiple times",
			Justification = "Stream must be closed explicitly to ensure that all of the data has been properly flushed.")]
		public static string Compress(string data)
		{
			if (string.IsNullOrWhiteSpace(data))
			{
				return null;
			}

			byte[] decompressedData = Encoding.UTF8.GetBytes(data);

			using (MemoryStream memoryStreamCompressed = new MemoryStream())
			{
				using (DeflateStream deflateStream = new DeflateStream(memoryStreamCompressed, CompressionMode.Compress, true))
				{
					deflateStream.Write(decompressedData, 0, decompressedData.Length);

					//If Close is not called after the call to Flush, not all of the data is flushed to the memory stream.
					deflateStream.Flush();
					deflateStream.Close();

					return Convert.ToBase64String(memoryStreamCompressed.ToArray());
				}
			}
		}

		/// <summary>
		/// Decompresses a string into a stream of UTF-8 encoded bytes.
		/// </summary>
		/// <param name="data">Data to be decompressed.</param>
		[SuppressMessage("Microsoft.Usage", "CA2202:Do not dispose objects multiple times",
			Justification = "These stream classes can be disposed multiple times. The current implementation is required in order to ensure that the class is always disposed.")]
		public static byte[] Decompress(string data)
		{
			if (string.IsNullOrWhiteSpace(data))
			{
				return null;
			}

			byte[] compressedData = Convert.FromBase64String(data);

			// Decompress
			using (MemoryStream memoryStreamCompressed = new MemoryStream(compressedData))
			{
				using (DeflateStream deflateStream = new DeflateStream(memoryStreamCompressed, CompressionMode.Decompress, false))
				{
					byte[] buffer = new byte[4096];
					using (MemoryStream memoryStreamDecompressed = new MemoryStream())
					{
						while (true)
						{
							int readBytes = deflateStream.Read(buffer, 0, buffer.Length);
							if (readBytes <= 0)
							{
								return memoryStreamDecompressed.ToArray();
							}

							memoryStreamDecompressed.Write(buffer, 0, readBytes);
						}
					}
				}
			}
		}

		/// <summary>
		/// Serializes the string
		/// </summary>
		public static string Serialize(Type type, object value)
		{
			return PartialTrustSerializer.Serialize(type, value);
		}

		/// <summary>
		/// Deserializes the string
		/// </summary>
		public static object Deserialize(Type type, string value, Assembly proxyTypesAssembly)
		{
			return PartialTrustSerializer.Deserialize(type, value, proxyTypesAssembly);
		}
	}
}
