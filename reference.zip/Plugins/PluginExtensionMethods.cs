﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace PluginProfiler.Plugins
{
	/// <summary>
	/// Extension Methods for the IServiceProvider interface
	/// </summary>
	public static class ServiceProviderExtensions
	{
		/// <summary>
		/// Gets the service object of the specified type.
		/// </summary>
		/// <typeparam name="T">A parameter that specifies the type of service object to get.</typeparam>
		/// <param name="provider">A provider object that will provide the desired service.</param>
		/// <returns>A service object of type serviceType.-or- null if there is no service object of type serviceType.</returns>
		public static T GetService<T>(this IServiceProvider provider)
		{
			if (null == provider)
			{
				throw new ArgumentNullException("provider");
			}

			return (T)provider.GetService(typeof(T));
		}
	}
}