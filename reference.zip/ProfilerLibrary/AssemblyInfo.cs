﻿using System;
using System.Diagnostics.CodeAnalysis;


//Namespace FxCop suppressions
[module: SuppressMessage("Microsoft.MSInternal", "CA904:DeclareTypesInMicrosoftOrSystemNamespace",
	Scope = "namespace", Target = "PluginProfiler", Justification = "Namespace follows the same standard as the PluginRegistrationTool.")]
[module: SuppressMessage("Microsoft.MSInternal", "CA904:DeclareTypesInMicrosoftOrSystemNamespace",
	Scope = "namespace", Target = "PluginProfiler.Library", Justification = "Namespace follows the same standard as the PluginRegistrationTool.")]
[module: SuppressMessage("Microsoft.MSInternal", "CA904:DeclareTypesInMicrosoftOrSystemNamespace",
	Scope = "namespace", Target = "PluginProfiler.Library.Reporting", Justification = "Namespace follows the same standard as the PluginRegistrationTool.")]