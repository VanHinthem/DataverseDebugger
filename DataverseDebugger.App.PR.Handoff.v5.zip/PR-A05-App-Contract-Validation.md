# PR-A05 – App Contract Validation & Drift Prevention

## Objective
Prove that the App is a thin host and does not implement execution semantics.

## Invariants
- No functional behavior changes beyond guardrails and documentation.
- No Runner changes.

## Required Validation
The App may:
- Collect inputs, persist settings, start/stop Runner, and display results.
The App must NOT:
- Implement Offline/Hybrid/Online semantics (overlay/merge/whitelists/etc.)
- Decide request allowance beyond UX confirmation

## Acceptance Criteria
- ExecutionMode and AllowLiveWrites are used only for:
  - UI gating
  - Runner process start configuration (AllowLiveWrites env var)
  - request field population (ExecutionMode)
  - Runner restart triggers (AllowLiveWrites change)
- No semantic duplication exists in request construction beyond setting ExecutionMode/WriteMode fields.
