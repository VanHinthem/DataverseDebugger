﻿using System;
using System.Text;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using PluginProfiler.Library;

namespace PluginProfiler.Debugger
{
	/// <summary>
	/// Base class for an operation type to be handled by the Profiler
	/// </summary>
	internal abstract class OperationHandlerBase
	{
		private EntityReference _id;

		#region Constructors
		protected OperationHandlerBase(string assemblyFilePath, string typeName, string profilePath, bool persistToEntity,
			string persistenceSessionKey, bool excludeSecureInformation, EntityReference id, string name)
		{
			if ((null == id || Guid.Empty == id.Id) && string.IsNullOrWhiteSpace(name))
			{
				throw new ArgumentNullException("id", "Id or Name must be set.");
			}

			this.AssemblyFilePath = assemblyFilePath;
			this.TypeName = typeName;
			this.ProfilePath = profilePath;
			this.PersistToEntity = persistToEntity;
			this.PersistenceSessionKey = persistenceSessionKey;
			this.ExcludeSecureInformation = excludeSecureInformation;
			this._id = id;
			this.Name = name;
		}
		#endregion

		#region Methods
		/// <summary>
		/// Retrieves the application configuration
		/// </summary>
		internal abstract OperationConfiguration GetOperationConfiguration();

		/// <summary>
		/// Enables profiling on the operation
		/// </summary>
		/// <param name="service">Service that should be used to enable the profiler.</param>
		/// <returns>Id for the profiled version of the operation</returns>
		internal abstract Guid Enable(IOrganizationService service);

		/// <summary>
		/// Enables profiling on the operation
		/// </summary>
		/// <param name="service">Service that should be used to disable the profiler.</param>
		internal abstract void Disable(IOrganizationService service);

		/// <summary>
		/// Lists steps that exist for the current operation
		/// </summary>
		/// <param name="service">Service that should be used to list steps.</param>
		internal abstract string ListSteps(IOrganizationService service);

		/// <summary>
		/// Generates a query for debugger operations based on the operation type
		/// </summary>
		/// <param name="operation">Operation that will be executed by the debugger</param>
		/// <returns>QueryExpression that will retrieve existing operations</returns>
		internal abstract QueryBase GenerateNameQuery(DebuggerOperation operation);

		/// <summary>
		/// Validate the operation's parameters
		/// </summary>
		/// <param name="operation">Operation to be executed</param>
		/// <param name="errors">Errors that should be returned</param>
		/// <returns>True if the validation succeeded</returns>
		internal abstract bool Validate(DebuggerOperation operation, StringBuilder errors);
		#endregion

		#region Properties
		/// <summary>
		/// Path to the assembly
		/// </summary>
		protected string AssemblyFilePath { get; private set; }

		/// <summary>
		/// Name of the type
		/// </summary>
		protected string TypeName { get; private set; }

		/// <summary>
		/// Path to the profile
		/// </summary>
		protected string ProfilePath { get; private set; }

		/// <summary>
		/// Indicates that the profile should be persisted to an entity
		/// </summary>
		protected bool PersistToEntity { get; private set; }

		/// <summary>
		/// Key to be used when persisting the profile to an entity
		/// </summary>
		protected string PersistenceSessionKey { get; private set; }

		/// <summary>
		/// Excludes secure information from the profile
		/// </summary>
		protected bool ExcludeSecureInformation { get; private set; }

		/// <summary>
		/// Operation Id
		/// </summary>
		internal EntityReference Id
		{
			get
			{
				return this._id;
			}

			set
			{
				if (null == value)
				{
					throw new ArgumentNullException("value");
				}

				this._id = value;
			}
		}

		/// <summary>
		/// Operation Name (optional)
		/// </summary>
		internal string Name { get; private set; }

		/// <summary>
		/// Plural Name for the record type
		/// </summary>
		internal abstract string PluralRecordName { get; }
		#endregion
	}
}
