# PR-A02 – Live Write Safety Gate

## Objective
Expose explicit AllowLiveWrites gate.

## Invariants
- Default safe.
- Explicit opt-in.

## Illegal Changes
- Silent enabling
- Safety bypass
