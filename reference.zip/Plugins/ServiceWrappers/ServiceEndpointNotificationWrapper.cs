﻿using System;
using System.Diagnostics;
using System.ServiceModel;

using Microsoft.Xrm.Sdk;

namespace PluginProfiler.Plugins.ServiceWrappers
{
	/// <summary>
	/// Wrapper for the IServiceEndpointNotificationService provided by the IOrganizationServiceFactory during execution of a plug-in.
	/// </summary>
	internal sealed class ServiceEndpointNotificationWrapper : ServiceWrapperBase<IServiceEndpointNotificationService>, IServiceEndpointNotificationService
	{
		/// <summary>
		/// Instantiates an instance of the ServiceEndpointNotificationWrapper
		/// </summary>
		/// <param name="service">Actual service provided by the original IServiceProvider instance.</param>
		/// <param name="context">Context for execution in the plug-in profiler.</param>
		public ServiceEndpointNotificationWrapper(IServiceEndpointNotificationService service, ProfilerPluginContext context)
			: base(service, context)
		{
		}

		#region IServiceEndpointNotificationService Members
		public string Execute(EntityReference serviceEndpoint, IExecutionContext context)
		{
			if (null == serviceEndpoint)
			{
				throw new ArgumentNullException("serviceEndpoint");
			}

			//Ensure that the context being sent is not a wrapper around the actual context
			ExecutionContextWrapper contextWrapper = context as ExecutionContextWrapper;
			if (null != contextWrapper)
			{
				context = contextWrapper.InnerContext;
			}

			Stopwatch watch = new Stopwatch();
			try
			{
				watch.Start();
				string result = this.InternalService.Execute(serviceEndpoint, context);
				watch.Stop();

				this.AddSuccessReplayEvent(watch, result);

				return result;
			}
			catch (Exception ex)
			{
				watch.Stop();

				this.AddExceptionReplayEvent(watch, ex);
				throw;
			}
		}
		#endregion

		#region Private Methods
		private void AddSuccessReplayEvent(Stopwatch watch, string result)
		{
			this.Context.Report.AddReplayEvent(new ServiceEndpointNotificationReplayEvent(result, watch.Elapsed));
		}

		private void AddExceptionReplayEvent(Stopwatch watch, Exception exception)
		{
			FaultException<OrganizationServiceFault> ex = exception as FaultException<OrganizationServiceFault>;
			if (null != ex)
			{
				this.Context.Report.AddReplayEvent(new ServiceEndpointNotificationReplayEvent(ex.Detail, watch.Elapsed));
				return;
			}

			this.Context.Report.AddReplayEvent(new ServiceEndpointNotificationReplayEvent(
				new OrganizationServiceFault() { Message = exception.GetType().FullName + ": " + exception.Message },
				watch.Elapsed));
		}
		#endregion
	}
}
