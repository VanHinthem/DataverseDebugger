﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.ServiceModel.Description;

using Microsoft.Crm.Sdk.Messages;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System.Diagnostics.CodeAnalysis;
using PluginProfiler.Library.Reporting;
using System.Security;
using System.Security.Permissions;

namespace PluginProfiler.Library
{
	/// <summary>
	/// IOrganizationServiceFactory that connects back to the server for any given user.
	/// </summary>
	[Serializable]
	public sealed class ProfilerContextOrganizationServiceFactory : MarshalByRefObject, IDisposable
	{
		private readonly Dictionary<Guid, ProfilerContextOrganizationService> ProxyList = new Dictionary<Guid, ProfilerContextOrganizationService>();

		/// <summary>
		/// Instantiates an instance of the ProfilerOrganizationServiceFactory class.
		/// </summary>
		/// <param name="administratorProxy">Proxy for a user that has permissions to impersonate any user in the organization.</param>
		public ProfilerContextOrganizationServiceFactory(OrganizationServiceProxy administratorProxy)
		{
			if (null == administratorProxy)
			{
				throw new ArgumentNullException("administratorProxy");
			}

			//This call must occur first in order to ensure that authentication is setup correctly before using this as a template
			this.AdministratorUserId = ((WhoAmIResponse)administratorProxy.Execute(new WhoAmIRequest())).UserId;
			this.ServiceConfiguration = administratorProxy.ServiceConfiguration;

			//The user token won't be set in the case of non-claims AD and Outlook offline. In all other cases,
			//the UserToken will be set.
			if (null == administratorProxy.SecurityTokenResponse)
			{
				this.UserCredentials = administratorProxy.ClientCredentials;
			}
			else
			{
				this.UserToken = administratorProxy.SecurityTokenResponse;
			}
		}

		#region IDisposable Members
		~ProfilerContextOrganizationServiceFactory()
		{
			this.Dispose(false);
		}

		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}
		#endregion

		#region Methods
		[SuppressMessage("Microsoft.Usage", "CA9888:DisposeObjectsCorrectly", MessageId = "domainProxy",
			Justification = "Returned to user. In the case of an error it is disposed properly.")]
		[SuppressMessage("Microsoft.Usage", "CA9888:DisposeObjectsCorrectly", MessageId = "proxy",
			Justification = "Returned to user. In the case of an error it is disposed properly.")]
		internal ProfilerContextOrganizationService CreateProxy(ProfilerExecutionReport report, Guid userId)
		{
			if (Guid.Empty == userId)
			{
				throw new ArgumentNullException("userId");
			}

			ProfilerContextOrganizationService domainProxy;
			if (this.ProxyList.TryGetValue(userId, out domainProxy))
			{
				return domainProxy;
			}

			PermissionSet set = new PermissionSet(PermissionState.Unrestricted);
			set.Assert();

			OrganizationServiceProxy proxy;
			try
			{
				if (null == this.UserToken)
				{
					proxy = new OrganizationServiceProxy(this.ServiceConfiguration, this.UserCredentials);
				}
				else
				{
					proxy = new OrganizationServiceProxy(this.ServiceConfiguration, this.UserToken);
				}

				if (this.AdministratorUserId != userId)
				{
					proxy.CallerId = userId;
				}
			}
			finally
			{
				CodeAccessPermission.RevertAssert();
			}

			domainProxy = new ProfilerContextOrganizationService(proxy, report);
			ProxyList[userId] = domainProxy;
			return domainProxy;
		}
		#endregion

		#region Properties
		internal Guid AdministratorUserId { get; private set; }

		private IServiceConfiguration<IOrganizationService> ServiceConfiguration { get; set; }
		private SecurityTokenResponse UserToken { get; set; }
		private ClientCredentials UserCredentials { get; set; }
		#endregion

		#region Private Methods
		private void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (null != this.ProxyList)
				{
					lock (this.ProxyList)
					{
						foreach (ProfilerContextOrganizationService proxy in this.ProxyList.Values)
						{
							proxy.Dispose();
						}
						this.ProxyList.Clear();
					}
				}
			}
		}
		#endregion
	}
}
