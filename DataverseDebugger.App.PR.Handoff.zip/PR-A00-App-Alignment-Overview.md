# PR-A00 – DataverseDebugger.App Alignment Overview

## Purpose
Align DataverseDebugger.App with Runner PR01–PR06.

## Invariants (Non-Negotiable)
- Preserve existing behavior unless explicitly changed.
- App must not contain execution semantics.
- Runner is sole authority for execution.

## Illegal Changes
- Adding execution logic to App
- Inferring safety or mode behavior
- Modifying Runner or protocol contracts

## PR Series
See PR-A-INDEX.md
