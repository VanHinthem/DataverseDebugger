﻿using System;
using System.Collections.Generic;
using System.Reflection;

using Microsoft.Xrm.Sdk;
using PluginProfiler.Plugins;
using PluginProfiler.Plugins.ServiceWrappers;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Deserialized version of the Profiler report
	/// </summary>
	internal sealed class DeserializedProfilerReport
	{
		#region Constructors
		internal DeserializedProfilerReport(string serializedReport, Assembly pluginAssembly)
		{
			if (string.IsNullOrWhiteSpace(serializedReport))
			{
				throw new ArgumentNullException("serializedReport");
			}

			this.SerializedReport = serializedReport;
			this.PluginAssembly = pluginAssembly;

			this.Report = ProfilerPluginReport.Deserialize(serializedReport, pluginAssembly);
			if (null != pluginAssembly)
			{
				this.ProxyTypesAssembly = ProfilerUtility.GetProxyTypesAssembly(pluginAssembly);
			}
		}
		#endregion

		#region Properties
		public ProfilerPluginReport Report { get; private set; }

		public string SerializedReport { get; private set; }

		public Assembly PluginAssembly { get; private set; }

		public Assembly ProxyTypesAssembly { get; private set; }
		#endregion
	}
}
