# Unified Plugin Execution Refactoring Plan  
**Runner-First, Reference-Inspired, Sender-Controlled Execution Modes**

---

## 1. Purpose and Scope

This document defines a **step-by-step refactoring and extension plan** to unify plugin execution in **DataverseDebugger.Runner**, based on:

- the **existing Runner project** (as primary implementation)
- **reference projects** used strictly as conceptual inspiration
- **no new external project dependencies**
- **explicit execution modes controlled by the sender**

The goal is to produce a **deterministic, testable, maintainable execution engine** that supports:

- Offline execution  
- Hybrid execution (live reads, cached writes)  
- Online execution (live reads + writes)  

across multiple **entry mechanisms** (WebAPI entry, Profiler entry), without turning the runner into a full Dataverse pipeline emulator.

---

## 2. Non-Negotiable Rules

### 2.1 Runner-First Rule
The existing Runner project is the **primary source of truth**.

- Existing working behavior must be preserved unless explicitly changed by this document.
- Refactoring must be **incremental** and **behavior-preserving by default**.

### 2.2 Reference Projects Rule
Reference projects may be used only to:
- understand concepts
- inspire structure
- identify missing responsibilities

They must **never** be referenced, linked, or depended upon.

All resulting code must be **runner-owned** and **re-expressed**.

### 2.3 WebAPI Entry Protection Rule
The WebAPI entry mechanism (request parsing, transport, wiring) is production-critical.

- It must **not** be refactored internally.
- It may delegate to the unified execution pipeline via a **thin adapter** only.

### 2.4 Sender-Controlled Execution Mode Rule
Execution mode is **explicitly chosen by the sender**.

- The runner must **not infer execution mode** from environment state if the sender specifies it.
- Legacy behavior remains only as a fallback when `ExecutionMode` is not provided.

### 2.5 Single Plugin Execution Rule
The runner executes **exactly one plugin per run**.

- No pipeline re-entry simulation  
- No cascading plugin execution  
- `Depth` is exposed but not auto-incremented  

### 2.6 Testability Rule
No behavior is considered correct unless it is testable.

- Every new execution mode or rule must be covered by unit and/or integration tests.

---

## 3. Conceptual Model

### 3.1 Entry Mechanisms

#### WebAPI Entry
- Inputs originate from WebAPI request data  
- Existing wiring remains unchanged  
- Delegates to unified pipeline via adapter  

#### Profiler Entry
- Inputs originate from profiler replay data  
- Delegates to unified pipeline  

### 3.2 Execution Modes

#### Offline
- No live connectivity permitted  
- All reads and writes simulated in memory  

#### Hybrid
- Live reads permitted  
- Writes intercepted and cached  
- Reads reflect cached changes  
- Live used only to fill missing requested attributes  

#### Online
- Live reads and live writes permitted  
- Full real-environment impact  
- Requires explicit runner opt-in  

### 3.3 Supported Combinations

| Entry Mechanism | Offline | Hybrid | Online |
|----------------|---------|--------|--------|
| WebAPI Entry   | Yes     | Yes    | Yes    |
| Profiler Entry | Yes     | Yes    | Yes    |

---

## 4. Protocol and Execution Mode Resolution

### 4.1 ExecutionMode (Sender Responsibility)

A new optional request field:

```
ExecutionMode: "Offline" | "Hybrid" | "Online"
```

- Case-insensitive  
- If present, authoritative  
- If absent, legacy `WriteMode` fallback applies  

### 4.2 Legacy Fallback
- `FakeWrites` → Hybrid  
- `LiveWrites` → Online  

---

## 5. Global Execution Policies

### 5.1 Write Semantics
Offline and Hybrid writes:
- Applied immediately to cache  
- No rollback  
- Cache discarded after execution  

### 5.2 Stage Handling
- Stage exposed via context  
- No Dataverse rules enforced  

### 5.3 Online Safety Gate
Online execution requires:

```
AllowLiveWrites = true
```

Otherwise execution fails deterministically.

---

## 6. Step-by-Step Refactoring Plan

### Step 1 — Extract Unified Invocation Engine
Extract plugin execution logic into a reusable internal engine.

**AI Prompt:**  
> Extract the plugin execution logic into a runner-internal PluginInvocationEngine. Preserve behavior exactly. Entry mechanisms must delegate without refactor.

---

### Step 2 — Introduce ExecutionMode
Add sender-controlled execution mode with fallback.

**AI Prompt:**  
> Add ExecutionMode to the request contract. Prefer it over WriteMode. Preserve legacy behavior when absent.

---

### Step 3 — Implement Offline Mode
Create a deterministic offline organization service.

**Rules:**
- No live access  
- CRUD + RetrieveMultiple  
- Execute supports WhoAmI only  

**AI Prompt:**  
> Implement OfflineOrganizationService with in-memory store and WhoAmI-only Execute support.

---

### Step 4 — Fix Hybrid Mode
Correct overlay, merge, and Execute semantics.

**AI Prompt:**  
> Implement true Hybrid semantics: cached writes, live reads, cache-prevails merge, strict Execute whitelist.

---

### Step 5 — Formalize Online Mode
Allow live writes only when explicitly enabled.

**AI Prompt:**  
> Enforce Online mode with AllowLiveWrites guard and live write support.

---

### Step 6 — Unify Service Resolution
Centralize IServiceProvider creation.

**AI Prompt:**  
> Implement a runner-internal service provider factory resolving services consistently per execution mode.

---

### Step 7 — Logging and Tracing
Unify logging across all paths.

**AI Prompt:**  
> Route all traces and logs through a runner-internal, execution-scoped logger.

---

### Step 8 — Validation and Regression
Prove correctness and preserve behavior.

**AI Prompt:**  
> Add integration and regression tests validating all entry + execution mode combinations.

---

## Appendix A — Determinism and Safety

### Entity Cloning
All cached entities must be deep-cloned on store and return.

### ColumnSet Merge Rules
Live fill respects requested ColumnSet only.

### Standardized NotSupported Errors
Errors must include execution mode, request type, and guidance.

### Correlation
CorrelationId always present; time abstractions required if introduced.

---

## End of Document


---

## Live Connectivity Strategy for Debugging

### Debug execution uses ServiceClient (full-fidelity IOrganizationService)
For **all plugin debugging execution paths** (WebAPI Entry executing the pipeline and Profiler Entry replay), any mode that is allowed to touch the live environment must use a **full-fidelity live `IOrganizationService` backed by `Microsoft.PowerPlatform.Dataverse.Client.ServiceClient`**.

- **Online:** `IOrganizationService = ServiceClient` (direct live reads + writes, gated)
- **Hybrid:** `IOrganizationService = HybridOrganizationService(inner = ServiceClient)` (live reads only, cached writes)
- **Offline:** no live connectivity; `IOrganizationService = OfflineOrganizationService`

### Web API pass-through is host routing (out of scope of unified pipeline)
The host (`DataverseDebugger.App`) decides **Proxy vs Emulate** routing. “Proxy/pass-through” Web API requests are not part of the unified plugin execution pipeline; they remain a separate route and may continue to use HTTP Web API forwarding with the host-forwarded bearer token.

This refactor focuses on **debug plugin execution** and its `IOrganizationService` behavior.
