﻿using System;
using System.Activities;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

using Microsoft.CSharp;

using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;

using PluginProfiler.Plugins;

using CrmSdk;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Utility for generating code for the profiler
	/// </summary>
	[SuppressMessage("Microsoft.Maintainability", "CA1506:AvoidExcessiveClassCoupling",
		Justification = "Excessive coupling is due to CodeDom classes that are in use.")]
	internal static class ProfilerCodeGenerationUtility
	{
		public const string ProfilerConfigurationPropertyName = "WorkflowActivityProfilerConfigurationProperty";

		private static readonly string[] ReferencedAssemblies;

		static ProfilerCodeGenerationUtility()
		{
			ReferencedAssemblies = new string[]
			{
				typeof(AssignRequest).Assembly.Location,
				typeof(Entity).Assembly.Location,
				typeof(InputAttribute).Assembly.Location,
				"System.dll",
				"System.Activities.dll",
				"System.Runtime.Serialization.dll",
				"System.Xml.dll"
			};
		}

		/// <summary>
		/// Builds a wrapper activity for the provided type
		/// </summary>
		/// <param name="configuration">Configuration for the compiler</param>
		internal static CompiledAssembly CompileInstrumentedActivities(ActivityAssemblyCompilerConfiguration configuration)
		{
			if (null == configuration)
			{
				throw new ArgumentNullException("configuration");
			}

			CodeCompileUnit unit = new CodeCompileUnit();
			Dictionary<string, CodeNamespace> namespaces = new Dictionary<string, CodeNamespace>();
			foreach (ActivityTypeCompilerConfiguration type in configuration.Types.Values)
			{
				// Create the instrumented activity
				CodeTypeDeclaration activity = CreateInstrumentedActivity(type);

				// Assign the object to a namespace
				CodeNamespace ns;
				if (!namespaces.TryGetValue(type.Namespace ?? string.Empty, out ns))
				{
					ns = new CodeNamespace(type.Namespace ?? string.Empty);
					namespaces[ns.Name] = ns;

					unit.Namespaces.Add(ns);
				}

				ns.Types.Add(activity);
			}

			// Retrieve the properties from the assembly
			CreateAssemblyAttributes(unit.AssemblyCustomAttributes, configuration);

			// Compile the assembly
			return CompileAssembly(unit, configuration.KeyFileName, configuration.AssemblyName);
		}

		/// <summary>
		/// Retrieves the assembly version information from the specified assembly
		/// </summary>
		/// <param name="assembly">Assembly that contains the version information</param>
		/// <returns>Tuple with values: Assembly Version, File Version, Culture</returns>
		internal static Tuple<string, string, string> GetAssemblyVersionAndCulture(Assembly assembly)
		{
			if (null == assembly)
			{
				throw new ArgumentNullException("assembly");
			}

			// Retrieve the assembly version
			string version = assembly.GetName().Version.ToString();

			// Loop through the assembly and extract the version
			string fileVersion = null;
			string culture = null;
			foreach (Attribute attribute in assembly.GetCustomAttributes(false))
			{
				#region AssemblyFileVersionAttribute
				{
					AssemblyFileVersionAttribute castAttribute = attribute as AssemblyFileVersionAttribute;
					if (null != castAttribute)
					{
						fileVersion = castAttribute.Version;
						continue;
					}
				}
				#endregion

				#region AssemblyCultureAttribute
				{
					AssemblyCultureAttribute castAttribute = attribute as AssemblyCultureAttribute;
					if (null != castAttribute)
					{
						culture = castAttribute.Culture;
						continue;
					}
				}
				#endregion
			}

			return new Tuple<string, string, string>(version, fileVersion, culture);
		}

		#region Private Methods
		private static CodeTypeDeclaration CreateInstrumentedActivity(ActivityTypeCompilerConfiguration configuration)
		{
			if (null == configuration)
			{
				throw new ArgumentNullException("configuration");
			}

			// Create the new activity class
			CodeTypeDeclaration newActivity = new CodeTypeDeclaration(configuration.TypeName);
			newActivity.BaseTypes.Add(new CodeTypeReference(typeof(CodeActivity)));
			newActivity.IsClass = true;
			newActivity.Attributes = MemberAttributes.Final | MemberAttributes.Public;

			// Retrieve the properties from the type
			Collection<string> inputProperties = new Collection<string>();
			Collection<string> outputProperties = new Collection<string>();
			foreach (PropertyInfo property in configuration.Type.GetProperties(BindingFlags.Public | BindingFlags.Instance))
			{
				CodeMemberProperty newProperty = CreateInputOutputProperty(newActivity, property, inputProperties, outputProperties);
				if (null == newProperty)
				{
					continue;
				}

				newActivity.Members.Add(newProperty);
			}

			// Add the profiler configuration input
			newActivity.Members.Add(CreateProfilerConfigurationProperty(newActivity));

			// Add the override for the Execute statement
			newActivity.Members.Add(CreateActivityExecuteMethod(inputProperties, outputProperties));

			return newActivity;
		}

		private static CodeMemberProperty CreateProfilerConfigurationProperty(CodeTypeDeclaration activity)
		{
			bool isInputParameter, isOutputParameter;
			CodeAttributeDeclarationCollection attributes = CreateWorkflowAttributes(
				new Attribute[] { new InputAttribute("WorkflowActivityProfilerConfiguration") }, out isInputParameter, out isOutputParameter);

			return CreateInputOutputProperty(activity, ProfilerConfigurationPropertyName, typeof(InArgument<string>), attributes);
		}

		private static CodeMemberProperty CreateInputOutputProperty(CodeTypeDeclaration activity, PropertyInfo property,
			Collection<string> inputProperties, Collection<string> outputProperties)
		{
			// Collect the attributes for the parameter
			bool isInputParameter, isOutputParameter;
			CodeAttributeDeclarationCollection attributes = CreateWorkflowAttributes(property.GetCustomAttributes(true),
				out isInputParameter, out isOutputParameter);
			if (!isInputParameter && !isOutputParameter)
			{
				return null;
			}

			if (isInputParameter)
			{
				inputProperties.Add(property.Name);
			}

			if (isOutputParameter)
			{
				outputProperties.Add(property.Name);
			}

			return CreateInputOutputProperty(activity, property.Name, property.PropertyType, attributes);
		}

		private static CodeMemberProperty CreateInputOutputProperty(CodeTypeDeclaration activity, string propertyName, Type type,
			CodeAttributeDeclarationCollection attributes)
		{
			// Instantiate the property
			CodeMemberProperty property = new CodeMemberProperty()
			{
				Attributes = MemberAttributes.Public | MemberAttributes.Final,
				CustomAttributes = attributes,
				Name = propertyName,
				HasGet = true,
				HasSet = true,
				Type = new CodeTypeReference(type)
			};

			// Create a placeholder variable for the activity
			string variableName = "_ProfiledProperty_" + propertyName;
			activity.Members.Add(new CodeMemberField(property.Type, variableName));

			// Add assignments for the variable into the property
			property.GetStatements.Add(Return(VarRef(variableName)));
			property.SetStatements.Add(AssignValue(VarRef(variableName), VarRef("value")));

			return property;
		}

		private static CodeMemberMethod CreateActivityExecuteMethod(Collection<string> inputProperties, Collection<string> outputProperties)
		{
			const string ActivityContextVariableName = "context";

			// Create the execute method
			CodeMemberMethod method = new CodeMemberMethod()
			{
				Attributes = MemberAttributes.Override | MemberAttributes.Family,
				Name = "Execute",
			};
			method.Parameters.Add(new CodeParameterDeclarationExpression(new CodeTypeReference(typeof(CodeActivityContext)), ActivityContextVariableName));

			// Add the input arguments dictionary
			string inputVariableName = AddInputArgumentStatements(method.Statements, inputProperties, ActivityContextVariableName);

			// Invoke the profiler
			string outputVariableName = AddProfilerInvokeStatements(method.Statements, ActivityContextVariableName, inputVariableName);

			// Apply the output parameters to the instrumented activity
			AddOutputArgumentsStatements(method.Statements, outputProperties, ActivityContextVariableName, outputVariableName);

			return method;
		}

		private static string AddInputArgumentStatements(CodeStatementCollection statements, Collection<string> inputProperties,
			string contextVariableName)
		{
			const string InputParametersVariableName = "inputParameters";

			// Dictionary<string, object> inputArguments = new Dictionary<string, object>();
			statements.Add(Var(typeof(IDictionary<string, object>), InputParametersVariableName, New(TypeRef(typeof(Dictionary<string, object>)))));
			foreach (string propertyName in inputProperties)
			{
				// inputArguments.Add("<propertyName>", this.<propertyName>.Get(context));
				statements.Add(MethodInvoke(VarRef(InputParametersVariableName), "Add",
					Literal(propertyName),
					MethodInvoke(ThisProp(propertyName), "Get", VarRef(contextVariableName))));
			}

			return InputParametersVariableName;
		}

		private static string AddProfilerInvokeStatements(CodeStatementCollection statements, string contextVariableName,
			string inputArgumentsVariableName)
		{
			const string FactoryVariableName = "factory";
			const string ServiceVariableName = "service";
			const string QueryVariableName = "query";
			const string ResultsVariableName = "results";
			const string ContentVariableName = "content";
			const string ActivityTypeVariableName = "activityType";
			const string MethodVariableName = "method";
			const string OutputParametersVariableName = "outputParameters";

			// IOrganizationServiceFactory factory = context.GetExtension<IOrganizationServiceFactory>()
			statements.Add(Var(typeof(IOrganizationServiceFactory), FactoryVariableName,
				MethodInvoke(VarRef(contextVariableName), "GetExtension", TypeRef(typeof(IOrganizationServiceFactory)))));

			// IOrganizationService service = factory.CreateOrganizationService(null);
			statements.Add(Var(typeof(IOrganizationService), ServiceVariableName,
				MethodInvoke(VarRef(FactoryVariableName), "CreateOrganizationService", Null())));

			// QueryByAttribute query = new QueryByAttribute("pluginassembly");
			statements.Add(Var(typeof(QueryByAttribute), QueryVariableName,
				New(TypeRef(typeof(QueryByAttribute)), Literal(PluginAssembly.EntityLogicalName))));

			// query.ColumnSet = new ColumnSet("content");
			statements.Add(AssignProp(VarRef(QueryVariableName), "ColumnSet",
				New(TypeRef(typeof(ColumnSet)), Literal("content"))));

			// query.AddAttributeValue("name", "<profiler assembly name>");
			statements.Add(MethodInvoke(VarRef(QueryVariableName), "AddAttributeValue",
				Literal("name"), Literal(typeof(ProfilerConfiguration).Assembly.GetName().Name)));

			// EntityCollection results = service.RetrieveMultiple(query);
			statements.Add(Var(typeof(EntityCollection), ResultsVariableName,
				MethodInvoke(VarRef(ServiceVariableName), "RetrieveMultiple", VarRef(QueryVariableName))));

			// if (0 == results.Entities.Count) throw new InvalidPluginExecutionException("...");
			statements.Add(If(Equal(Literal(0), PropRef(PropRef(VarRef(ResultsVariableName), "Entities"), "Count")),
				Throw(typeof(InvalidPluginExecutionException), "Unable to locate the Profiler Assembly.")));

			// byte[] content = Convert.FromBase64String(results[0].GetAttributeValue<string>("content"));
			statements.Add(Var(typeof(byte[]), ContentVariableName,
				StaticMethodInvoke(typeof(Convert), "FromBase64String",
					MethodInvoke(Indexer(VarRef(ResultsVariableName), 0), "GetAttributeValue", TypeRef(typeof(string)), Literal("content")))));

			// Type activityType = Assembly.Load(content).GetType("PluginProfiler.Plugins.ProfilerActivity", true);
			statements.Add(Var(typeof(Type), ActivityTypeVariableName,
				MethodInvoke(StaticMethodInvoke(typeof(Assembly), "Load", VarRef(ContentVariableName)), "GetType",
					Literal(typeof(ProfilerActivity).FullName), Literal(true))));

			// MethodInfo method = activityType.GetMethod("Execute", BindingFlags.Static | BindingFlags.Public);
			statements.Add(Var(typeof(MethodInfo), MethodVariableName,
				MethodInvoke(VarRef(ActivityTypeVariableName), "GetMethod",
					Literal("Execute"),
						Binary(FieldRef(typeof(BindingFlags), "Static"), CodeBinaryOperatorType.BitwiseOr,
							FieldRef(typeof(BindingFlags), "Public")))));

			// if (null == method) throw new InvalidPluginExecutionException("...");
			statements.Add(If(Null(VarRef(MethodVariableName)),
				Throw(typeof(InvalidPluginExecutionException), "Execute method cannot be found on the Profiler Activity.")));

			// IDictionary<string, object> outputParameters = (IDictionary<string, object>)method.Invoke(null,
			// new object[] 
			// { 
			//    this.ProfilerActivityProfilerConfiguration.Get(context),
			//    context,
			//    inputArguments
			// }
			statements.Add(Var(typeof(IDictionary<string, object>), OutputParametersVariableName,
				Cast(TypeRef(typeof(IDictionary<string, object>)), MethodInvoke(VarRef(MethodVariableName), "Invoke",
					Null(), NewArray(TypeRef(typeof(object)),
						MethodInvoke(ThisProp(ProfilerConfigurationPropertyName), "Get", VarRef(contextVariableName)),
						VarRef(contextVariableName),
						VarRef(inputArgumentsVariableName))))));

			return OutputParametersVariableName;
		}

		private static void AddOutputArgumentsStatements(CodeStatementCollection statements, Collection<string> outputProperties,
			string contextVariableName, string outputParametersVariableName)
		{
			const string ValuePlaceholderVariableName = "value";
			if (0 == outputProperties.Count)
			{
				return;
			}

			statements.Add(Var(typeof(object), ValuePlaceholderVariableName, Null()));
			foreach (string propertyName in outputProperties)
			{
				// if (outputParameters.TryGetValue("<propertyName>", out value)) this.<propertyName>.Set(context, value);
				statements.Add(If(MethodInvoke(VarRef(outputParametersVariableName), "TryGetValue",
					Literal(propertyName), new CodeDirectionExpression(FieldDirection.Out, VarRef(ValuePlaceholderVariableName))),
					MethodInvoke(ThisProp(propertyName), "Set", VarRef(contextVariableName), VarRef(ValuePlaceholderVariableName))));
			}
		}

		private static CodeAttributeDeclarationCollection CreateWorkflowAttributes(IEnumerable existingAttributes,
			out bool isInputParameter, out bool isOutputParameter)
		{
			isInputParameter = false;
			isOutputParameter = false;

			// Loop through each attribute on the property and convert them to CodeDom attributes

			CodeAttributeDeclarationCollection attributes = new CodeAttributeDeclarationCollection();
			foreach (Attribute attribute in existingAttributes)
			{
				#region InputAttribute and OutputAttribute
				{
					ParameterAttribute castAttribute = attribute as ParameterAttribute;
					if (null != castAttribute)
					{
						attributes.Add(Attribute(castAttribute.GetType(),
							AttributeArg(castAttribute.Name)));

						if (castAttribute is InputAttribute)
						{
							isInputParameter = true;
						}
						else if (castAttribute is OutputAttribute)
						{
							isOutputParameter = true;
						}
						continue;
					}
				}
				#endregion

				#region AttributeTargetAttribute
				{
					AttributeTargetAttribute castAttribute = attribute as AttributeTargetAttribute;
					if (null != castAttribute)
					{
						attributes.Add(Attribute(castAttribute.GetType(),
							AttributeArg(castAttribute.EntityName),
							AttributeArg(castAttribute.AttributeName)));
						continue;
					}
				}
				#endregion

				#region DefaultAttribute
				{
					DefaultAttribute castAttribute = attribute as DefaultAttribute;
					if (null != castAttribute)
					{
						attributes.Add(Attribute(castAttribute.GetType(),
							AttributeArg(castAttribute.Value),
							AttributeArg(castAttribute.EntityName)));
						continue;
					}
				}
				#endregion

				#region ReferenceTargetAttribute
				{
					ReferenceTargetAttribute castAttribute = attribute as ReferenceTargetAttribute;
					if (null != castAttribute)
					{
						attributes.Add(Attribute(castAttribute.GetType(),
							AttributeArg(castAttribute.EntityName)));
						continue;
					}
				}
				#endregion
			}

			return attributes;
		}

		private static void CreateAssemblyAttributes(CodeAttributeDeclarationCollection attributes,
			ActivityAssemblyCompilerConfiguration configuration)
		{
			attributes.Add(Attribute(typeof(AssemblyVersionAttribute), AttributeArg(configuration.Version)));
			attributes.Add(Attribute(typeof(AssemblyFileVersionAttribute), AttributeArg(configuration.FileVersion)));
		}

		private static CompiledAssembly CompileAssembly(CodeCompileUnit unit, string keyFileName, string assemblyName)
		{
			using (CSharpCodeProvider provider = new CSharpCodeProvider())
			{
				// Compile the assembly
				CompilerResults results = provider.CompileAssemblyFromDom(CreateCompilerParameters(keyFileName, assemblyName), unit);

				// If there are any errors write it:
				if (0 != results.Errors.Count)
				{
					StringBuilder sb = new StringBuilder();
					sb.AppendLine("Compiler errors occurred while compiling the assembly.");
					foreach (CompilerError error in results.Errors)
					{
						sb.AppendFormat(CultureInfo.InvariantCulture, "{0}({1}) {2}{3}", error.FileName, error.Line,
							error.ErrorText, Environment.NewLine);
					}

					throw new InvalidOperationException(sb.ToString());
				}

				// Read the data about the assembly into memory
				CompiledAssembly assembly;
				using (AppDomainContext context = new AppDomainContext("CompiledAssembly"))
				{
					assembly = context.Proxy.GetAssembly(results.PathToAssembly);
				}

				// Delete the assembly from the disk
				Directory.Delete(Path.GetDirectoryName(results.PathToAssembly), true);

				return assembly;
			}
		}

		private static CompilerParameters CreateCompilerParameters(string keyFileName, string assemblyName)
		{
			string tempFilePath = Path.GetTempFileName();
			tempFilePath = Path.Combine(Path.GetDirectoryName(tempFilePath), Path.GetFileNameWithoutExtension(tempFilePath));

			Directory.CreateDirectory(tempFilePath);

			CompilerParameters parameters = new CompilerParameters();
			parameters.CompilerOptions = string.Format(CultureInfo.InvariantCulture, "\"/keyfile:{0}\"", keyFileName);
			parameters.ReferencedAssemblies.AddRange(ReferencedAssemblies);
			parameters.IncludeDebugInformation = false;
			parameters.TreatWarningsAsErrors = true;
			parameters.GenerateInMemory = false;
			parameters.OutputAssembly = Path.Combine(tempFilePath, assemblyName + ".dll");

			return parameters;
		}

		#region CodeDom Helpers
		private static CodeTypeReference TypeRef(Type type)
		{
			return new CodeTypeReference(type);
		}

		private static CodeAttributeDeclaration Attribute(Type type, params CodeAttributeArgument[] args)
		{
			return new CodeAttributeDeclaration(TypeRef(type), args);
		}

		private static CodeAttributeArgument AttributeArg(object value)
		{
			CodeExpression codeExpression = value as CodeExpression;
			if (codeExpression != null)
				return AttributeArg(null, codeExpression);
			else
				return AttributeArg(null, value);
		}

		private static CodeAttributeArgument AttributeArg(string name, object value)
		{
			return AttributeArg(name, new CodePrimitiveExpression(value));
		}

		private static CodeAttributeArgument AttributeArg(string name, CodeExpression value)
		{
			return String.IsNullOrEmpty(name)
				? new CodeAttributeArgument(value)
				: new CodeAttributeArgument(name, value);
		}

		private static CodeConditionStatement If(CodeExpression condition, CodeExpression trueCode)
		{
			return If(condition, new CodeExpressionStatement(trueCode), null);
		}

		private static CodeConditionStatement If(CodeExpression condition, CodeStatement trueStatement)
		{
			return If(condition, trueStatement, null);
		}

		private static CodeConditionStatement If(CodeExpression condition, CodeStatement trueStatement, CodeStatement falseStatement)
		{
			CodeConditionStatement ifStatement = new CodeConditionStatement(condition, trueStatement);
			if (falseStatement != null)
				ifStatement.FalseStatements.Add(falseStatement);
			return ifStatement;
		}

		private static CodeFieldReferenceExpression FieldRef(Type targetType, string fieldName)
		{
			return new CodeFieldReferenceExpression(new CodeTypeReferenceExpression(targetType), fieldName);
		}

		private static CodeVariableReferenceExpression VarRef(string name)
		{
			return new CodeVariableReferenceExpression(name);
		}

		private static CodeVariableDeclarationStatement Var(Type type, string name, CodeExpression init)
		{
			return new CodeVariableDeclarationStatement(type, name, init);
		}

		private static CodeObjectCreateExpression New(CodeTypeReference createType, params CodeExpression[] args)
		{
			CodeObjectCreateExpression create = new CodeObjectCreateExpression(createType, args);
			return create;
		}

		private static CodeArrayCreateExpression NewArray(CodeTypeReference createType, params CodeExpression[] initializers)
		{
			return new CodeArrayCreateExpression(createType, initializers);
		}

		private static CodeBinaryOperatorExpression Binary(CodeExpression left, CodeBinaryOperatorType op, CodeExpression right)
		{
			return new CodeBinaryOperatorExpression(left, op, right);
		}

		private static CodeAssignStatement AssignProp(CodeExpression target, string propName, CodeExpression value)
		{
			CodeAssignStatement assign = new CodeAssignStatement();
			assign.Left = PropRef(target, propName);
			assign.Right = value;
			return assign;
		}

		private static CodeAssignStatement AssignValue(CodeExpression target, CodeExpression value)
		{
			return new CodeAssignStatement(target, value);
		}

		private static CodeMethodInvokeExpression MethodInvoke(CodeExpression target, string methodName, params CodeExpression[] parameters)
		{
			return new CodeMethodInvokeExpression(new CodeMethodReferenceExpression(target, methodName), parameters);
		}

		private static CodeMethodInvokeExpression MethodInvoke(CodeExpression target, string methodName, CodeTypeReference typeParameter,
			params CodeExpression[] parameters)
		{
			return new CodeMethodInvokeExpression(new CodeMethodReferenceExpression(target, methodName, typeParameter), parameters);
		}

		private static CodeIndexerExpression Indexer(CodeExpression target, object index)
		{
			return new CodeIndexerExpression(target, Literal(index));
		}

		private static CodePropertyReferenceExpression PropRef(CodeExpression expression, string propertyName)
		{
			return new CodePropertyReferenceExpression(expression, propertyName);
		}

		private static CodePropertyReferenceExpression ThisProp(string propertyName)
		{
			return new CodePropertyReferenceExpression(This(), propertyName);
		}

		private static CodeThisReferenceExpression This()
		{
			return new CodeThisReferenceExpression();
		}

		private static CodeMethodInvokeExpression StaticMethodInvoke(Type targetObject, string methodName, params CodeExpression[] parameters)
		{
			return new CodeMethodInvokeExpression(
				new CodeMethodReferenceExpression(
					new CodeTypeReferenceExpression(targetObject),
					methodName),
				parameters);
		}

		private static CodeCastExpression Cast(CodeTypeReference targetType, CodeExpression expression)
		{
			return new CodeCastExpression(targetType, expression);
		}

		private static CodePrimitiveExpression Literal(object value)
		{
			return new CodePrimitiveExpression(value);
		}

		private static CodeMethodReturnStatement Return(CodeExpression expression)
		{
			return new CodeMethodReturnStatement(expression);
		}

		private static CodeExpression Null(CodeExpression expression)
		{
			return new CodeBinaryOperatorExpression(expression, CodeBinaryOperatorType.IdentityEquality, Null());
		}

		private static CodePrimitiveExpression Null()
		{
			return new CodePrimitiveExpression(null);
		}

		private static CodeThrowExceptionStatement Throw(Type type, string message)
		{
			return new CodeThrowExceptionStatement(New(TypeRef(type), Literal(message)));
		}

		private static CodeBinaryOperatorExpression Equal(CodeExpression left, CodeExpression right)
		{
			return new CodeBinaryOperatorExpression(left, CodeBinaryOperatorType.IdentityEquality, right);
		}
		#endregion
		#endregion

		#region Private Classes
		private sealed class AppDomainContext : IDisposable
		{
			private AppDomain _domain;
			private bool _disposed;

			internal AppDomainContext(string domainName)
			{
				if (string.IsNullOrWhiteSpace(domainName))
				{
					throw new ArgumentNullException("domainName");
				}

				//Create the AppDomain
				AppDomainSetup setup = new AppDomainSetup();
				setup.ApplicationBase = AppDomain.CurrentDomain.BaseDirectory;

				this._domain = AppDomain.CreateDomain(domainName, null, setup);

				//Create the proxy in the AppDomain so that all assemblies that are loaded do not stay loaded in the AppDomain
				this.Proxy = (AssemblyReader)this._domain.CreateInstanceFromAndUnwrap(typeof(AssemblyReader).Assembly.Location,
					typeof(AssemblyReader).FullName);
			}

			~AppDomainContext()
			{
				this.Dispose(false);
			}

			#region Properties
			public AssemblyReader Proxy { get; private set; }
			#endregion

			#region Methods
			public void Dispose()
			{
				this.Dispose(true);
				GC.SuppressFinalize(this);
			}
			#endregion

			#region Private Methods
			private void Dispose(bool disposing)
			{
				if (this._disposed)
				{
					return;
				}

				if (null != this._domain)
				{
					AppDomain.Unload(this._domain);
					this._domain = null;
					this.Proxy = null;
				}

				if (disposing)
				{
					this._disposed = true;
				}
			}
			#endregion
		}

		private sealed class AssemblyReader : MarshalByRefObject
		{
			public CompiledAssembly GetAssembly(string path)
			{
				byte[] assembly = File.ReadAllBytes(path);
				return new CompiledAssembly(Assembly.Load(assembly).GetName(), assembly);
			}
		}
		#endregion
	}

	#region Internal Classes
	/// <summary>
	/// Compiler Configuration for an Assembly of Workflow Activities
	/// </summary>
	internal sealed class ActivityAssemblyCompilerConfiguration
	{
		internal ActivityAssemblyCompilerConfiguration(string assemblyName, string version, string fileVersion, string keyFileName)
		{
			if (string.IsNullOrWhiteSpace(assemblyName))
			{
				throw new ArgumentNullException("assemblyName");
			}
			else if (string.IsNullOrWhiteSpace(keyFileName))
			{
				throw new ArgumentNullException("keyFileName");
			}

			this.AssemblyName = assemblyName;
			this.Version = version;
			this.FileVersion = fileVersion;
			this.KeyFileName = keyFileName;

			this.Types = new Dictionary<Guid, ActivityTypeCompilerConfiguration>();
		}

		#region Properties
		/// <summary>
		/// New name of the assembly to be compiled
		/// </summary>
		internal string AssemblyName { get; private set; }

		/// <summary>
		/// File Version
		/// </summary>
		internal string FileVersion { get; private set; }

		/// <summary>
		/// Assembly Version
		/// </summary>
		internal string Version { get; private set; }

		/// <summary>
		/// Types that should be included in the compilation
		/// </summary>
		internal IDictionary<Guid, ActivityTypeCompilerConfiguration> Types { get; private set; }

		/// <summary>
		/// Key that should be used to sign the assembly
		/// </summary>
		internal string KeyFileName { get; private set; }
		#endregion
	}

	/// <summary>
	/// Compiler Configuration for a Workflow Activity Type
	/// </summary>
	internal sealed class ActivityTypeCompilerConfiguration
	{
		#region Constructors
		internal ActivityTypeCompilerConfiguration(Guid id, string ns, string typeName, Type type)
		{
			if (Guid.Empty == id)
			{
				throw new ArgumentNullException("id");
			}
			else if (string.IsNullOrWhiteSpace(ns))
			{
				throw new ArgumentNullException("ns");
			}
			else if (string.IsNullOrWhiteSpace(typeName))
			{
				throw new ArgumentNullException("typeName");
			}
			else if (null == type)
			{
				throw new ArgumentNullException("type");
			}
			else if (!typeof(Activity).IsAssignableFrom(type))
			{
				throw new ArgumentException(string.Format(CultureInfo.InvariantCulture,
					"Type \"{0}\" is not a supported Workflow Activity as it doesn't inherit from \"{1}\".",
					type.FullName, typeof(Activity).FullName));
			}

			this.Id = id;
			this.Namespace = ns;
			this.TypeName = typeName;
			this.Type = type;
		}
		#endregion

		#region Properties
		/// <summary>
		/// Id for the Type
		/// </summary>
		internal Guid Id { get; private set; }

		/// <summary>
		/// New Name for the Type
		/// </summary>
		internal string TypeName { get; private set; }

		/// <summary>
		/// Namespace for the new type
		/// </summary>
		internal string Namespace { get; private set; }

		/// <summary>
		/// Exisiting Type
		/// </summary>
		internal Type Type { get; private set; }
		#endregion
	}

	[Serializable]
	internal sealed class CompiledAssembly
	{
		public CompiledAssembly(AssemblyName name, byte[] assembly)
		{
			if (null == name)
			{
				throw new ArgumentNullException("name");
			}
			else if (null == assembly)
			{
				throw new ArgumentNullException("assembly");
			}

			this.Assembly = assembly;
			if (null == name)
			{
				throw new ArgumentNullException("name");
			}

			this.Name = name.Name;
			this.Version = name.Version.ToString();

			if (name.CultureInfo.LCID == CultureInfo.InvariantCulture.LCID)
			{
				this.Culture = "neutral";
			}
			else
			{
				this.Culture = name.CultureInfo.Name;
			}

			byte[] tokenBytes = name.GetPublicKeyToken();
			if (null == tokenBytes || 0 == tokenBytes.Length)
			{
				this.PublicKeyToken = null;
			}
			else
			{
				this.PublicKeyToken = string.Join(string.Empty, tokenBytes.Select(b => b.ToString("X2", CultureInfo.InvariantCulture)));
			}
		}

		#region Properties
		/// <summary>
		/// Name of the assembly
		/// </summary>
		public string Name { get; private set; }

		/// <summary>
		/// Version of the assembly
		/// </summary>
		public string Version { get; private set; }

		/// <summary>
		/// Culture for the assembly
		/// </summary>
		public string Culture { get; private set; }

		/// <summary>
		/// Public Key Token for the assembly
		/// </summary>
		public string PublicKeyToken { get; private set; }

		/// <summary>
		/// Serialized version of the assembly
		/// </summary>
		public byte[] Assembly { get; private set; }
		#endregion
	}
	#endregion
}
