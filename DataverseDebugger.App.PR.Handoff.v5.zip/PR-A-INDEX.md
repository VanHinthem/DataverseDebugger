# DataverseDebugger.App — PR Execution Index (Authoritative)

## Execution Order (Do Not Reorder)
1. PR-A01 – ExecutionMode-First App Model
2. PR-A02 – Live Write Safety Gate
3. PR-A03 – Deterministic Runner Copy on Build
4. PR-A04 – Centralized Runner Start Configuration (Mode + Gate)
5. PR-A05 – App Contract Validation & Drift Prevention

## Global Rules
- Preserve existing behavior unless the PR explicitly changes it.
- Do not modify Runner code, packaging, or protocol contracts.
- Do not refactor unrelated areas.
- Each PR must compile and run before starting the next.
