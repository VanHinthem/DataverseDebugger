# PR 6 — Regression + Documentation + Final Validation

**Repo:** DataverseDebugger

## Global Non-Negotiables
1. No new external project references; reference ZIPs are conceptual only.
2. Do not refactor WebAPI entry wiring; only add a thin delegation seam when instructed.
3. Single-plugin execution only; no pipeline re-entry simulation.
4. Sender-controlled `ExecutionMode` is authoritative when provided; legacy fallback remains when absent.
5. Keep all changes inside existing `DataverseDebugger.Runner` project (no new projects).
6. Keep diffs minimal and reviewable; avoid opportunistic refactors.
7. Add deterministic errors for guards/NotSupported (include mode + operation + guidance).

## AI Implementation Rules
- Preserve current behavior unless this PR explicitly changes it.
- Maintain backward compatibility for request/response serialization.
- Add tests as specified; do not skip tests.



## Objective
Regression hardening and documentation: ensure WebAPI behavior remains stable, validate all entry+mode combinations, and document limitations.

## Scope
- Add regression tests to prove:
  - legacy behavior unchanged when ExecutionMode absent
  - WebAPI entry wiring unchanged (only delegating seam if applied)
- Add integration tests for:
  - Profiler entry + Offline/Hybrid/Online
  - WebAPI entry + Offline/Hybrid/Online (as applicable in your architecture)
- Ensure logging is consistent and errors are deterministic.

## Deliverables
### A) Live connectivity validation
- Add tests or verification steps to ensure that **plugin debugging execution paths** in Online/Hybrid use the ServiceClient-backed `IOrganizationService` factory (not the legacy Web API wrapper), while host-side Web API proxy routing remains unchanged.


### B) Regression test suite
- Baseline tests for key existing flows (before/after comparisons)
- Tests for Online gate

### C) Documentation
Add/update docs (Markdown) describing:
- Entry mechanisms vs execution modes
- ExecutionMode request field and allowed values
- Offline limitations (WhoAmI only Execute)
- Hybrid limitations (cached creates only for ID-targeted queries; strict Execute whitelist)
- Online safety gate and risks
- Single-plugin execution limitation (no pipeline re-entry simulation)

### D) Cleanup (optional, only if safe)
- Remove dead code paths introduced by interim steps (only if fully covered by tests)

### Acceptance criteria
- All tests pass
- No regressions to existing behavior
- Documentation is clear and matches implementation

## AI Prompt (copy/paste)
> Implement PR6: add regression and integration tests covering legacy behavior, ExecutionMode selection, Offline/Hybrid/Online behavior, and Online safety gate. Confirm WebAPI entry wiring remains unchanged aside from any approved delegation seam. Add clear documentation describing entry mechanisms, execution modes, constraints, and limitations. Ensure errors are deterministic and test-covered.

