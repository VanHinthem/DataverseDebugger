﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;

using Microsoft.Crm.Services.Utility;

using PluginProfiler.Library;

namespace PluginProfiler.Debugger
{
	/// <summary>
	/// Class that represents the command-line parameters
	/// </summary>
	internal sealed class PluginDebuggerParameters : ICommandLineArgumentSource
	{
		#region Fields
		private CommandLineParser _parser;
		#endregion

		#region Constructors
		internal PluginDebuggerParameters()
		{
			this._parser = new CommandLineParser(this);
			this.Permissions = PluginPermissions.Sandbox;
			this.WorkflowStepIds = new List<string>();
		}
		#endregion

		#region Properties
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional | ArgumentType.Binary, "nologo",
			Description = "Suppresses the banner.")]
		internal bool NoLogo { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional, "url",
			Description = "A url or path to the SDK endpoint to use when calling an IOrganizationService instance (not required for replay operations).",
			ParameterDescription = "<url>", SampleUsageValue = "http://localhost/Organization1/XRMServices/2011/Organization.svc")]
		internal string Url { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional, "file",
			Description = "The path to the debugging log file.",
			ParameterDescription = "<filename>",
			Shortcut = "f", SampleUsageValue = "ErrorDetails.txt")]
		internal string InputFile { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional, "assembly",
			Description = "Path to the plug-in assembly to be executed.",
			ParameterDescription = "<path>",
			Shortcut = "a", SampleUsageValue = "PluginAssembly.dll")]
		internal string PluginAssemblyPath { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional, "type",
			Description = "Plug-in type that should be instantiated with this profile.",
			ParameterDescription = "<typename>",
			Shortcut = "t", SampleUsageValue = "MyNamespace.MyPluginType")]
		internal string PluginTypeName { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional, "username",
			Description = "Username of an administrator to use when connecting to the server.",
			ParameterDescription = "<username>",
			Shortcut = "u")]
		internal string UserName { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional, "password",
			Description = "Password of an administrator to use when connecting to the server.",
			ParameterDescription = "<password>",
			Shortcut = "p")]
		internal string Password { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional, "domain",
			Description = "Domain of an administrator to use when connecting to the server.",
			ParameterDescription = "<domain>",
			Shortcut = "d")]
		internal string Domain { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Required, "operation",
			Description = "Type of operation being executed: Replay, Debug, Enable, Remove",
			ParameterDescription = "<Replay, Debug, Enable, Disable, Remove>",
			Shortcut = "o")]
		internal string Operation { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional, "isolation",
			Description = "Isolation Mode: None, Sandbox",
			ParameterDescription = "<None, Sandbox>",
			Shortcut = "i")]
		internal string IsolationMode { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional, "id",
			Description = "Id of the profiled operation or operation to be profiled (Only required when enabling/disabling profiling).",
			ParameterDescription = "<guid>")]
		internal string Id { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional, "name",
			Description = "Name of the profiled operation or operation to be profiled (Only required when enabling/disabling profiling).",
			ParameterDescription = "<Name>",
			Shortcut = "n")]
		internal string Name { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional, "profiledoperation",
			Description = "Type of operation to be profiled (Only required when enabling/disabling profiling).",
			ParameterDescription = "<Plugin, WorkflowActivity>",
			Shortcut = "po")]
		internal string ProfilerOperationType { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional | ArgumentType.Multiple, "workflowstep",
			Description = "One or more ids for the custom activity steps in the workflow (Only required when enabling/disabling profiling).",
			ParameterDescription = "<Name of the Workflow Step>",
			Shortcut = "wfs")]
		internal List<string> WorkflowStepIds { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional, "key",
			Description = "File name to the key that should be used when building an instrumented assembly (Only required when enabling/disabling profiling for workflows).",
			ParameterDescription = "<File Path>")]
		internal string KeyFileName { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional | ArgumentType.Binary, "persist",
			Description = "Indicates that the profile should be persisted (Only required when enabling/disabling profiling).")]
		internal bool PersistToEntity { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional, "persistkey",
			Description = "Session key to be used when serializing the profile to an entity (Optional when enabling/disabling profiling).",
			ParameterDescription = "<Arbitrary Key>")]
		internal string PersistenceSessionKey { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional, "maxiterations",
			Description = "Number of times the plug-in should be profiled before profiling is disabled (Only required when enabling/disabling profiling).",
			ParameterDescription = "<Number>",
			Shortcut = "max")]
		internal int? MaxNumberOfExecutions { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional | ArgumentType.Binary, "excludesecure",
			Description = "Indicates that secure information should be excluded when generating profile. (Only required when enabling/disabling profiling).")]
		internal bool ExcludeSecureInformation { get; set; }

		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Justification = "Called via reflection")]
		[CommandLineArgument(ArgumentType.Optional | ArgumentType.Binary, "help",
			Shortcut = "?",
			Description = "Show this usage message.")]
		internal bool ShowHelp { get; set; }

		internal DebuggerOperation DebuggerOperation { get; set; }

		internal OperationHandlerBase OperationHandler { get; set; }

		internal PluginPermissions Permissions { get; set; }

		private CommandLineParser Parser
		{
			get
			{
				return this._parser;
			}
		}
		#endregion

		#region Methods
		internal void LoadArguments(string[] args)
		{
			this.Parser.ParseArguments(args);
		}

		internal bool VerifyArguments()
		{
			if (!this.Parser.VerifyArguments())
			{
				Trace.TraceWarning("Exiting {0} with false return value due to the parser finding invalid arguments",
					MethodBase.GetCurrentMethod().Name);
				return false;
			}

			DebuggerOperation operation;
			if (Enum.TryParse<DebuggerOperation>(this.Operation, true, out operation))
			{
				this.DebuggerOperation = operation;
			}
			else
			{
				Trace.TraceWarning("Exiting {0} because the debugger operation specified is invalid.",
					MethodBase.GetCurrentMethod().Name);
				return false;
			}

			if (this.DebuggerOperation != Debugger.DebuggerOperation.Replay &&
				string.IsNullOrWhiteSpace(this.Url))
			{
				Trace.TraceWarning("Exiting {0} because the URL was not specified. It is required when this is not a replay operation.",
					MethodBase.GetCurrentMethod().Name);
				return false;
			}

			OperationType operationType;
			if (string.IsNullOrWhiteSpace(this.ProfilerOperationType) ||
				!Enum.TryParse<OperationType>(this.ProfilerOperationType, true, out operationType))
			{
				operationType = OperationType.Unknown;
			}

			switch (this.DebuggerOperation)
			{
				case Debugger.DebuggerOperation.Replay:
				case Debugger.DebuggerOperation.Debug:
					if (!this.VerifyReplayDebug())
					{
						return false;
					}
					break;
				case Debugger.DebuggerOperation.Enable:
				case Debugger.DebuggerOperation.Disable:
				case Debugger.DebuggerOperation.ListSteps:
					if (!this.VerifyOperationHandler(operationType))
					{
						return false;
					}
					break;
				default:
					throw new NotImplementedException("DebuggerOperation = " + this.DebuggerOperation);
			}

			if (!string.IsNullOrWhiteSpace(this.Domain) || !string.IsNullOrEmpty(this.UserName))
			{
				if (string.IsNullOrWhiteSpace(this.Password))
				{
					Trace.TraceWarning("Exiting {0} with false return value due to invalid credentials",
						MethodBase.GetCurrentMethod().Name);
					return false;
				}
			}

			if (string.Equals("None", this.IsolationMode, StringComparison.OrdinalIgnoreCase))
			{
				this.Permissions = PluginPermissions.NonIsolated;
			}

			return true;
		}

		internal void ShowUsage()
		{
			this.Parser.WriteUsage();
		}
		#endregion

		#region Private Helper Methods
		private bool VerifyReplayDebug()
		{
			if (string.IsNullOrWhiteSpace(this.PluginAssemblyPath) ||
				!File.Exists(this.PluginAssemblyPath))
			{
				Trace.TraceWarning("Exiting {0} because the assembly path is either invalid or missing.",
					MethodBase.GetCurrentMethod().Name);
				return false;
			}
			else if (string.IsNullOrWhiteSpace(this.InputFile) ||
				!File.Exists(this.InputFile))
			{
				Trace.TraceWarning("Exiting {0} because the input file path is either invalid or missing.",
					MethodBase.GetCurrentMethod().Name);
				return false;
			}

			return true;
		}

		private bool VerifyOperationHandler(OperationType operationType)
		{
			// Parse the Id into a valid value
			Guid id;
			if (string.IsNullOrWhiteSpace(this.Id) || !Guid.TryParse(this.Id, out id))
			{
				id = Guid.Empty;
			}
			if (Guid.Empty == id && string.IsNullOrWhiteSpace(this.Name))
			{
				Trace.TraceWarning("Exiting {0} because the Id and Name have not been specified.",
					MethodBase.GetCurrentMethod().Name);
				return false;
			}

			// Instantiate the operation handler
			switch (operationType)
			{
				case OperationType.Plugin:
					this.OperationHandler = new PluginOperationHandler(this.PluginAssemblyPath, this.PluginTypeName, this.InputFile,
						null, null, this.MaxNumberOfExecutions, this.PersistToEntity,
						this.PersistenceSessionKey, this.ExcludeSecureInformation, id, this.Name);
					break;
				case OperationType.WorkflowActivity:
					this.OperationHandler = new WorkflowActivityOperationHandler(this.PluginAssemblyPath, this.PluginTypeName,
						this.InputFile, this.KeyFileName, this.PersistToEntity, this.PersistenceSessionKey, this.ExcludeSecureInformation,
						id, this.Name, null == this.WorkflowStepIds ? null : this.WorkflowStepIds.ToArray());
					break;
				default:
					Trace.TraceWarning("Exiting {0} because the operation type is invalid.",
						MethodBase.GetCurrentMethod().Name);
					return false;
			}

			// Validate the operation
			StringBuilder errors = new StringBuilder();
			if (!this.OperationHandler.Validate(this.DebuggerOperation, errors))
			{
				Trace.TraceWarning("Exiting {0} because parameters for the operation {1} are invalid:{2}{3}",
					MethodBase.GetCurrentMethod().Name, operationType, Environment.NewLine, errors);
				return false;
			}

			return true;
		}
		#endregion

		#region ICommandLineArgumentSource Implementation
		void ICommandLineArgumentSource.OnUnknownArgument(string argumentName, string argumentValue)
		{
			throw new NotSupportedException("Argument Name: " + argumentName);
		}

		void ICommandLineArgumentSource.OnInvalidArgument(string argument)
		{
			Trace.TraceError("Exiting {0}: Found string {1} in arguments array that could not be parsed.",
				MethodBase.GetCurrentMethod().Name, argument);
			throw new InvalidOperationException(String.Format(CultureInfo.InvariantCulture,
				"Argument '{0}' could not be parsed.", argument));
		}
		#endregion
	}

	public enum DebuggerOperation
	{
		Install,
		Replay,
		Debug,
		Enable,
		Disable,
		Uninstall,
		ListSteps
	}
}
