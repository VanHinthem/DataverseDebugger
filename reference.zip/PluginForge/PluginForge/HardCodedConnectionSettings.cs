﻿namespace Microsoft.Dynamics.ProjectOperations.PluginForge
{
    public class HardCodedConnectionSettings : IConnectionSettings
    {
        public string Profile { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }
        public string OrganizationUrl { get => "https://aurorabapenvba451.crm10.dynamics.com"; set => throw new System.NotImplementedException(); }
        public string FQDNOrgUrl { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }
        public string Audience { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }
        public string UserPrincipalName { get => "aurorauser01@auroraprojopsintegration01.onmicrosoft.com"; set => throw new System.NotImplementedException(); }
        public string Password { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }
        public string TenantId { get => "e1cbfdbb-a786-4d71-a661-47db9bcecb6a"; set => throw new System.NotImplementedException(); }
        public string SubjectName { get => "aurorauser01.auroraprojopsintegration01.azclient.ms"; set => throw new System.NotImplementedException(); }
        public string TestUserPrincipalName { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }
        public string TestUserSubjectName { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }
        public string TokenCacheStorePath { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }
    }
}
