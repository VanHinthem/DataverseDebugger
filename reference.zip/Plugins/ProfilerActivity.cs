﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Diagnostics;

using Microsoft.Xrm.Sdk.Workflow;

using PluginProfiler.Plugins.ServiceWrappers;

namespace PluginProfiler.Plugins
{
	/// <summary>
	/// Entry point for the server-side profiler component for activities
	/// </summary>
	public sealed class ProfilerActivity : ProfilerBase<WorkflowExecutionContextWrapper>
	{
		/// <summary>
		/// Instantiate an instance of the ProfilerActivity class
		/// </summary>
		/// <param name="configuration">Configuration for the entity</param>
		public ProfilerActivity(string configuration)
			: base(configuration)
		{
		}

		#region Public Methods
		/// <summary>
		/// Executes the profiler activity
		/// </summary>
		/// <param name="activityContext">Activity context with the existing services attached</param>
		/// <param name="inputParameters">Input Parameters for the Workflow</param>
		internal IDictionary<string, object> Execute(ActivityContext activityContext, IDictionary<string, object> inputParameters)
		{
			if (null == activityContext)
			{
				throw new ArgumentNullException("activityContext");
			}
			else if (null == inputParameters)
			{
				throw new ArgumentNullException("inputParameters");
			}

			// Extract the services from the provider
			Dictionary<Type, object> services = ServiceProviderWrapper.ExtractServices(activityContext);
			WorkflowExecutionContextWrapper workflowContext =
				new WorkflowExecutionContextWrapper(activityContext.GetExtension<IWorkflowContext>());

			// Initialize the profiler
			ProfilerPluginContext context;
			ProfilerPluginReport report = this.InitializeProfiler(services, workflowContext, out context);

			// Add the parameters to the report
			this.AddParameters(report.WorkflowInputParameters, inputParameters);

			// Execute the Activity
			return (IDictionary<string, object>)this.Execute(workflowContext, context, report, inputParameters);
		}

		/// <summary>
		/// Execute the Profiler Activity
		/// </summary>
		/// <param name="profilerConfiguration">Profiler Configuration</param>
		/// <param name="activityContext">Activity Context for the Workflow Activity</param>
		/// <param name="inputParameters">Input Parameters for the workflow</param>
		/// <returns>Output parameters</returns>
		public static IDictionary<string, object> Execute(string profilerConfiguration,
			ActivityContext activityContext, IDictionary<string, object> inputParameters)
		{
			if (string.IsNullOrWhiteSpace(profilerConfiguration))
			{
				throw new ArgumentNullException("profilerConfiguration", "Profiler Configuration must be non-null.");
			}

			return new ProfilerActivity(profilerConfiguration).Execute(activityContext, inputParameters);
		}
		#endregion

		internal override void ExecuteInternal(Stopwatch watch, ProfilerPluginContext context, ProfilerPluginReport report,
			object inputParameter, ref object result)
		{
			IDictionary<string, object> inputParameters = inputParameter as IDictionary<string, object>;

			// Instantiate the WorkflowInvoker to prepare for executing the activity
			WorkflowInvoker invoker = new WorkflowInvoker(this.InitializationContext.Activity);
			context.ServiceProvider.AddExtensionsToWorkflowInvoker(invoker);

			// Execute the workflow
			watch.Start();
			IDictionary<string, object> outputParameters = invoker.Invoke(inputParameters);
			watch.Stop();

			// Report the output parameters to the report
			this.AddParameters(report.WorkflowOutputParameters, outputParameters);

			// Return the results to the caller
			result = outputParameters;
		}

		#region Private Methods
		private void AddParameters(IList<SerializedValue> serializedItems, IDictionary<string, object> parameters)
		{
			if (null == parameters)
			{
				return;
			}

			foreach (KeyValuePair<string, object> parameter in parameters)
			{
				serializedItems.Add(new SerializedValue(parameter.Key, parameter.Value));
			}
		}
		#endregion
	}
}
