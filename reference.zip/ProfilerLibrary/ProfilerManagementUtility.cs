﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceModel;

using Microsoft.Crm.Sdk.Messages;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

using PluginProfiler.Plugins;

using CrmSdk;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Utility for managing the profiler plug-ins
	/// </summary>
	public static class ProfilerManagementUtility
	{
		private const string ProfilerWorkflowKeyDefaultFileName = "PluginProfiler.DefaultWorkflowAssembly.snk";
		private const string ProfilerSolutionUniqueName = "PluginProfiler";
		private const string ProfilerSuffix = " (Profiler)";
		private const string ProfilerDescription = "Plug-in profiler step that encapsulates the plug-in or provides the IPluginExecutionContext at a particular point in the pipeline.";
		private const string ProfilerTypePrefix = "ProfilerType";
		private const string ProfilerNamespace = "ProfiledTypes";
		public const string ProfiledStepNameSuffix = " (Profiled)";
		public const string ProfilerActivityAssemblyNameFormat = "{0}_{1}" + ProfilerActivityNameSuffix;
		public const string ProfilerActivityNameSuffix = "_Profiled";
		public const string ProfilerWorkflowDescriptionPrefix = "|P|";

		/// <summary>
		/// Installs the Profiler with the given service
		/// </summary>
		public static EntityReference InstallProfiler(IOrganizationService service)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}

			return RetrieveOrCreateProfilerPluginType(service);
		}

		/// <summary>
		/// Enables profiling for a given step
		/// </summary>
		/// <param name="service">Service to be profiled</param>
		/// <param name="pluginStepId">Id for the step to be profiled</param>
		public static Guid EnablePlugin(IOrganizationService service, Guid pluginStepId)
		{
			return EnablePlugin(service, pluginStepId, false, null, null, true);
		}

		/// <summary>
		/// Enables profiling for a given step
		/// </summary>
		/// <param name="service">Service to be profiled</param>
		/// <param name="pluginStepId">Id for the step to be profiled</param>
		/// <param name="persistToEntity">Indicates that the profile should be persisted to an entity</param>
		/// <param name="persistenceSessionKey">Session key for persistence (optional).</param>
		/// <param name="maxNumberOfExecutions">Maximum number of executions before the profile is disabled</param>
		/// <param name="includeSecureInformation">Indicates that secure information should be included in the profile</param>
		/// <remarks>
		/// Although these parameters can be added to the Plug-in Profiler Configuration, they are not currently honored by
		/// the Plug-in Profiler. These have been added to allow for future functionality. Once this functionality is available,
		/// this method should be made public.
		/// </remarks>
		public static Guid EnablePlugin(IOrganizationService service, Guid pluginStepId, bool persistToEntity, string persistenceSessionKey,
			int? maxNumberOfExecutions, bool includeSecureInformation)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}
			else if (Guid.Empty == pluginStepId)
			{
				throw new ArgumentNullException("pluginStepId");
			}

			//Instantiate the profiler step
			Tuple<SdkMessageProcessingStep, ProfilerConfiguration> profilerConfiguration = InstantiateProfilerStep(service, pluginStepId, null,
				persistToEntity, persistenceSessionKey, maxNumberOfExecutions, includeSecureInformation);

			Guid profilerStepId;
			if (profilerConfiguration.Item2.IsContextReplay.GetValueOrDefault())
			{
				Entity step = profilerConfiguration.Item1.ToEntity<Entity>();
				profilerStepId = step.Id;

				service.Update(step);
			}
			else
			{
				//Create the profiler step and disable the original step (the profiler step is taking the place of the orginal step)
				profilerStepId = service.Create(profilerConfiguration.Item1.ToEntity<Entity>());

				//Update the title for the step
				service.Update(new SdkMessageProcessingStep()
				{
					Id = pluginStepId,
					Name = profilerConfiguration.Item2.OriginalEventHandlerName + ProfiledStepNameSuffix
				}.ToEntity<Entity>());

				service.Execute(new SetStateRequest()
				{
					EntityMoniker = new EntityReference(SdkMessageProcessingStep.EntityLogicalName, pluginStepId),
					State = new OptionSetValue((int)SdkMessageProcessingStepState.Disabled),
					Status = new OptionSetValue(-1)
				});
			}

			return profilerStepId;
		}

		/// <summary>
		/// Instruments the specified steps in a Workflow
		/// </summary>
		/// <param name="service">Service to be used to retrieve the assembly</param>
		/// <param name="overrideKeyFileName">File name for the key file to be used to sign the workflow shim assembly (if the default is not sufficient).</param>
		/// <param name="workflowId">Id for the Workflow</param>
		/// <param name="workflowStepIds">Step ids that should be instrumented</param>
		/// <returns>Id for the profiled Workflow</returns>
		/// <remarks>
		/// Using this method will be less performant than providing the CustomActivityStep as the XAML for the workflow
		/// will need to be retrieved and parsed for the custom activity steps.
		/// </remarks>
		public static Guid EnableWorkflow(IOrganizationService service, string overrideKeyFileName, Guid workflowId,
			params string[] workflowStepIds)
		{
			return EnableWorkflow(service, overrideKeyFileName, workflowId, false, null, true, false, workflowStepIds);
		}

		/// <summary>
		/// Instruments the specified steps in a Workflow
		/// </summary>
		/// <param name="service">Service to be used to retrieve the assembly</param>
		/// <param name="overrideKeyFileName">File name for the key file to be used to sign the workflow shim assembly (if the default is not sufficient).</param>
		/// <param name="workflowId">Id for the Workflow</param>
		/// <param name="persistToEntity">Indicates that the profile should be persisted to an entity</param>
		/// <param name="persistenceSessionKey">Session key for persistence (optional).</param>
		/// <param name="includeSecureInformation">Indicates that secure information should be included in the profile</param>
		/// <param name="isContextReplay">Indicates that this is a context replay.</param>
		/// <param name="workflowStepIds">Step ids that should be instrumented</param>
		/// <returns>Id for the profiled Workflow</returns>
		/// <remarks>
		/// Using this method will be less performant than providing the CustomActivityStep as the XAML for the workflow
		/// will need to be retrieved and parsed for the custom activity steps.
		/// </remarks>
		public static Guid EnableWorkflow(IOrganizationService service, string overrideKeyFileName, Guid workflowId,
			bool persistToEntity, string persistenceSessionKey, bool includeSecureInformation, bool isContextReplay, params string[] workflowStepIds)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}
			else if (Guid.Empty == workflowId)
			{
				throw new ArgumentNullException("workflowId");
			}

			// Get the list of steps
			IDictionary<string, CustomActivityStep> steps = GetWorkflowActivitySteps(service, workflowId);

			// Loop through and include only the workflow steps that have been requested
			List<CustomActivityStep> filteredSteps = new List<CustomActivityStep>();
			if (null == workflowStepIds)
			{
				filteredSteps.AddRange(steps.Values);
			}
			else
			{
				Collection<string> processedSteps = new Collection<string>();
				foreach (string id in workflowStepIds)
				{
					if (string.IsNullOrWhiteSpace(id) || processedSteps.Contains(id))
					{
						continue;
					}
					processedSteps.Add(id);

					CustomActivityStep step;
					if (steps.TryGetValue(id, out step))
					{
						filteredSteps.Add(step);
					}
					else
					{
						throw new ArgumentOutOfRangeException("workflowStepIds", id, "Step does not exist in the specified Workflow.");
					}
				}
			}

			return EnableWorkflow(service, overrideKeyFileName, workflowId, persistToEntity, persistenceSessionKey,
				includeSecureInformation, isContextReplay, filteredSteps.ToArray());
		}

		/// <summary>
		/// Instruments the specified steps in a Workflow
		/// </summary>
		/// <param name="service">Service to be used to retrieve the assembly</param>
		/// <param name="overrideKeyFileName">File name for the key file to be used to sign the workflow shim assembly (if the default is not sufficient).</param>
		/// <param name="workflowId">Id for the Workflow</param>
		/// <param name="workflowSteps">Steps that should be instrumented</param>
		/// <returns>Id for the profiled Workflow</returns>
		public static Guid EnableWorkflow(IOrganizationService service, string overrideKeyFileName, Guid workflowId,
			params CustomActivityStep[] workflowSteps)
		{
			return EnableWorkflow(service, overrideKeyFileName, workflowId, false, null, true, false, workflowSteps);
		}

		/// <summary>
		/// Instruments the specified steps in a Workflow
		/// </summary>
		/// <param name="service">Service to be used to retrieve the assembly</param>
		/// <param name="overrideKeyFileName">File name for the key file to be used to sign the workflow shim assembly (if the default is not sufficient).</param>
		/// <param name="workflowId">Id for the Workflow</param>
		/// <param name="persistToEntity">Indicates that the profile should be persisted to an entity</param>
		/// <param name="persistenceSessionKey">Session key for persistence (optional).</param>
		/// <param name="includeSecureInformation">Indicates that secure information should be included in the profile</param>
		/// <param name="isContextReplay">Indicates that this is a context replay.</param>
		/// <param name="workflowSteps">Steps that should be instrumented</param>
		/// <returns>Id for the profiled Workflow</returns>
		public static Guid EnableWorkflow(IOrganizationService service, string overrideKeyFileName, Guid workflowId,
			bool persistToEntity, string persistenceSessionKey, bool includeSecureInformation, bool isContextReplay, params CustomActivityStep[] workflowSteps)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}
			else if (Guid.Empty == workflowId)
			{
				throw new ArgumentNullException("workflowId");
			}
			else if (null == workflowSteps || 0 == workflowSteps.Length)
			{
				throw new ArgumentNullException("workflowSteps");
			}

			// Default the key file name (if not set)
			if (string.IsNullOrWhiteSpace(overrideKeyFileName))
			{
				overrideKeyFileName = GenerateDefaultKeyFileNameIfMissing(overrideKeyFileName);
			}

			// Delete the existing profiler workflow
			DeleteProfiledWorkflow(service, workflowId);

			// Instrument all of the steps specified
			Dictionary<Guid, PluginType> instrumentedSteps = InstrumentWorkflowSteps(service, workflowId, overrideKeyFileName, workflowSteps);

			// Create the configuration for the workflow
			List<InstrumentedStepConfiguration> configurationSteps = new List<InstrumentedStepConfiguration>();
			foreach (CustomActivityStep step in workflowSteps)
			{
				PluginType instrumentedPlugin;
				if (instrumentedSteps.TryGetValue(step.PluginTypeId, out instrumentedPlugin))
				{
					ProfilerConfiguration configuration = InstantiateWorkflowActivityConfiguration(step.PluginAssemblyId,
						new EntityReference(PluginType.EntityLogicalName, step.PluginTypeId), step.TypeName,
						persistToEntity, persistenceSessionKey, includeSecureInformation, isContextReplay, step.StepId);
					configurationSteps.Add(new InstrumentedStepConfiguration(step.StepId, configuration, instrumentedPlugin));
				}
			}

			// Retrieve the Workflow's XAML
			Workflow template = service.Retrieve(Workflow.EntityLogicalName, workflowId, new ColumnSet("statecode", "category", "description", "name", "ondemand", "primaryentity", "scope", "subprocess", "triggeroncreate", "triggerondelete", "type", "xaml")).ToEntity<Workflow>();

			// Instrument the XAML
			template.Xaml = WorkflowXamlUtility.InstrumentXaml(service, template.Xaml, configurationSteps);

			// Create the duplicate workflow
			bool isPublished = (WorkflowState.Draft != template.StateCode);

			template.Attributes.Remove("statecode");
			template.AsyncAutoDelete = false;
			template.Description = CreateProfiledObjectConfiguration(new Guid[] { template.Id }, isPublished);
			template.Name += ProfilerManagementUtility.ProfiledStepNameSuffix;

			// Check if the state of the workflow is published
			if (isPublished)
			{
				SetStateRequest request = new SetStateRequest();
				request.EntityMoniker = template.ToEntityReference();
				request.State = new OptionSetValue((int)WorkflowState.Draft);
				request.Status = new OptionSetValue(-1);

				service.Execute(request);
			}

			// Create the profiled workflow
			template.Id = Guid.NewGuid();
			service.Create(template.ToEntity<Entity>());

			// If this workflow was published, it needs to be republished
			if (isPublished)
			{
				SetStateRequest request = new SetStateRequest();
				request.EntityMoniker = template.ToEntityReference();
				request.State = new OptionSetValue((int)WorkflowState.Activated);
				request.Status = new OptionSetValue(-1);

				service.Execute(request);
			}

			return template.Id;
		}

		/// <summary>
		/// Generates a list of the custom activity steps on the given workflow
		/// </summary>
		/// <param name="service">Service to be used to access the workflow</param>
		/// <param name="workflowId">Id for the Workflow</param>
		/// <returns>List of custom activity steps for the workflow</returns>
		public static IDictionary<string, CustomActivityStep> GetWorkflowActivitySteps(IOrganizationService service, Guid workflowId)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}
			else if (Guid.Empty == workflowId)
			{
				throw new ArgumentNullException("workflowId");
			}

			// Retrieve the XAML
			string xaml = service.Retrieve(Workflow.EntityLogicalName, workflowId, new ColumnSet("xaml")).GetAttributeValue<string>("xaml");

			// Parse the XAML
			return WorkflowXamlUtility.GetWorkflowActivitySteps(service, xaml);
		}

		/// <summary>
		/// Generates a list of the custom activity steps on the given workflow
		/// </summary>
		/// <param name="service">Service to be used to access the workflow</param>
		/// <param name="xaml">XAML definition for the workflow</param>
		/// <returns>List of custom activity steps for the workflow</returns>
		public static IDictionary<string, CustomActivityStep> GetWorkflowActivitySteps(IOrganizationService service, string xaml)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}
			else if (string.IsNullOrWhiteSpace(xaml))
			{
				throw new ArgumentNullException("xaml");
			}

			// Parse the XAML
			return WorkflowXamlUtility.GetWorkflowActivitySteps(service, xaml);
		}

		/// <summary>
		/// Refreshes a profiler step from the given entity
		/// </summary>
		/// <param name="service">Service to be profiled</param>
		/// <param name="profilerStepId">Id for the profiler step</param>
		public static void RefreshProfilerStep(IOrganizationService service, Guid profilerStepId)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}
			else if (Guid.Empty == profilerStepId)
			{
				throw new ArgumentNullException("profilerStepId");
			}

			//Retrieve the existing profiler configuration
			SdkMessageProcessingStep step = service.Retrieve(SdkMessageProcessingStep.EntityLogicalName, profilerStepId,
				new ColumnSet("configuration")).ToEntity<SdkMessageProcessingStep>();
			ProfilerConfiguration originalConfiguration = RetrieveConfiguration(step.Configuration);

			//Instantiate the profiler step
			Tuple<SdkMessageProcessingStep, ProfilerConfiguration> profilerConfiguration = InstantiateProfilerStep(service,
				originalConfiguration.EventHandler.Id, originalConfiguration, false, null, null, true);

			//Update the existing step
			profilerConfiguration.Item1.Id = profilerStepId;
			service.Update(profilerConfiguration.Item1.ToEntity<Entity>());
		}

		/// <summary>
		/// Deserializes the Unsecure Configuration for a Profiler Step
		/// </summary>
		/// <param name="configuration">Configuration with the profiler information</param>
		public static ProfilerConfiguration RetrieveConfiguration(string configuration)
		{
			if (string.IsNullOrWhiteSpace(configuration))
			{
				throw new ArgumentNullException("configuration");
			}

			return ProfilerConfiguration.Deserialize(configuration);
		}

		/// <summary>
		/// Disables the given profiler 
		/// </summary>
		/// <param name="service">Service for the given organization</param>
		/// <param name="profilerStepId">Id of the profiler step, which replaced the original step</param>
		public static void DisablePlugin(IOrganizationService service, Guid profilerStepId)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}
			else if (Guid.Empty == profilerStepId)
			{
				throw new ArgumentNullException("profilerStepId");
			}

			//Retrieve the reference to the profiler plugintype record to determine if the step that was specified is the step under
			//the profiler or the profiler step itself
			EntityReference profilerPluginId = RetrieveProfilerPluginType(service);

			SdkMessageProcessingStep step = service.Retrieve(SdkMessageProcessingStep.EntityLogicalName,
				profilerStepId, new ColumnSet("name", "configuration", "statecode", "eventhandler")).ToEntity<SdkMessageProcessingStep>();

			Dictionary<Guid, ProfilerConfiguration> disableStepList;
			if (profilerPluginId.Equals(step.EventHandler))
			{
				if (string.IsNullOrWhiteSpace(step.Configuration))
				{
					throw new InvalidOperationException("StepId does not refer to a valid (enabled) profiler step.");
				}

				//Deserialize the configuration
				ProfilerConfiguration configuration;
				try
				{
					configuration = ProfilerConfiguration.Deserialize(step.Configuration);
				}
				catch (Exception ex)
				{
					throw new InvalidOperationException("Unable to deserialize the configuration for the profiler step.", ex);
				}

				//Populate the list
				disableStepList = new Dictionary<Guid, ProfilerConfiguration>();
				disableStepList.Add(step.Id, configuration);
			}
			else
			{
				disableStepList = RetrieveProfilerSteps(RetrieveAllProfilerSteps(service, profilerPluginId, false), profilerStepId);
			}

			if (0 == disableStepList.Count)
			{
				throw new InvalidOperationException("StepId does not refer to a valid profiler step or step under the profiler.");
			}

			DisableProfilerSteps(service, disableStepList);
		}

		/// <summary>
		/// Disables the given profiler 
		/// </summary>
		/// <param name="service">Service for the given organization</param>
		/// <param name="workflowId">Id of the workflow</param>
		public static void DisableWorkflow(IOrganizationService service, Guid workflowId)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}
			else if (Guid.Empty == workflowId)
			{
				throw new ArgumentNullException("workflowId");
			}

			DisableWorkflows(service, new Entity[] { RetrieveProfilerWorkflow(service, workflowId, "xaml") }, true);
		}

		/// <summary>
		/// Uninstalls the Profiler from the given organization
		/// </summary>
		/// <param name="service">Service for the Profiler</param>
		public static void UninstallProfiler(IOrganizationService service)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}

			// Delete all of the profiler workflows
			DeleteAllProfilerWorkflows(service);

			//Retrieve all plug-in types that are related to the profiler plug-in type plug-in (including those
			//that have bad configuration values).
			Dictionary<Guid, ProfilerConfiguration> pluginSteps = RetrieveAllProfilerSteps(service,
				RetrieveProfilerPluginType(service), true);

			//Disable all of the profiling that has been enabled
			DisableProfilerSteps(service, pluginSteps);

			//Delete the solution
			QueryByAttribute query = new QueryByAttribute(CrmSdk.Solution.EntityLogicalName);
			query.AddAttributeValue("uniquename", ProfilerSolutionUniqueName);

			EntityCollection results = service.RetrieveMultiple(query);
			if (1 != results.Entities.Count)
			{
				throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
					"Unable to locate the Profiler solution (Name = \"{0}\").", ProfilerSolutionUniqueName));
			}

			service.Delete(Solution.EntityLogicalName, results.Entities.FirstOrDefault().Id);
		}

		/// <summary>
		/// Determines if the given plug-in type is the Profiler plug-in
		/// </summary>
		/// <remarks>
		/// This method has been added to support a UI built over the Profiler.
		/// </remarks>
		public static bool IsProfilerPlugin(string pluginTypeName)
		{
			if (string.IsNullOrWhiteSpace(pluginTypeName))
			{
				throw new ArgumentNullException("pluginTypeName");
			}

			return string.Equals(typeof(ProfilerPlugin).FullName, pluginTypeName, StringComparison.OrdinalIgnoreCase);
		}

		/// <summary>
		/// Updates the given <paramref name="step"/> with the configuration for a step that doesn't have an actual plug-in.
		/// </summary>
		/// <param name="step">Step entity instance to be updated</param>
		/// <remarks>
		/// In some cases, a developer may be using the Profiler to develop their plug-in from scratch. In order to capture
		/// the initial plug-in context, a step still needs to be registered. To enable this, the Profiler supports registering a step
		/// on the Plug-in Profiler Plug-in itself in order to capture the needed information.
		/// </remarks>
		public static ProfilerConfiguration UpdateWithStandaloneConfiguration(Entity step)
		{
			if (null == step)
			{
				throw new ArgumentNullException("step");
			}

			return CreateContextReplayConfiguration(step.ToEntity<SdkMessageProcessingStep>(), null);
		}

		/// <summary>
		/// Determines if the provided assembly is a workflow activity wrapper assembly
		/// </summary>
		/// <param name="entity">Entity that should be checked</param>
		/// <returns>True if the assembly is a workflow activity</returns>
		/// <remarks>
		/// Entity must contain the "name" and "description" fields.
		/// </remarks>
		public static Guid ExtractWorkflowIdFromAssembly(Entity entity)
		{
			if (null == entity)
			{
				throw new ArgumentNullException("entity");
			}

			PluginAssembly assembly = entity.ToEntity<PluginAssembly>();
			if (!string.IsNullOrWhiteSpace(assembly.Description) &&
				assembly.Description.StartsWith(ProfilerWorkflowDescriptionPrefix, StringComparison.Ordinal))
			{
				string isolatedSuffix = string.Format(CultureInfo.InvariantCulture, ProfilerActivityAssemblyNameFormat,
					string.Empty, "None");
				string nonIsolatedSuffix = string.Format(CultureInfo.InvariantCulture, ProfilerActivityAssemblyNameFormat,
					string.Empty, "Isolated");

				if (!string.IsNullOrWhiteSpace(assembly.Name))
				{
					string unparsedId;
					if (assembly.Name.EndsWith(isolatedSuffix, StringComparison.Ordinal))
					{
						unparsedId = assembly.Name.Substring(0, assembly.Name.Length - isolatedSuffix.Length);
					}
					else if (assembly.Name.EndsWith(nonIsolatedSuffix, StringComparison.Ordinal))
					{
						unparsedId = assembly.Name.Substring(0, assembly.Name.Length - nonIsolatedSuffix.Length);
					}
					else
					{
						return Guid.Empty;
					}

					Guid id;
					if (Guid.TryParseExact(unparsedId, "N", out id))
					{
						return id;
					}
				}
			}

			return Guid.Empty;
		}

		/// <summary>
		/// Retrieve all profiler workflow entities
		/// </summary>
		/// <param name="service">Service that should be used</param>
		/// <param name="additionalColumns">Additional columns that should be included when retrieving the entities</param>
		/// <returns>List of profiler workflows</returns>
		public static IList<Entity> RetrieveAllProfilerWorkflows(IOrganizationService service, params string[] additionalColumns)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}

			QueryExpression query = new QueryExpression(Workflow.EntityLogicalName);
			query.ColumnSet = new ColumnSet("name", "description", "createdon", "modifiedon");
			if (null != additionalColumns && 0 != additionalColumns.Length)
			{
				query.ColumnSet.AddColumns(additionalColumns);
			}
			query.Criteria.AddCondition("type", ConditionOperator.Equal, 1);
			query.Criteria.AddCondition("description", ConditionOperator.BeginsWith, ProfilerWorkflowDescriptionPrefix);

			EntityCollection workflows = service.RetrieveMultiple(query);
			if (0 == workflows.Entities.Count)
			{
				return new Entity[0];
			}

			return workflows.Entities;
		}

		/// <summary>
		/// Retrieves the assemblies for a given workflow id
		/// </summary>
		/// <param name="service">Service to be used</param>
		/// <param name="originalWorkflowId">Id for the original workflow</param>
		/// <returns>List of plug-in assembly ids</returns>
		public static IList<Guid> RetrieveProfilerWorkflowAssemblies(IOrganizationService service, Guid originalWorkflowId)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}
			else if (Guid.Empty == originalWorkflowId)
			{
				throw new ArgumentNullException("originalWorkflowId");
			}

			return RetrieveProfilerWorkflowsAssemblies(service, new Guid[] { originalWorkflowId });
		}

		#region Private Methods
		private static Guid[] DisableWorkflows(IOrganizationService service, IList<Entity> profilerWorkflows, bool cleanupAssemblies)
		{
			List<Guid> originalWorkflowsIds = new List<Guid>();
			foreach (Entity entity in profilerWorkflows)
			{
				Workflow profilerWorkflow = entity.ToEntity<Workflow>();

				// Read the original workflow
				Tuple<Collection<Guid>, DateTime, bool> profilerConfiguration = ReadProfiledObjectConfiguration(profilerWorkflow.Description);

				// Unpublish the profile workflow
				SetStateRequest stateRequest = new SetStateRequest();
				stateRequest.EntityMoniker = new EntityReference(Workflow.EntityLogicalName, profilerWorkflow.Id);
				stateRequest.State = new OptionSetValue((int)WorkflowState.Draft);
				stateRequest.Status = new OptionSetValue(-1);
				try
				{
					service.Execute(stateRequest);
				}
				catch (Exception ex)
				{
					throw new InvalidOperationException("Unable to unpublish the profiler workflow. The state of the system has not changed.", ex);
				}

				// Publish the original Workflow
				Guid originalWorkflowId = profilerConfiguration.Item1.First();
				originalWorkflowsIds.Add(originalWorkflowId);
				if (profilerConfiguration.Item3)
				{
					stateRequest.EntityMoniker.Id = profilerConfiguration.Item1.First();
					stateRequest.State = new OptionSetValue((int)WorkflowState.Activated);

					try
					{
						service.Execute(stateRequest);
					}
					catch (FaultException<OrganizationServiceFault> ex)
					{
						if (-2147220969 != ex.Detail.ErrorCode) //ObjectDoesNotExist
						{
							throw new InvalidOperationException("Unable to publish the original workflow. Please review the Workflow and publish manually.", ex);
						}
					}
				}

				// Delete the workflow
				try
				{
					service.Delete(Workflow.EntityLogicalName, profilerWorkflow.Id);
				}
				catch (Exception ex)
				{
					throw new InvalidOperationException("Unable to delete the Profiled Workflow. The original workflow has been restored to its original state.", ex);
				}

				if (cleanupAssemblies)
				{
					CleanUpAssembliesAndTypes(service, profilerWorkflow.Xaml);
				}
			}

			return originalWorkflowsIds.ToArray();
		}

		private static IList<Guid> RetrieveProfilerWorkflowsAssemblies(IOrganizationService service, Guid[] originalWorkflowIds)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}
			else if (null == originalWorkflowIds || 0 == originalWorkflowIds.Length)
			{
				throw new ArgumentNullException("originalWorkflowIds");
			}

			QueryExpression query = new QueryExpression(PluginAssembly.EntityLogicalName);
			foreach (Guid id in originalWorkflowIds)
			{
				query.Criteria.AddCondition("name", ConditionOperator.Like,
					string.Format(CultureInfo.InvariantCulture, ProfilerActivityAssemblyNameFormat,
					id.ToString("N"), "%"));
			}

			List<Guid> ids = new List<Guid>();
			foreach (Entity entity in service.RetrieveMultiple(query).Entities)
			{
				ids.Add(entity.Id);
			}

			return ids;
		}

		private static ProfilerConfiguration CreateContextReplayConfiguration(SdkMessageProcessingStep step,
			ProfilerConfiguration originalConfiguration)
		{
			ProfilerConfiguration configuration = new ProfilerConfiguration()
			{
				IncludeSecureInformation = true,
				IsContextReplay = true,
				Configuration = step.Configuration
			};

			if (null == originalConfiguration)
			{
				configuration.OriginalEventHandlerName = step.Name;
				if (!step.Name.EndsWith(ProfiledStepNameSuffix, StringComparison.Ordinal))
				{
					step.Name = step.Name + ProfiledStepNameSuffix;
				}
			}
			else
			{
				configuration.OriginalEventHandlerName = originalConfiguration.OriginalEventHandlerName;
			}

			return configuration;
		}

		private static ProfilerConfiguration InstantiateWorkflowActivityConfiguration(Guid assemblyId, EntityReference originalTypeId,
			string typeName, bool persistToEntity, string persistenceSessionKey, bool includeSecureInformation, bool isContextReplay,
			string workflowStepId)
		{
			// Create the configuration
			ProfilerConfiguration configuration = new ProfilerConfiguration();
			configuration.AssemblyId = new EntityReference(PluginAssembly.EntityLogicalName, assemblyId);
			configuration.EventHandler = originalTypeId;
			configuration.IncludeSecureInformation = includeSecureInformation;
			configuration.IsContextReplay = isContextReplay;
			configuration.IsProfilePersistedToEntity = persistToEntity;
			configuration.WorkflowStepId = workflowStepId;
			if (persistToEntity)
			{
				configuration.PersistenceSessionKey =
					string.IsNullOrWhiteSpace(persistenceSessionKey) ? Guid.NewGuid().ToString("N") : persistenceSessionKey;
			}
			configuration.TypeName = typeName;

			return configuration;
		}

		private static Tuple<SdkMessageProcessingStep, ProfilerConfiguration> InstantiateProfilerStep(IOrganizationService service,
			Guid handlerId, ProfilerConfiguration originalConfiguration, bool persistToEntity, string persistenceSessionKey,
			int? maximumNumberOfExecutions, bool includeSecureInformation)
		{
			EntityReference profilerType = RetrieveProfilerPluginType(service);

			QueryExpression query = new QueryExpression(SdkMessageProcessingStep.EntityLogicalName);
			query.ColumnSet = new ColumnSet(true);
			query.Criteria.AddCondition("sdkmessageprocessingstepid", ConditionOperator.Equal, handlerId);
			if (null == originalConfiguration)
			{
				query.Criteria.AddCondition("statecode", ConditionOperator.Equal, (int)SdkMessageProcessingStepState.Enabled);
			}

			LinkEntity pluginLink = query.AddLink(PluginType.EntityLogicalName, "eventhandler", "plugintypeid");
			pluginLink.EntityAlias = "plugin";
			pluginLink.Columns = new ColumnSet("typename", "pluginassemblyid");

			EntityCollection collection = service.RetrieveMultiple(query);
			if (0 == collection.Entities.Count)
			{
				throw new InvalidOperationException("Invalid StepId has been specified. Either it does not exist, is not enabled (may already be profiled), or it is not a custom plug-in: " +
					handlerId);
			}

			SdkMessageProcessingStep step = collection[0].ToEntity<SdkMessageProcessingStep>();
			EntityReference assemblyId = (EntityReference)step.GetAttributeValue<AliasedValue>("plugin.pluginassemblyid").Value;
			string typeName = (string)step.GetAttributeValue<AliasedValue>("plugin.typename").Value;

			SdkMessageProcessingStep profilerStep = new SdkMessageProcessingStep();
			if (string.IsNullOrWhiteSpace(step.Name))
			{
				step.Name = "Unnamed plug-in";
			}

			ProfilerConfiguration configuration;
			if (profilerType.Equals(step.EventHandler))
			{
				if (null == originalConfiguration)
				{
					profilerStep.Id = step.Id;
					profilerStep.Name = step.Name;
				}

				configuration = CreateContextReplayConfiguration(profilerStep, originalConfiguration);
			}
			else
			{
				configuration = new ProfilerConfiguration()
					{
						IncludeSecureInformation = true,
						AssemblyId = assemblyId,
						TypeName = typeName,
						EventHandler = step.ToEntityReference()
					};

				if (null == originalConfiguration)
				{
					configuration.OriginalEventHandlerName = step.Name;
					profilerStep.Name = step.Name + ProfilerSuffix;
					profilerStep.EventHandler = profilerType;
				}
				else
				{
					configuration.OriginalEventHandlerName = originalConfiguration.OriginalEventHandlerName;
				}

				profilerStep.Stage = step.Stage;
				profilerStep.SupportedDeployment = step.SupportedDeployment;
				profilerStep.SdkMessageId = step.SdkMessageId;
				profilerStep.SdkMessageFilterId = step.SdkMessageFilterId;
				profilerStep.Rank = step.Rank;
				profilerStep.AsyncAutoDelete = step.AsyncAutoDelete;
				profilerStep.Mode = step.Mode;
			}

			if (persistToEntity)
			{
				configuration.IsProfilePersistedToEntity = true;
				configuration.PersistenceSessionKey =
					string.IsNullOrWhiteSpace(persistenceSessionKey) ? Guid.NewGuid().ToString("N") : persistenceSessionKey;
			}

			configuration.IncludeSecureInformation = includeSecureInformation;
			configuration.MaxNumberOfExecutions = maximumNumberOfExecutions;

			profilerStep.Configuration = configuration.ToString();
			profilerStep.Description = ProfilerDescription;

			//Add the images that need to be updated
			List<SdkMessageProcessingStepImage> images = RetrieveImagesForStep(service, step.Id);
			if (null != images)
			{
				profilerStep.sdkmessageprocessingstepid_sdkmessageprocessingstepimage = images;
			}

			return new Tuple<SdkMessageProcessingStep, ProfilerConfiguration>(profilerStep, configuration);
		}

		private static List<SdkMessageProcessingStepImage> RetrieveImagesForStep(IOrganizationService service, Guid parentStepId)
		{
			QueryByAttribute query = new QueryByAttribute(SdkMessageProcessingStepImage.EntityLogicalName);
			query.ColumnSet = new ColumnSet();
			query.AddAttributeValue("sdkmessageprocessingstepid", parentStepId);

			EntityCollection results = service.RetrieveMultiple(query);
			if (0 == results.Entities.Count)
			{
				return null;
			}

			List<SdkMessageProcessingStepImage> imageList = new List<SdkMessageProcessingStepImage>();
			foreach (Entity entity in results.Entities)
			{
				SdkMessageProcessingStepImage image = entity.ToEntity<SdkMessageProcessingStepImage>();
				image.EntityState = EntityState.Changed;
				imageList.Add(image);
			}

			return imageList;
		}

		private static EntityReference RetrieveOrCreateProfilerPluginType(IOrganizationService service)
		{
			EntityReference profilerType = RetrieveProfilerPluginType(service);
			if (null != profilerType)
			{
				return profilerType;
			}

			// Read the solution from an embedded resource
			ImportSolutionRequest importRequest = new ImportSolutionRequest();
			importRequest.CustomizationFile = LoadSolutionFile();
			importRequest.OverwriteUnmanagedCustomizations = true;
			importRequest.PublishWorkflows = false;

			try
			{
				service.Execute(importRequest);
			}
			catch (FaultException<OrganizationServiceFault> ex)
			{
				throw new InvalidOperationException("Unable to import the solution for the Plug-in Profiler.", ex);
			}

			// Publish the Plug-in Profiler
			PublishXmlRequest publishRequest = new PublishXmlRequest();
			publishRequest.ParameterXml = string.Format(CultureInfo.InvariantCulture,
				"<importexportxml><entities><entity>{0}</entity></entities><optionsets /><dashboards /><webresources /><nodes><node>sitemap</node></nodes><settings /><securityroles /><workflows /><templates /></importexportxml>",
				ProfilerSharedUtility.ProfilerEntityLogicalName);

			try
			{
				service.Execute(publishRequest);
			}
			catch (FaultException<OrganizationServiceFault> ex)
			{
				throw new InvalidOperationException("Unable to publish customizations for the Plug-in Profiler solution. Please Publish All Customizations before attempting to use the Plug-in Profiler.", ex);
			}

			//Once the solution has been executed, attempt to retrieve the profiler type
			profilerType = RetrieveProfilerPluginType(service);
			if (null == profilerType)
			{
				throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
					"Profiler solution was imported successfully, but the Profiler's plug-in (PluginType.TypeName = \"{0}\") was not created.",
					typeof(ProfilerPlugin).FullName));
			}

			return profilerType;
		}

		private static EntityReference RetrieveProfilerPluginType(IOrganizationService service)
		{
			QueryExpression query = new QueryExpression(PluginType.EntityLogicalName);
			query.ColumnSet = new ColumnSet("plugintypeid");
			query.Criteria.AddCondition("typename", ConditionOperator.Equal, typeof(ProfilerPlugin).FullName);

			LinkEntity assemblyLink = query.AddLink(PluginAssembly.EntityLogicalName, "pluginassemblyid", "pluginassemblyid");
			assemblyLink.LinkCriteria.AddCondition("name", ConditionOperator.Equal,
				typeof(ProfilerPlugin).Assembly.GetName().Name);

			EntityCollection collection = service.RetrieveMultiple(query);
			if (0 == collection.Entities.Count)
			{
				return null;
			}

			return collection[0].ToEntityReference();
		}

		private static void DeleteAllProfilerWorkflows(IOrganizationService service)
		{
			// NOTE: There is an assumption in this code that no more than 1000 - 2000 profiled workflows will be registered at once. If there are
			// more, there will be a generic SQL error.
			IList<Entity> profilerWorkflows = RetrieveAllProfilerWorkflows(service);
			if (0 == profilerWorkflows.Count)
			{
				return;
			}

			// Delete all of the profiler workflows
			Guid[] originalWorkflowIds = DisableWorkflows(service, profilerWorkflows, false);

			// Retrieve all of the profiler workflow assemblies
			IList<Guid> assemblies = RetrieveProfilerWorkflowsAssemblies(service, originalWorkflowIds);

			// Create the query to retrieve all of the types
			QueryExpression query = new QueryExpression(PluginType.EntityLogicalName);
			query.ColumnSet = new ColumnSet();

			ConditionExpression condition = new ConditionExpression("pluginassemblyid", ConditionOperator.In);
			query.Criteria.AddCondition(condition);

			foreach (Guid id in assemblies)
			{
				condition.Values.Add(id);
			}

			EntityCollection typeResults = service.RetrieveMultiple(query);
			foreach (Entity type in typeResults.Entities)
			{
				service.Delete(type.LogicalName, type.Id);
			}

			foreach (Guid id in assemblies)
			{
				service.Delete(PluginAssembly.EntityLogicalName, id);
			}
		}

		private static void DisableProfilerSteps(IOrganizationService service, Dictionary<Guid, ProfilerConfiguration> steps)
		{
			foreach (KeyValuePair<Guid, ProfilerConfiguration> pair in steps)
			{
				Guid profilerStepId = pair.Key;
				ProfilerConfiguration configuration = pair.Value;

				//If the configuration has not been set correctly, then this is an invalid profiler.
				//The only time that this should be hit is when the profiler is being completely uninstalled.
				if (null == configuration)
				{
					service.Delete(SdkMessageProcessingStep.EntityLogicalName, profilerStepId);
					continue;
				}

				//Change the state of the original plug-in
				if (configuration.IsContextReplay.GetValueOrDefault())
				{
					List<SdkMessageProcessingStepImage> images = RetrieveImagesForStep(service, profilerStepId);
					if (null != images)
					{
						foreach (SdkMessageProcessingStepImage image in images)
						{
							service.Delete(image.LogicalName, image.Id);
						}
					}
					service.Delete(SdkMessageProcessingStep.EntityLogicalName, profilerStepId);
				}
				else
				{
					//Update the title for the step
					SdkMessageProcessingStep updatedStep = new SdkMessageProcessingStep()
					{
						Id = configuration.EventHandler.Id,
						Name = configuration.OriginalEventHandlerName,
					};

					//Set the updated images for the step
					List<SdkMessageProcessingStepImage> images = RetrieveImagesForStep(service, profilerStepId);
					if (null != images)
					{
						updatedStep.sdkmessageprocessingstepid_sdkmessageprocessingstepimage = images;
					}
					service.Update(updatedStep.ToEntity<Entity>());

					//Enable the operation
					service.Execute(new SetStateRequest()
					{
						EntityMoniker = configuration.EventHandler,
						State = new OptionSetValue((int)SdkMessageProcessingStepState.Enabled),
						Status = new OptionSetValue(-1)
					});

					//Delete the profiler step
					service.Delete(SdkMessageProcessingStep.EntityLogicalName, profilerStepId);
				}
			}
		}

		private static Dictionary<Guid, ProfilerConfiguration> RetrieveAllProfilerSteps(IOrganizationService service,
			EntityReference profilerPluginId, bool includeBadConfiguration)
		{
			if (null == profilerPluginId)
			{
				return new Dictionary<Guid, ProfilerConfiguration>(0);
			}

			QueryByAttribute query = new QueryByAttribute(SdkMessageProcessingStep.EntityLogicalName);
			query.AddAttributeValue("eventhandler", profilerPluginId.Id);
			query.ColumnSet = new ColumnSet("configuration");

			EntityCollection results = service.RetrieveMultiple(query);

			//Instantiate the variables before searching the results
			Dictionary<Guid, ProfilerConfiguration> profilerStepList = new Dictionary<Guid, ProfilerConfiguration>(results.Entities.Count);

			//Search through each of the results (deserializing the configuration) to identify which handler is profiled
			//by which profiler step.
			foreach (Entity entity in results.Entities)
			{
				SdkMessageProcessingStep step = entity.ToEntity<SdkMessageProcessingStep>();

				//Retrieve the configuration to determine if this is the step under the profiler
				ProfilerConfiguration config;
				try
				{
					config = ProfilerConfiguration.Deserialize(step.Configuration);
				}
				catch (Exception ex)
				{
					if (includeBadConfiguration)
					{
						config = null;
					}
					else
					{
						throw new InvalidOperationException("Unable to deserialize the configuration for the profiler step.", ex);
					}
				}

				if (includeBadConfiguration || null != config.EventHandler)
				{
					profilerStepList.Add(step.Id, config);
				}
			}

			return profilerStepList;
		}

		private static Dictionary<Guid, ProfilerConfiguration> RetrieveProfilerSteps(Dictionary<Guid, ProfilerConfiguration> existingSteps,
			Guid handlerId)
		{
			EntityReference handlerReference = new EntityReference(SdkMessageProcessingStep.EntityLogicalName, handlerId);

			//Search through each of the results (deserializing the configuration) to identify which handler is profiled
			//by which profiler step.
			Dictionary<Guid, ProfilerConfiguration> stepList = new Dictionary<Guid, ProfilerConfiguration>(1);
			foreach (KeyValuePair<Guid, ProfilerConfiguration> pair in existingSteps)
			{
				if (pair.Value.EventHandler.Equals(handlerReference))
				{
					stepList.Add(pair.Key, pair.Value);
				}
			}

			return stepList;
		}

		private static Dictionary<Guid, PluginType> InstrumentWorkflowSteps(IOrganizationService service, Guid workflowId, string keyFileName,
			CustomActivityStep[] workflowSteps)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}
			else if (string.IsNullOrWhiteSpace(keyFileName))
			{
				throw new ArgumentNullException("keyFileName");
			}
			else if (Guid.Empty == workflowId)
			{
				throw new ArgumentNullException("workflowId");
			}

			// Extract the unique assembly and type ids
			Dictionary<Guid, List<Guid>> assemblies = GetUniqueAssemblyAndTypeIds(workflowSteps);

			// Retrieve the assemblies and types specified
			List<object> pluginIds;
			Dictionary<Guid, PluginAssembly> sdkAssemblies = RetrieveWorkflowAssemblies(service, assemblies, out pluginIds);
			Dictionary<Guid, PluginType> sdkTypes = RetrieveWorkflowTypes(service, pluginIds);

			// Create the assembly configuration using the data
			Tuple<DateTime, DateTime> lastModified;
			Tuple<ActivityAssemblyCompilerConfiguration, ActivityAssemblyCompilerConfiguration> newAssemblies =
				InstantiateWorkflowAssemblyConfiguration(keyFileName, sdkAssemblies, sdkTypes, workflowId.ToString("N"), out lastModified);

			Dictionary<Guid, PluginType> plugins = new Dictionary<Guid, PluginType>();
			if (null != newAssemblies.Item1)
			{
				IDictionary<Guid, PluginType> typeMapping = CreateWorkflowAssembliesAndTypes(service,
					newAssemblies.Item1, sdkTypes, new OptionSetValue(2), lastModified.Item1, sdkAssemblies.Keys).Item2;
				foreach (KeyValuePair<Guid, PluginType> pair in typeMapping)
				{
					plugins.Add(pair.Key, pair.Value);
				}
			}

			if (null != newAssemblies.Item2)
			{
				IDictionary<Guid, PluginType> typeMapping = CreateWorkflowAssembliesAndTypes(service,
					newAssemblies.Item2, sdkTypes, new OptionSetValue(1), lastModified.Item2, sdkAssemblies.Keys).Item2;
				foreach (KeyValuePair<Guid, PluginType> pair in typeMapping)
				{
					plugins.Add(pair.Key, pair.Value);
				}
			}

			return plugins;
		}

		private static void UpdateAssemblyEntityState(IOrganizationService service, PluginAssembly sdkAssembly, EntityCollection sdkTypes,
			DateTime lastModified)
		{
			QueryByAttribute assemblyQuery = new QueryByAttribute(PluginAssembly.EntityLogicalName);
			assemblyQuery.ColumnSet = new ColumnSet("description");
			assemblyQuery.AddAttributeValue("name", sdkAssembly.Name);
			assemblyQuery.AddAttributeValue("version", sdkAssembly.Version);
			assemblyQuery.AddAttributeValue("culture", sdkAssembly.Culture);
			assemblyQuery.AddAttributeValue("publickeytoken", sdkAssembly.PublicKeyToken);

			EntityCollection assemblies = service.RetrieveMultiple(assemblyQuery);
			if (0 == assemblies.Entities.Count)
			{
				return;
			}

			// Get the last modified date from the existing entity
			if (lastModified < ReadProfiledObjectConfiguration(assemblies[0].GetAttributeValue<string>("description")).Item2)
			{
				sdkAssembly.Attributes.Remove("content");
			}

			sdkAssembly.Id = assemblies[0].Id;
			sdkAssembly.EntityState = EntityState.Changed;

			// Loop through each type and add it to a list of ids that can be used in a query down below.
			Dictionary<string, Entity> types = new Dictionary<string, Entity>();
			List<object> typeNames = new List<object>();
			foreach (Entity sdkType in sdkTypes.Entities)
			{
				sdkType.EntityState = EntityState.Created;

				PluginType type = sdkType.ToEntity<PluginType>();
				typeNames.Add(type.TypeName);
				types.Add(type.TypeName, sdkType);
			}

			QueryExpression typeQuery = new QueryExpression(PluginType.EntityLogicalName);
			typeQuery.ColumnSet = new ColumnSet("typename");
			typeQuery.Criteria.AddCondition("typename", ConditionOperator.In, typeNames.ToArray());

			EntityCollection existingTypes = service.RetrieveMultiple(typeQuery);
			foreach (Entity sdkType in existingTypes.Entities)
			{
				PluginType type = sdkType.ToEntity<PluginType>();

				Entity existingType;
				if (types.TryGetValue(type.TypeName, out existingType))
				{
					existingType.Id = type.Id;
					existingType.EntityState = EntityState.Changed;
					existingType.Attributes.Remove("plugintypeid");
				}
			}
		}

		private static Dictionary<Guid, List<Guid>> GetUniqueAssemblyAndTypeIds(IList<CustomActivityStep> steps)
		{
			Dictionary<Guid, List<Guid>> assemblies = new Dictionary<Guid, List<Guid>>();
			foreach (CustomActivityStep step in steps)
			{
				if (null == step)
				{
					continue;
				}

				List<Guid> types;
				if (!assemblies.TryGetValue(step.PluginAssemblyId, out types))
				{
					types = new List<Guid>();
					assemblies.Add(step.PluginAssemblyId, types);
				}

				types.Add(step.PluginTypeId);
			}

			return assemblies;
		}

		private static string CreateProfiledObjectConfiguration(IEnumerable<Guid> objectIds, bool isActive)
		{
			return string.Format(CultureInfo.InvariantCulture, "{0}{1}|{2:s}|{3}|",
				ProfilerWorkflowDescriptionPrefix, string.Join(";", objectIds), DateTime.UtcNow, isActive ? 1 : 0);
		}

		private static Tuple<Collection<Guid>, DateTime, bool> ReadProfiledObjectConfiguration(string configuration)
		{
			if (string.IsNullOrWhiteSpace(configuration))
			{
				return new Tuple<Collection<Guid>, DateTime, bool>(new Collection<Guid>(), DateTime.MinValue, false);
			}

			string[] parts = configuration.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
			if (parts.Length < 3)
			{
				return new Tuple<Collection<Guid>, DateTime, bool>(new Collection<Guid>(), DateTime.MinValue, false);
			}

			// Split out the parts
			Collection<Guid> ids = new Collection<Guid>();
			foreach (string id in (parts[1] ?? string.Empty).Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries))
			{
				Guid parsedId;
				if (Guid.TryParse(id, out parsedId))
				{
					ids.Add(parsedId);
				}
			}

			DateTime lastModified;
			if (!DateTime.TryParseExact(parts[2], "s", CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out lastModified))
			{
				lastModified = DateTime.MinValue;
			}

			bool isActive = false;
			if (parts.Length > 3 && "1" == parts[3])
			{
				isActive = true;
			}

			return new Tuple<Collection<Guid>, DateTime, bool>(ids, lastModified, isActive);
		}

		private static Tuple<Collection<Guid>, Collection<Guid>> GetAssembliesAndTypesForDeletion(IOrganizationService service, string xaml)
		{
			// Retrieve the list of steps that are present in this workflow
			Collection<Guid> deleteAssemblies = new Collection<Guid>();
			Collection<Guid> deleteTypes = new Collection<Guid>();
			foreach (CustomActivityStep step in WorkflowXamlUtility.GetWorkflowActivitySteps(service, xaml).Values)
			{
				if (!deleteTypes.Contains(step.PluginTypeId))
				{
					deleteTypes.Add(step.PluginTypeId);
				}

				if (!deleteAssemblies.Contains(step.PluginAssemblyId))
				{
					deleteAssemblies.Add(step.PluginAssemblyId);
				}
			}

			return new Tuple<Collection<Guid>, Collection<Guid>>(deleteAssemblies, deleteTypes);
		}

		private static void CleanUpAssembliesAndTypes(IOrganizationService service, string xaml)
		{
			Tuple<Collection<Guid>, Collection<Guid>> deleteInfo = GetAssembliesAndTypesForDeletion(service, xaml);

			// Delete the types and assemblies
			bool hasErrors = false;
			foreach (Guid id in deleteInfo.Item2)
			{
				try
				{
					service.Delete(PluginType.EntityLogicalName, id);
				}
				catch (FaultException<OrganizationServiceFault>)
				{
					hasErrors = true;
				}
			}

			foreach (Guid id in deleteInfo.Item1)
			{
				try
				{
					service.Delete(PluginAssembly.EntityLogicalName, id);
				}
				catch (FaultException<OrganizationServiceFault>)
				{
					hasErrors = true;
				}
			}

			if (hasErrors)
			{
				throw new InvalidOperationException("Unable to clean-up remaining instrumented assemblies. It is recommended that you manually clean-up these assemblies and types.");
			}
		}

		private static Tuple<ActivityAssemblyCompilerConfiguration, ActivityAssemblyCompilerConfiguration> InstantiateWorkflowAssemblyConfiguration(
			string keyFileName, Dictionary<Guid, PluginAssembly> assemblies, Dictionary<Guid, PluginType> types, string baseAssemblyName,
			out Tuple<DateTime, DateTime> lastModified)
		{
			// Step #1: Retrieve the version information about the currently running assembly
			Tuple<string, string, string> compilerInfo = ProfilerCodeGenerationUtility.GetAssemblyVersionAndCulture(typeof(Entity).Assembly);

			// Step #2: Loop through each assembly and create two (isolated and non-isolated) consolidated assembly configurations
			Dictionary<Guid, Tuple<Assembly, ActivityAssemblyCompilerConfiguration>> loadedAssemblies =
				new Dictionary<Guid, Tuple<Assembly, ActivityAssemblyCompilerConfiguration>>();

			ActivityAssemblyCompilerConfiguration isolatedAssembly = null;
			ActivityAssemblyCompilerConfiguration nonIsolatedAssembly = null;
			DateTime lastModifiedIsolated = DateTime.MinValue;
			DateTime lastModifiedNonIsolated = DateTime.MinValue;
			foreach (PluginAssembly sdkAssembly in assemblies.Values)
			{
				// Load the assembly
				Assembly assembly;
				try
				{
					assembly = Assembly.Load(Convert.FromBase64String(sdkAssembly.Content));
				}
				catch (Exception ex)
				{
					throw new InvalidOperationException("Unable to load the assembly: " + sdkAssembly.Id, ex);
				}

				// Store the last modified on date
				ActivityAssemblyCompilerConfiguration assemblyConfiguration;
				DateTime modifiedOn = sdkAssembly.ModifiedOn ?? DateTime.MinValue;
				switch (sdkAssembly.IsolationMode.Value)
				{
					case 1: // None

						if (modifiedOn > lastModifiedNonIsolated)
						{
							lastModifiedNonIsolated = modifiedOn;
						}

						if (null == nonIsolatedAssembly)
						{
							nonIsolatedAssembly = new ActivityAssemblyCompilerConfiguration(string.Format(CultureInfo.InvariantCulture,
								ProfilerActivityAssemblyNameFormat, baseAssemblyName, "Isolated"), compilerInfo.Item1, compilerInfo.Item2,
								keyFileName);
						}

						assemblyConfiguration = nonIsolatedAssembly;
						break;
					case 2: // Isolated
						if (modifiedOn > lastModifiedIsolated)
						{
							lastModifiedIsolated = modifiedOn;
						}

						if (null == isolatedAssembly)
						{
							isolatedAssembly = new ActivityAssemblyCompilerConfiguration(string.Format(CultureInfo.InvariantCulture,
								ProfilerActivityAssemblyNameFormat, baseAssemblyName, "None"), compilerInfo.Item1, compilerInfo.Item2,
								keyFileName);
						}

						assemblyConfiguration = isolatedAssembly;
						break;
					default:
						throw new NotImplementedException("Isolation Mode = " + sdkAssembly.IsolationMode.Value);
				}

				// Add to the loaded to the loaded assemblies list
				loadedAssemblies.Add(sdkAssembly.Id,
					new Tuple<Assembly, ActivityAssemblyCompilerConfiguration>(assembly, assemblyConfiguration));
			}

			// Add the types
			AddWorkflowTypeConfiguration(loadedAssemblies, types);

			// Provide the values to the caller
			lastModified = new Tuple<DateTime, DateTime>(lastModifiedIsolated, lastModifiedNonIsolated);
			return new Tuple<ActivityAssemblyCompilerConfiguration, ActivityAssemblyCompilerConfiguration>(isolatedAssembly, nonIsolatedAssembly);
		}

		private static Dictionary<Guid, PluginAssembly> RetrieveWorkflowAssemblies(IOrganizationService service,
			Dictionary<Guid, List<Guid>> assemblies, out List<object> pluginIds)
		{
			QueryExpression query = new QueryExpression(PluginAssembly.EntityLogicalName);
			query.ColumnSet = new ColumnSet("name", "culture", "version", "sourcetype", "content", "isolationmode", "modifiedon");

			pluginIds = new List<object>();
			if (null != assemblies && 0 != assemblies.Count)
			{
				List<object> ids = new List<object>();
				foreach (KeyValuePair<Guid, List<Guid>> assembly in assemblies)
				{
					ids.Add(assembly.Key);

					foreach (Guid id in assembly.Value)
					{
						pluginIds.Add(id);
					}
				}

				query.Criteria.AddCondition("pluginassemblyid", ConditionOperator.In, ids.ToArray());
			}

			Dictionary<Guid, PluginAssembly> sdkAssemblies = new Dictionary<Guid, PluginAssembly>();
			foreach (Entity entity in service.RetrieveMultiple(query).Entities)
			{
				sdkAssemblies.Add(entity.Id, entity.ToEntity<PluginAssembly>());
			}

			return sdkAssemblies;
		}

		private static Dictionary<Guid, PluginType> RetrieveWorkflowTypes(IOrganizationService service, List<object> pluginIds)
		{
			QueryExpression pluginQuery = new QueryExpression(PluginType.EntityLogicalName);
			pluginQuery.ColumnSet = new ColumnSet("typename", "workflowactivitygroupname", "name", "modifiedon", "pluginassemblyid");
			pluginQuery.Criteria.AddCondition("isworkflowactivity", ConditionOperator.Equal, true);
			pluginQuery.Criteria.AddCondition("plugintypeid", ConditionOperator.In, pluginIds.ToArray());

			EntityCollection results = service.RetrieveMultiple(pluginQuery);

			Dictionary<Guid, PluginType> sdkTypes = new Dictionary<Guid, PluginType>();
			foreach (Entity entity in results.Entities)
			{
				sdkTypes.Add(entity.Id, entity.ToEntity<PluginType>());
			}

			return sdkTypes;
		}

		private static Entity RetrieveProfilerWorkflow(IOrganizationService service, Guid workflowId, params string[] columns)
		{
			ColumnSet cols = new ColumnSet("statecode", "description");
			if (null != columns)
			{
				cols.AddColumns(columns);
			}

			Workflow originalWorkflow = service.Retrieve(Workflow.EntityLogicalName, workflowId, cols).ToEntity<Workflow>();

			Tuple<Collection<Guid>, DateTime, bool> profiledWorkflow = ReadProfiledObjectConfiguration(originalWorkflow.Description);
			if (0 != profiledWorkflow.Item1.Count)
			{
				return originalWorkflow;
			}

			QueryExpression query = new QueryExpression(Workflow.EntityLogicalName);
			query.ColumnSet = cols;
			query.Criteria.AddCondition("type", ConditionOperator.Equal, 1);
			query.Criteria.AddCondition("description", ConditionOperator.BeginsWith, string.Format(CultureInfo.InvariantCulture, "{0}{1}|",
				ProfilerWorkflowDescriptionPrefix, workflowId));

			EntityCollection workflows = service.RetrieveMultiple(query);
			if (0 == workflows.Entities.Count)
			{
				return null;
			}

			return workflows[0];
		}

		private static bool DeleteProfiledWorkflow(IOrganizationService service, Guid originalWorkflowId)
		{
			Entity entity = RetrieveProfilerWorkflow(service, originalWorkflowId);
			if (null == entity)
			{
				return false;
			}

			if (WorkflowState.Activated == entity.ToEntity<Workflow>().StateCode)
			{
				SetStateRequest request = new SetStateRequest();
				request.EntityMoniker = entity.ToEntityReference();
				request.State = new OptionSetValue((int)WorkflowState.Draft);
				request.Status = new OptionSetValue(-1);

				service.Execute(request);
			}

			service.Delete(Workflow.EntityLogicalName, entity.Id);
			return true;
		}

		private static void AddWorkflowTypeConfiguration(Dictionary<Guid, Tuple<Assembly, ActivityAssemblyCompilerConfiguration>> loadedAssemblies,
			Dictionary<Guid, PluginType> types)
		{
			foreach (PluginType sdkType in types.Values)
			{
				Tuple<Assembly, ActivityAssemblyCompilerConfiguration> assembly;
				if (!loadedAssemblies.TryGetValue(sdkType.PluginAssemblyId.Id, out assembly))
				{
					throw new ArgumentOutOfRangeException("loadedAssemblies", sdkType.Id, "Assembly Id is not contained in the collection.");
				}

				// Load the type
				Type type = assembly.Item1.GetType(sdkType.TypeName, false, false);
				if (null == type)
				{
					throw new ArgumentOutOfRangeException("types", sdkType.TypeName, "Type doesn't exist in the specified assembly.");
				}

				// Add the type to the configuration
				assembly.Item2.Types.Add(sdkType.Id,
					new ActivityTypeCompilerConfiguration(sdkType.Id, ProfilerNamespace, ProfilerTypePrefix + sdkType.Id.ToString("N"), type));
			}
		}

		private static Tuple<Guid, IDictionary<Guid, PluginType>> CreateWorkflowAssembliesAndTypes(IOrganizationService service,
			ActivityAssemblyCompilerConfiguration configuration, Dictionary<Guid, PluginType> types,
			OptionSetValue isolationMode, DateTime lastModified, IEnumerable<Guid> mappedAssemblies)
		{
			CompiledAssembly compiledAssembly = ProfilerCodeGenerationUtility.CompileInstrumentedActivities(configuration);

			// Create the new SDK assembly
			PluginAssembly sdkAssembly = new PluginAssembly();
			sdkAssembly.Id = Guid.NewGuid();
			sdkAssembly.IsolationMode = isolationMode;
			sdkAssembly.Content = Convert.ToBase64String(compiledAssembly.Assembly);
			sdkAssembly.Name = compiledAssembly.Name;
			sdkAssembly.Version = compiledAssembly.Version;
			sdkAssembly.Culture = compiledAssembly.Culture;
			sdkAssembly.PublicKeyToken = compiledAssembly.PublicKeyToken;
			sdkAssembly.Description = CreateProfiledObjectConfiguration(mappedAssemblies, true);

			// Add each type that was instrumented
			EntityCollection sdkTypes = new EntityCollection();
			sdkAssembly.RelatedEntities[new Relationship("pluginassembly_plugintype")] = sdkTypes;

			Dictionary<Guid, PluginType> typeMapping = new Dictionary<Guid, PluginType>();
			foreach (ActivityTypeCompilerConfiguration type in configuration.Types.Values)
			{
				PluginType sdkType;
				if (!types.TryGetValue(type.Id, out sdkType))
				{
					continue;
				}

				// Instantiate the type
				PluginType newType = new PluginType()
				{
					Id = Guid.NewGuid(),
					Description = sdkType.Description,
					FriendlyName = Guid.NewGuid().ToString(),
					Name = sdkType.Name + ProfiledStepNameSuffix,
					WorkflowActivityGroupName = sdkType.WorkflowActivityGroupName + ProfiledStepNameSuffix,
					PluginAssemblyId = sdkAssembly.ToEntityReference(),
					TypeName = ProfilerNamespace + "." + type.TypeName
				};

				// Store the ID
				typeMapping.Add(sdkType.Id, newType);

				// Add the type to the entity
				sdkTypes.Entities.Add(newType.ToEntity<Entity>());
			}

			// Check if the assembly already exists
			UpdateAssemblyEntityState(service, sdkAssembly, sdkTypes, lastModified);
			if (EntityState.Changed == sdkAssembly.EntityState)
			{
				service.Update(sdkAssembly.ToEntity<Entity>());
			}
			else
			{
				// Create the assembly
				sdkAssembly.Id = service.Create(sdkAssembly.ToEntity<Entity>());
			}

			// Loop through the types and set the assembly metadata on the objects. This is required further on in the code
			foreach (PluginType type in typeMapping.Values)
			{
				type["assemblyname"] = sdkAssembly.Name;
				type["version"] = sdkAssembly.Version;
				type["culture"] = sdkAssembly.Culture;
				type["publickeytoken"] = sdkAssembly.PublicKeyToken;
			}

			return new Tuple<Guid, IDictionary<Guid, PluginType>>(sdkAssembly.Id, typeMapping);
		}

		private static string GenerateDefaultKeyFileNameIfMissing(string keyFileName)
		{
			if (!string.IsNullOrWhiteSpace(keyFileName))
			{
				return keyFileName;
			}

			// Check if the default file already exists
			string outputFileName = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location),
				ProfilerWorkflowKeyDefaultFileName);
			if (File.Exists(outputFileName))
			{
				return outputFileName;
			}

			// Retrieve the file from the embedded resources
			try
			{
				byte[] keyBytes = Resources.PluginProfilerWorkflowDefaultKey;
				if (null == keyBytes)
				{
					throw new InvalidOperationException("Default Profiler Workflow Key is not embedded as a resource.");
				}

				File.WriteAllBytes(outputFileName, keyBytes);

				return outputFileName;
			}
			catch (Exception ex)
			{
				throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
					"Unable to generate a default key to use to sign the workflow shim assembly. Create a key (using sn -k) and store it in \"{0}\".",
					outputFileName), ex);
			}
		}

		private static byte[] LoadSolutionFile()
		{
			const string SolutionFileName = "PluginProfiler.Solution.zip";

			string fileName;
			if (File.Exists(SolutionFileName))
			{
				fileName = SolutionFileName;
			}
			else
			{
				fileName = Path.Combine(@"..\Solutions\PluginProfiler", SolutionFileName);
				if (!File.Exists(fileName))
				{
					throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
						"Unable to locate the \"{0}\" file. Make sure that it is in the same directory as the {1} assembly.",
						SolutionFileName, Path.GetFileName(typeof(ProfilerManagementUtility).Assembly.Location)));
				}
			}

			// Load the solution file
			return File.ReadAllBytes(fileName);
		}
		#endregion
	}
}
