# AI App Execution Prompt (Authoritative)

You are implementing DataverseDebugger.App alignment PRs (PR-A01..PR-A05).

## Non-Negotiable Rules
- Preserve existing behavior unless explicitly changed by the current PR.
- Do not add new features.
- Do not refactor for cleanliness.
- Do not change Runner projects or protocol contracts.
- App is a thin host; Runner is authoritative for execution semantics.

## Runner Configuration Facts (Confirmed From Runner Source)
The Runner currently reads these environment variables:
- `DATAVERSE_DEBUGGER_HOST_PID` (read in Runner `Program.cs`)
- `DATAVERSE_DEBUGGER_ALLOW_LIVE_WRITES` (constant `RunnerExecutionOptions.AllowLiveWritesEnvVar`)

ExecutionMode is not read from environment variables in the Runner; it is resolved from request payload fields
(e.g., `PluginInvokeRequest.ExecutionMode`, with legacy fallback to `WriteMode`).
