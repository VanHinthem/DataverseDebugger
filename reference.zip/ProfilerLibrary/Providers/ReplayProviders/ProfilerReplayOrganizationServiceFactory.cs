﻿using System;
using System.Collections.Generic;
using System.Reflection;

using PluginProfiler.Library.Reporting;
using PluginProfiler.Plugins;

using Microsoft.Xrm.Sdk;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Implementation of the IOrganizationServiceFactory which returns an IOrganizationService which returns the results.
	/// </summary>
	internal sealed class ProfilerReplayOrganizationServiceFactory : IOrganizationServiceFactory
	{
		private readonly ProfilerReplayOrganizationService ReplayService;

		/// <summary>
		/// Instantiates an instance of the ProfilerReplayOrganizationServiceFactory class.
		/// </summary>
		/// <param name="report">Execution report</param>
		/// <param name="pluginAssembly">Assembly for the plug-in that will be executed</param>
		/// <param name="events">Events that should be replayed.</param>
		internal ProfilerReplayOrganizationServiceFactory(ProfilerExecutionReport report, Assembly pluginAssembly,
			Queue<ProfilerReplayEvent> events)
		{
			if (null == events)
			{
				throw new ArgumentNullException("events");
			}

			this.ReplayService = new ProfilerReplayOrganizationService(report, pluginAssembly, events);
		}

		#region IOrganizationServiceFactory Members
		public IOrganizationService CreateOrganizationService(Guid? userId)
		{
			return this.ReplayService;
		}
		#endregion
	}
}
