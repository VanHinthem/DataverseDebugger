﻿using System;
using System.Text;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

using PluginProfiler.Library;

namespace PluginProfiler.Debugger
{
	/// <summary>
	/// Plug-in operation type to be handled by the Profiler
	/// </summary>
	internal sealed class PluginOperationHandler : OperationHandlerBase
	{
		private const string EntityName = "sdkmessageprocessingstep";

		#region Constructors
		internal PluginOperationHandler(string assemblyFilePath, string typeName, string profilePath, string unsecureConfiguration,
			string secureConfiguration, int? maxNumberOfExecutions, bool persistToEntity, string persistenceSessionKey,
			bool excludeSecureInformation, Guid pluginStepId, string name)
			: base(assemblyFilePath, typeName, profilePath, persistToEntity, persistenceSessionKey, excludeSecureInformation,
				Guid.Empty == pluginStepId ? null : new EntityReference(EntityName, pluginStepId), name)
		{
			this.UnsecureConfiguration = unsecureConfiguration;
			this.SecureConfiguration = secureConfiguration;
			this.MaxNumberOfExecutions = maxNumberOfExecutions;
		}
		#endregion

		#region Methods
		/// <summary>
		/// Retrieves the application configuration
		/// </summary>
		internal override OperationConfiguration GetOperationConfiguration()
		{
			return new PluginOperationConfiguration(this.AssemblyFilePath, this.TypeName, this.ProfilePath,
				this.UnsecureConfiguration, this.SecureConfiguration);
		}

		/// <summary>
		/// Enables profiling on the operation
		/// </summary>
		/// <param name="service">Service that should be used to enable the profiler.</param>
		/// <returns>Id for the profiled version of the operation</returns>
		internal override Guid Enable(IOrganizationService service)
		{
			return ProfilerManagementUtility.EnablePlugin(service, this.Id.Id, this.PersistToEntity, this.PersistenceSessionKey,
				this.MaxNumberOfExecutions, !this.ExcludeSecureInformation);
		}

		/// <summary>
		/// Enables profiling on the operation
		/// </summary>
		/// <param name="service">Service that should be used to disable the profiler.</param>
		internal override void Disable(IOrganizationService service)
		{
			ProfilerManagementUtility.DisablePlugin(service, this.Id.Id);
		}

		/// <summary>
		/// Lists steps that exist for the current operation
		/// </summary>
		/// <param name="service">Service that should be used to list steps.</param>
		internal override string ListSteps(IOrganizationService service)
		{
			throw new NotSupportedException("Workflow steps cannot be listed for plug-ins.");
		}

		/// <summary>
		/// Validate the operation's parameters
		/// </summary>
		/// <param name="operation">Operation to be executed</param>
		/// <param name="errors">Errors that should be returned</param>
		/// <returns>True if the validation succeeded</returns>
		internal override bool Validate(DebuggerOperation operation, StringBuilder errors)
		{
			switch (operation)
			{
				case DebuggerOperation.Enable:
				case DebuggerOperation.Disable:
					return true;
				default:
					errors.AppendFormat("Plug-ins don't support {0} operations.{1}", operation, Environment.NewLine);
					return false;
			}
		}

		/// <summary>
		/// Generates a query for debugger operations based on the operation type
		/// </summary>
		/// <param name="operation">Operation that will be executed by the debugger</param>
		/// <returns>QueryExpression that will retrieve existing operations</returns>
		internal override QueryBase GenerateNameQuery(DebuggerOperation operation)
		{
			QueryByAttribute query = new QueryByAttribute(EntityName);
			query.ColumnSet = new ColumnSet();

			switch (operation)
			{
				case DebuggerOperation.Enable:
					query.AddAttributeValue("name", this.Name);

					// StateCode 0 = Active
					query.AddAttributeValue("statecode", 0);
					break;
				case DebuggerOperation.Disable:

					// All steps that are profiled will have the profiler suffix added
					query.AddAttributeValue("name", this.Name + ProfilerManagementUtility.ProfiledStepNameSuffix);

					// StateCode 1 = Inactive (or Disabled)
					query.AddAttributeValue("statecode", 1);
					break;
				default:
					throw new NotSupportedException("DebuggerOperation = " + operation);
			}

			return query;
		}
		#endregion

		#region Properties
		private string UnsecureConfiguration { get; set; }

		private string SecureConfiguration { get; set; }

		private int? MaxNumberOfExecutions { get; set; }

		/// <summary>
		/// Plural Name for the record type
		/// </summary>
		internal override string PluralRecordName
		{
			get
			{
				return "steps";
			}
		}
		#endregion
	}
}
