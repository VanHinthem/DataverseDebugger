# PR-A01 – ExecutionMode-First App Model (No Behavior Change)

## Objective
Introduce an ExecutionMode-first settings model and UI while preserving current runtime behavior.

## Invariants
- No Runner changes.
- No Protocol changes.
- Preserve existing behavior.

## Target Files (In-Scope)
- `Models/RunnerSettingsModel.cs`
- `Models/AppSettingsModel.cs`
- `Views/SettingsView.xaml`
- `MainWindow.xaml.cs` (settings persistence wiring only)

## Required Changes
1. `RunnerSettingsModel`
   - Add `ExecutionMode` (string), default **Hybrid**.
   - Add `AllowLiveWrites` (bool), default **false**.
   - Keep `WriteMode` as derived compatibility value (see PR-A00 mapping).

2. Settings UI
   - Replace “Write mode” selector with:
     - ExecutionMode selector: Offline/Hybrid/Online
     - AllowLiveWrites toggle (disabled unless Online; fully enforced in PR-A02)

3. Persistence + Migration
   - Store ExecutionMode and AllowLiveWrites.
   - Migrate from legacy WriteMode per PR-A00.

## Acceptance Criteria (Manual)
- App builds and launches.
- ExecutionMode defaults to Hybrid on clean settings.
- AllowLiveWrites defaults to false.
- Existing settings migrate correctly from previous WriteMode.
- No Runner start/config behavior changes in this PR.
