﻿using System;

using Microsoft.Xrm.Sdk;

using PluginProfiler.Library.Reporting;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Configuration for debugging a profiler session
	/// </summary>
	[Serializable]
	public sealed class ProfilerContextExecutionConfiguration : ProfilerExecutionConfiguration
	{
		private readonly ITracingService TracingService;
		private readonly ProfilerContextAppDomainOrganizationServiceFactory ServiceFactory;
		private readonly IServiceEndpointNotificationService ServiceEndpointNotification;

		/// <summary>
		/// Instantiates an instance of the ProfilerContextExecutionConfiguration class
		/// </summary>
		/// <param name="operation">Configuration for the operation</param>
		/// <param name="reporting">Reporting configuration for the profiler</param>
		/// <param name="factory">Factory that should be used to generate proxies</param>
		/// <param name="tracing">Tracing service that should be used</param>
		/// <param name="serviceEndpointNotificationService">AppFabric Notification Service</param>
		public ProfilerContextExecutionConfiguration(OperationConfiguration operation, ProfilerReportingConfiguration reporting,
			ITracingService tracing, ProfilerContextOrganizationServiceFactory factory,
			IServiceEndpointNotificationService serviceEndpointNotificationService)
			: base(operation, reporting)
		{
			if (null == factory)
			{
				throw new ArgumentNullException("factory");
			}

			this.TracingService = tracing ?? new ProfilerConsoleTracingService();
			this.ServiceFactory = new ProfilerContextAppDomainOrganizationServiceFactory(factory);
			this.ServiceEndpointNotification = serviceEndpointNotificationService;
		}

		internal override PluginServicesConfiguration GetServices(AppDomainProxy proxy, ProfilerExecutionConfiguration configuration,
			ProfilerExecutionReport executionReport, Guid currentUserId)
		{
			if (null == proxy)
			{
				throw new ArgumentNullException("proxy");
			}

			this.ServiceFactory.CurrentUserId = currentUserId;
			this.ServiceFactory.ProxyTypesAssembly = proxy.ProxyTypesAssembly;
			this.ServiceFactory.IncludeProxyTypesInDefaultDomain = configuration.ReportingConfiguration.IncludeProxyTypes;
			this.ServiceFactory.Report = executionReport;

			return new PluginServicesConfiguration(this.TracingService, this.ServiceFactory,
				proxy.PluginReport.HasServiceEndpointNotificationService ? this.ServiceEndpointNotification : null);
		}
	}
}