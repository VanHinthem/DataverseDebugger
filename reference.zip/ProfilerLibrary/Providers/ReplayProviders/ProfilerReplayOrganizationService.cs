﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.ServiceModel;

using PluginProfiler.Library.Reporting;
using PluginProfiler.Plugins;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Security;
using System.Security.Permissions;

namespace PluginProfiler.Library
{
	/// <summary>
	/// IOrganizationService which replays events that were captured on the server.
	/// </summary>
	internal sealed class ProfilerReplayOrganizationService : ProfilerReplayService<OrganizationServiceReplayEvent>, IOrganizationService
	{
		private Assembly _pluginAssembly;
		private ProfilerExecutionReport _report;

		/// <summary>
		/// Instantiates an instance of the ProfilerReplayOrganizationService class.
		/// </summary>
		/// <param name="report">Execution report</param>
		/// <param name="pluginAssembly">Assembly for the plug-in that will be executed</param>
		/// <param name="events">Events to be replayed</param>
		public ProfilerReplayOrganizationService(ProfilerExecutionReport report, Assembly pluginAssembly,
			Queue<ProfilerReplayEvent> events)
			: base(events)
		{
			this._report = report;
			this._pluginAssembly = pluginAssembly;
		}

		#region IOrganizationService Members
		public Guid Create(Entity entity)
		{
			return this.NextReturnValue<ProfilerCreateClientOperation, Guid>(ProfilerOrganizationServiceClientOperation.Create, entity);
		}

		public Entity Retrieve(string entityName, Guid id, ColumnSet columnSet)
		{
			return this.NextReturnValue<ProfilerRetrieveClientOperation, Entity>(ProfilerOrganizationServiceClientOperation.Retrieve,
				entityName, id, columnSet);
		}

		public EntityCollection RetrieveMultiple(QueryBase query)
		{
			return this.NextReturnValue<ProfilerRetrieveMultipleClientOperation, EntityCollection>(
				ProfilerOrganizationServiceClientOperation.RetrieveMultiple, query);
		}

		public void Update(Entity entity)
		{
			this.NextReturnValue<ProfilerUpdateClientOperation, object>(ProfilerOrganizationServiceClientOperation.Update, entity);
		}

		public void Delete(string entityName, Guid id)
		{
			this.NextReturnValue<ProfilerDeleteClientOperation, object>(ProfilerOrganizationServiceClientOperation.Delete,
				entityName, id);
		}

		public void Associate(string entityName, Guid id, Relationship relationship, EntityReferenceCollection relatedEntities)
		{
			this.NextReturnValue<ProfilerAssociateClientOperation, object>(ProfilerOrganizationServiceClientOperation.Associate,
				entityName, id, relationship, relatedEntities);
		}

		public void Disassociate(string entityName, Guid id, Relationship relationship, EntityReferenceCollection relatedEntities)
		{
			this.NextReturnValue<ProfilerDisassociateClientOperation, object>(ProfilerOrganizationServiceClientOperation.Disassociate,
				entityName, id, relationship, relatedEntities);
		}

		public OrganizationResponse Execute(OrganizationRequest request)
		{
			return this.NextReturnValue<ProfilerExecuteClientOperation, OrganizationResponse>(
				ProfilerOrganizationServiceClientOperation.Execute, request);
		}
		#endregion

		#region Private Methods
		private TResult NextReturnValue<TClientOperation, TResult>(ProfilerOrganizationServiceClientOperation operation,
			params object[] inputParameters)
			where TClientOperation : ProfilerOrganizationServiceClientOperationBase
		{
			bool hasOutputParameter = (typeof(TResult) != typeof(object));

			OrganizationServiceReplayEvent replayEvent = this.NextEvent();
			if (replayEvent.OperationName != operation.ToString())
			{
				throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
					"Expected {0} operation in the event queue, but found {1}.", operation, replayEvent.OperationName));
			}

			OrganizationServiceFault fault = null;

			PermissionSet set = new PermissionSet(PermissionState.Unrestricted);

			//If the result has been set, deserialize it
			object result = null;
			if (null != replayEvent.Result)
			{
				set.Assert();

				try
				{
					result = replayEvent.Result.GetDeserializedValue(this._pluginAssembly);
				}
				finally
				{
					CodeAccessPermission.RevertAssert();
				}
			}

			if (replayEvent.IsFault)
			{
				fault = (OrganizationServiceFault)result;
			}

			//If client operations are being recorded, add them to the list
			if (null != this._report)
			{
				//All of the operation classes have constructors with the following format:
				//- Type(Exception ex, <Input Parameter #1>, <Input Parameter #2>, ..., [<Output Parameter>]
				int additionalParameters = (hasOutputParameter ? 2 : 1);

				object[] parameters;
				if (null == inputParameters)
				{
					parameters = new object[additionalParameters];
				}
				else
				{
					parameters = new object[inputParameters.Length + additionalParameters];
					Array.Copy(inputParameters, 0, parameters, 1, inputParameters.Length);
				}

				parameters[0] = fault;
				if (hasOutputParameter && null == fault)
				{
					parameters[parameters.Length - 1] = result;
				}

				//Assert full trust in order to instantiate the operation
				set.Assert();

				TClientOperation clientOperation;
				try
				{
					clientOperation = (TClientOperation)Activator.CreateInstance(typeof(TClientOperation),
						BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, parameters, CultureInfo.InvariantCulture);

					//Create the operation and add it.
					this._report.AddOperationFromAppDomain(clientOperation.GetType(),
						ProfilerSharedUtility.Serialize(clientOperation.GetType(), clientOperation));
				}
				finally
				{
					CodeAccessPermission.RevertAssert();
				}
			}

			if (null == fault)
			{
				try
				{
					return (TResult)result;
				}
				catch (InvalidCastException ex)
				{
					throw new InvalidOperationException("Invalid type for return type while deserializing result.", ex);
				}
				catch (NullReferenceException)
				{
					throw new InvalidOperationException("Invalid type for return type while deserializing result.");
				}
			}
			else
			{
				throw new FaultException<OrganizationServiceFault>(fault, fault.Message);
			}
		}
		#endregion
	}
}
