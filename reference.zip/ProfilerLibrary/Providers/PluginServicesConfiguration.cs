﻿using System;
using System.Collections.Generic;

using PluginProfiler.Library.Reporting;

using Microsoft.Xrm.Sdk;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Services that will be used for debugging a profiler session
	/// </summary>
	public sealed class PluginServicesConfiguration
	{
		/// <summary>
		/// Instantiates an instance of the ProfilerContextServicesConfiguration class
		/// </summary>
		/// <param name="factory">Factory that will be used to generate the organization service</param>
		/// <param name="endpointNotification">IServiceEndpointNotificationService that should be used to replay against a Service Endpoint.</param>
		public PluginServicesConfiguration(IOrganizationServiceFactory factory,
			IServiceEndpointNotificationService endpointNotification)
			: this(new ProfilerConsoleTracingService(), factory, endpointNotification)
		{
		}

		/// <summary>
		/// Instantiates an instance of the ProfilerContextServicesConfiguration class
		/// </summary>
		/// <param name="tracing">Tracing service that should be used.</param>
		/// <param name="factory">Factory that will be used to generate the organization service</param>
		/// <param name="endpointNotification">IServiceEndpointNotificationService that should be used to replay against a Service Endpoint.</param>
		public PluginServicesConfiguration(ITracingService tracing, IOrganizationServiceFactory factory,
			IServiceEndpointNotificationService endpointNotification)
		{
			if (null == tracing)
			{
				throw new ArgumentNullException("tracing");
			}
			else if (null == factory)
			{
				throw new ArgumentNullException("factory");
			}

			this.Tracing = tracing;
			this.ServiceFactory = factory;
			this.ServiceEndpointNotification = endpointNotification;
			this.ClientOperations = new List<ProfilerClientOperationBase>();
		}

		#region Properties
		/// <summary>
		/// ITracingService to be used.
		/// </summary>
		internal ITracingService Tracing { get; private set; }

		/// <summary>
		/// IOrganizationServiceFactory factory to be used
		/// </summary>
		internal IOrganizationServiceFactory ServiceFactory { get; private set; }

		/// <summary>
		/// IServiceEndpointNotificationService service to be used.
		/// </summary>
		internal IServiceEndpointNotificationService ServiceEndpointNotification { get; set; }

		/// <summary>
		/// Operations that were executed client-side
		/// </summary>
		public IList<ProfilerClientOperationBase> ClientOperations { get; private set; }
		#endregion
	}
}