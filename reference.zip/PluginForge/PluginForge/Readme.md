﻿## 😖 The Struggle: Debugging C# Dataverse Plugins

If you’ve ever written a plugin for Project Operations, you already know: debugging isn’t just hard — it’s a slog.

You don’t get instant feedback. You can’t just hit F5 and see what broke. Instead, you’re stuck in a frustrating cycle:

Compile the plugin.

Register it using the Plugin Registration Tool or through a DevOps pipeline.

Trigger it manually in the environment.

Hope your tracing service logs are enough to figure out what went wrong.

Recompile. Re-register. Repeat.

It’s slow. It’s painful. And it breaks your flow.

Integrated scenarios make things worse as we don't have integration tests.
Even with tracing, figuring out why something didn’t work requires mental gymnastics and a lot of patience.

That’s the reality many developers face daily.

What if we could debug the plugins as close to as how a plugin is executed in dataverse ? That's where we could use Plugin forge.

## Plugin Forge – Debugging Dataverse Plugins

**Plugin Forge** is a .NET-based testing tool built to **mock and debug Dataverse plugins** with ease.

With Plugin Forge, you can:

- Set the **target entity** for your plugin
- **Simulate plugin execution** in different contexts
- **Step through the code** in debug mode
- Quickly **isolate and fix logic issues**

This tool is especially useful for plugin-heavy Dynamics 365 / Power Platform projects, where test coverage and debugging are typically painful.

---

## Getting Started

## How It Works

Plugin Forge exposes a **`PluginSimulationBase`** class, allowing you to simulate a plugin execution environment locally — no need to deploy to test.

It enables:

- Setting up the plugin context (entity, depth, message, stage, etc.)
- Injecting input/output parameters
- Creating `IOrganizationService`

---

## Usage Guide

### 1. **Write a Test**

Add a test under `SharedSrc\PluginForge\Plugins` folder

```csharp
using System;
using Microsoft.Dynamics.ProjectOperationsDualWrite.Plugins;
using Microsoft.Dynamics.ProjectOperationsDualWrite.Proxies;
using Microsoft.Xrm.Sdk;
using Xunit;

namespace Microsoft.Dynamics.ProjectOperations.PluginForge.Plugins
{

    public class OnAddressCreateHandlerTest : PluginSimulationBase<OnAddressCreateActionHandler>
    {
        [Fact]
        public void test()
        {
            LocalPluginExecutionContextBuilder localPluginExecutionContextBuilder = new LocalPluginExecutionContextBuilder();

            EntityReference entityReference = new EntityReference();

            entityReference.LogicalName = Account.EntityLogicalName;
            entityReference.Id = Guid.Parse("d8855b75-3c31-f011-8c4e-000d3a58f097");

            localPluginExecutionContextBuilder.WithTargetEntityReference(entityReference);

            var context = localPluginExecutionContextBuilder.Build();

            this.SetExecutionContext(context);

            this.Execute();
        }
    }
}

```

### 2. **Update settings file**

Navigate to settings.json file in `SharedSrc\PluginForge` folder and point to your environment.

sample

```json
{
    "OrganizationUrl": "https://aurorabapenv51c63.crm10.dynamics.com/",
    "FQDNOrgUrl": "https://aurorabapenv51c63.crm10.dynamics.com/",
    "Audience": null,
    "UserPrincipalName": "aurorauser01@auroraprojopsintegration01.onmicrosoft.com",
    "TenantId": "e1cbfdbb-a786-4d71-a661-47db9bcecb6a",
    "SubjectName": "aurorauser01.auroraprojopsintegration01.azclient.ms"
}
```

---

## Debugging Plugins

Just set breakpoints in your plugin and run your tests in **debug mode**. You’ll be able to **step through the logic** as if it were running in a live Dataverse environment.

---

## ❓ FAQ

**Q: Can this test custom APIs or workflows?**  
A: It can debug all classes which inherits from `IPlugin` interface

**Q: Are there any edge cases which the tool can miss?**  
A: Yes, since you are debugging the plugin in your dev workstation, the environment is not exactly same as the dataverse environment where your plugin actually executes . Some of the API calls
may work inside your workstation but may fail when it executes inside dataverse environments. For eg: calls to System.IO.File .
