# AI App Execution Prompt (Authoritative)

You are implementing DataverseDebugger.App alignment PRs.

MANDATORY RULES:
- Preserve existing behavior unless explicitly changed by the PR.
- Do NOT introduce new features.
- Do NOT refactor for cleanliness.
- Do NOT infer execution semantics.
- Do NOT modify Runner code.

The App is a thin host. The Runner is authoritative.

If a requirement is ambiguous, STOP and ask for clarification.
