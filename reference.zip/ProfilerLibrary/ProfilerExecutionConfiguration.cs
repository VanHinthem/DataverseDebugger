﻿using System;

using PluginProfiler.Library.Reporting;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Configuration for executing a profiler session
	/// </summary>
	[Serializable]
	public abstract class ProfilerExecutionConfiguration
	{
		/// <summary>
		/// Instantiates an instance of the ProfilerExecutionConfiguration class
		/// </summary>
		/// <param name="operation">Configuration for the operation for execution</param>
		/// <param name="reporting">Reporting configuration for the profiler</param>
		internal ProfilerExecutionConfiguration(OperationConfiguration operation, ProfilerReportingConfiguration reporting)
		{
			if (null == operation)
			{
				throw new ArgumentNullException("operation");
			}
			else if (null == reporting)
			{
				throw new ArgumentNullException("reporting");
			}

			this.OperationConfiguration = operation;
			this.ReportingConfiguration = reporting;
			this.ProfilerTracingService = reporting.ProfilerTracingService;
		}

		#region Methods
		internal abstract PluginServicesConfiguration GetServices(AppDomainProxy proxy, ProfilerExecutionConfiguration configuration,
			ProfilerExecutionReport executionReport, Guid currentUserId);
		#endregion

		#region Properties
		/// <summary>
		/// Configuration for the operation
		/// </summary>
		public OperationConfiguration OperationConfiguration { get; private set; }

		/// <summary>
		/// Reporting configuration for the Profiler
		/// </summary>
		public ProfilerReportingConfiguration ReportingConfiguration { get; private set; }

		/// <summary>
		/// Tracer for the Profiler
		/// </summary>
		internal IProfilerTracingService ProfilerTracingService { get; private set; }
		#endregion
	}
}
