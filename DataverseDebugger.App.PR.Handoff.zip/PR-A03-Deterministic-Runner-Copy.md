# PR-A03 – Deterministic Runner Copy

## Objective
Runner must exist in App output after Build.

## Illegal Changes
- Runtime copy logic
- Publish behavior changes
