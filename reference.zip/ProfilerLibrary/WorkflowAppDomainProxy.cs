﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Security;
using System.Security.Permissions;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

using PluginProfiler.Library.Reporting;
using PluginProfiler.Plugins;

namespace PluginProfiler.Library
{
	/// <summary>
	/// AppDomainProxy that is used to replay or debug the workflow
	/// </summary>
	internal sealed class WorkflowAppDomainProxy : AppDomainProxy
	{
		/// <summary>
		/// Instantiate an instance of the WorkflowAppDomainProxy
		/// </summary>
		/// <param name="trustedAssemblies">List of assemblies that are trusted</param>
		private WorkflowAppDomainProxy(Dictionary<string, string> trustedAssemblies)
			: base(trustedAssemblies)
		{
		}

		#region Protected Methods
		/// <summary>
		/// Process the report to extract any required values from it
		/// </summary>
		/// <param name="report">Report that was generated</param>
		protected override void ProcessReport(ProfilerPluginReport report)
		{
			this.InputParameters = new Dictionary<string, object>();
			foreach (SerializedValue value in report.WorkflowInputParameters)
			{
				this.InputParameters.Add(value.Name, value.GetDeserializedValue(this.ProxyTypesAssembly));
			}
		}

		/// <summary>
		/// Retrieve the configuration that is to be used to instantiate the operation
		/// </summary>
		/// <param name="configuration">Configuration to be used</param>
		/// <param name="parameters">Parameters that should be provided when constructing the object</param>
		/// <returns>Constructor info</returns>
		protected override ConstructorInfo FindConstructor(ProfilerExecutionConfiguration configuration, out object[] parameters)
		{
			parameters = new object[0];
			return this.OperationInstanceType.GetConstructor(new Type[0]);
		}

		/// <summary>
		/// Retrieve the configuration that is to be used to instantiate the operation
		/// </summary>
		/// <param name="configuration">Configuration to be used</param>
		/// <param name="context">Context for the oepration</param>
		/// <param name="report">Execution report for the given execution</param>
		/// <returns>Constructor info</returns>
		protected override object PrepareExecution(ProfilerExecutionConfiguration configuration, IExecutionContext context,
			ProfilerExecutionReport report)
		{
			return new ProfilerServiceProvider(context, configuration.GetServices(this, configuration, report, context.UserId));
		}

		/// <summary>
		/// Execute the operation
		/// </summary>
		/// <param name="watch">Watch to be used while counting time</param>
		/// <param name="report">Execution report for the given execution</param>
		/// <param name="instance">Instance of the operation that should be used during execution</param>
		/// <param name="executionParameter">Parameter that should be used during execution</param>
		protected override void ExecuteCore(Stopwatch watch, ProfilerExecutionReport report, object instance, object executionParameter)
		{
			// Instantiate the WorkflowInvoker to prepare for executing the activity
			WorkflowInvoker invoker = new WorkflowInvoker((Activity)instance);
			AddExtensionsToWorkflowInvoker((IServiceProvider)executionParameter, invoker);

			// Execute the workflow
			watch.Start();
			invoker.Invoke(this.InputParameters);
			watch.Stop();
		}
		#endregion

		#region Properties
		private IDictionary<string, object> InputParameters { get; set; }
		#endregion

		#region Private Methods
		private void AddExtensionsToWorkflowInvoker(IServiceProvider provider, WorkflowInvoker invoker)
		{
			AddExtensionToWorkflowInvoker<IWorkflowContext>(provider, invoker);
			AddExtensionToWorkflowInvoker<IOrganizationServiceFactory>(provider, invoker);
			AddExtensionToWorkflowInvoker<IServiceEndpointNotificationService>(provider, invoker);
			AddExtensionToWorkflowInvoker<ITracingService>(provider, invoker);
		}

		private void AddExtensionToWorkflowInvoker<T>(IServiceProvider provider, WorkflowInvoker invoker)
			where T : class
		{
			// Currently, if instances of the extensions are added the workflow activity receives null back. However, using the generic Add
			// forces the WorkflowContext to query for the instance of the class which appears to work without issue.
			// TODO: Do this in a more generic way.
			if (null != provider.GetService(typeof(T)))
			{
				invoker.Extensions.Add<T>(delegate() { return ServiceProviderExtensions.GetService<T>(provider); });
			}
		}
		#endregion
	}
}