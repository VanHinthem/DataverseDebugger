﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Xml;

using PluginProfiler.Plugins.ServiceWrappers;

namespace PluginProfiler.Plugins
{
	/// <summary>
	/// Report of the data that was profiled
	/// </summary>
	[DataContract(Name = "Report", Namespace = "")]
	public sealed class ProfilerPluginReport : IExtensibleDataObject
	{
		private static readonly Version MinimumSupportedVersion =  new Version("1.0");
		private static readonly Version CurrentVersion = new Version("1.1");
		private const string UnformattedReportNode = "Report";
		private const string FormattedReportNode = "Profile";

		private List<ProfilerReplayEvent> _internalEventsList = new List<ProfilerReplayEvent>();
		private List<SerializedValue> _workflowInputParameters;
		private List<SerializedValue> _workflowOutputParameters;

		/// <summary>
		/// Instantiates an instance of the ProfilerPluginReport class for Context Executions
		/// </summary>
		/// <param name="context">IPluginExecutionContext for the plug-in</param>
		/// <param name="workflowStepId">Id for the workflow step</param>
		internal ProfilerPluginReport(ExecutionContextWrapper context, string workflowStepId)
		{
			if (null == context)
			{
				throw new ArgumentNullException("context");
			}

			this.IsContextReplay = true;
			this.OperationType = context.OperationType;
			this.Context = context.ToString();
			this.WorkflowStepId = workflowStepId;
			this.ProfileVersion = CurrentVersion.ToString();
		}

		/// <summary>
		/// Instantiates an instance of the ProfilerPluginReport class for actual plug-in executions.
		/// </summary>
		/// <param name="typeName">Full name of the plug-in that was executed</param>
		/// <param name="context">IPluginExecutionContext for the plug-in</param>
		/// <param name="workflowStepId">Id for the workflow step</param>
		/// <param name="configuration">Configuration that was used when the plug-in was instantiated</param>
		/// <param name="secureConfiguration">Secure configuration that was used when the plug-in was instantiated</param>
		internal ProfilerPluginReport(string typeName, ExecutionContextWrapper context, string workflowStepId,
			string configuration, string secureConfiguration)
			: this(context, workflowStepId)
		{
			if (string.IsNullOrWhiteSpace(typeName))
			{
				throw new ArgumentNullException("typeName");
			}

			this.TypeName = typeName;
			this.Configuration = configuration;
			this.SecureConfiguration = secureConfiguration;
			this.IsContextReplay = false;
			this.IsolationMode = context.IsolationMode;
		}

		#region Properties
		/// <summary>
		/// Full name of the plug-in that was executed
		/// </summary>
		[DataMember]
		public string TypeName { get; private set; }

		/// <summary>
		/// Type of operation that was executed
		/// </summary>
		[DataMember]
		public OperationType OperationType { get; private set; }

		/// <summary>
		/// Indicates that no plug-in was actually executed
		/// </summary>
		[DataMember]
		public bool IsContextReplay { get; private set; }

		/// <summary>
		/// IPluginExecutionContext for the plug-in
		/// </summary>
		[DataMember]
		public string Context { get; private set; }

		/// <summary>
		/// Configuration that was used when the plug-in was instantiated
		/// </summary>
		[DataMember]
		public string Configuration { get; private set; }

		/// <summary>
		/// Secure configuration that was used when the plug-in was instantiated
		/// </summary>
		[DataMember]
		public string SecureConfiguration { get; private set; }

		/// <summary>
		/// Id for the Workflow Step
		/// </summary>
		[DataMember]
		public string WorkflowStepId { get; private set; }

		/// <summary>
		/// Input Parameters for a Workflow Activity
		/// </summary>
		[DataMember]
		public IList<SerializedValue> WorkflowInputParameters
		{
			get
			{
				if (null == this._workflowInputParameters)
				{
					this._workflowInputParameters = new List<SerializedValue>();
				}

				return this._workflowInputParameters;
			}
		}

		/// <summary>
		/// Output Parameters for a Workflow Activity
		/// </summary>
		[DataMember]
		public IList<SerializedValue> WorkflowOutputParameters
		{
			get
			{
				if (null == this._workflowOutputParameters)
				{
					this._workflowOutputParameters = new List<SerializedValue>();
				}

				return this._workflowOutputParameters;
			}
		}

		/// <summary>
		/// Events that occurred while the plug-in was being profiled
		/// </summary>
		[DataMember]
		public IList<ProfilerReplayEvent> ReplayEvents
		{
			get
			{
				if (null == this._internalEventsList)
				{
					this._internalEventsList = new List<ProfilerReplayEvent>();
				}

				return this._internalEventsList;
			}
		}

		/// <summary>
		/// Start time for the constructor's execution
		/// </summary>
		[DataMember]
		public DateTime? ConstructorStartTime { get; private set; }

		/// <summary>
		/// Duration of the constructor's execution
		/// </summary>
		[DataMember]
		public long? ConstructorDurationInMilliseconds { get; private set; }

		/// <summary>
		/// Exception that occurred during construction (if any)
		/// </summary>
		[DataMember]
		public string ConstructorException { get; private set; }

		/// <summary>
		/// Start time for the plug-in's execution
		/// </summary>
		[DataMember]
		public DateTime? ExecutionStartTime { get; private set; }

		/// <summary>
		/// Duration of the plug-in's execution
		/// </summary>
		[DataMember]
		public long? ExecutionDurationInMilliseconds { get; private set; }

		/// <summary>
		/// Exception that occurred during execution (if any)
		/// </summary>
		[DataMember]
		public string ExecutionException { get; private set; }

		/// <summary>
		/// Indicates whether the IServiceEndpointNotificationService service was available during the plug-ins execution.
		/// </summary>
		[DataMember]
		public bool HasServiceEndpointNotificationService { get; set; }

		/// <summary>
		/// Indicates the type of isolation for the profiler's execution
		/// </summary>
		[DataMember]
		public int? IsolationMode { get; set; }

		/// <summary>
		/// Version of the profile
		/// </summary>
		[DataMember]
		public string ProfileVersion { get; private set; } 
		#endregion

		#region IExtensibleDataObject Members
		/// <summary>
		/// Contains any unknown parameters during deserialization
		/// </summary>
		public ExtensionDataObject ExtensionData { get; set; }
		#endregion

		#region Methods
		/// <summary>
		/// Deserializes the serialized ProfilerPluginReport
		/// </summary>
		/// <param name="serializedValue">Serialized ProfilerPluginReport instance</param>
		/// <param name="proxyTypesAssembly">Assembly with the proxy types in it</param>
		public static ProfilerPluginReport Deserialize(string serializedValue, Assembly proxyTypesAssembly)
		{
			if (string.IsNullOrWhiteSpace(serializedValue))
			{
				throw new ArgumentNullException("serializedValue");
			}

			try
			{
				ProfilerPluginReport report = PartialTrustSerializer.Deserialize<ProfilerPluginReport>(serializedValue, proxyTypesAssembly);

				// Determine the version number
				Version profileVersion;
				if (string.IsNullOrWhiteSpace(report.ProfileVersion))
				{
					profileVersion = MinimumSupportedVersion;
				}
				else
				{
					try
					{
						profileVersion = new Version(report.ProfileVersion);
					}
					catch (FormatException)
					{
						profileVersion = MinimumSupportedVersion;
					}
				}

				// If this is an older profile, the operation type must be set
				if (profileVersion < new Version("1.1"))
				{
					report.OperationType = OperationType.Plugin;
				}

				return report;
			}
			catch (Exception ex)
			{
				throw new InvalidOperationException("Unable to deserialize the serialized value.", ex);
			}
		}

		/// <summary>
		/// Adds the event to the queue of events
		/// </summary>
		/// <param name="replayEvent">Event that occurred</param>
		internal void AddReplayEvent(ProfilerReplayEvent replayEvent)
		{
			if (null == replayEvent)
			{
				throw new ArgumentNullException("replayEvent");
			}

			lock (this._internalEventsList)
			{
				this._internalEventsList.Add(replayEvent);
			}
		}

		/// <summary>
		/// Sets the result for the constructor of the plug-in
		/// </summary>
		/// <param name="startTime">Start time for the constructor</param>
		/// <param name="durationInMilliseconds">Length of the constructor execution</param>
		/// <param name="exception">Exception that occurred. If this is excluded, it is assumed that the constructor succeeded.</param>
		internal void SetConstructorResult(DateTime startTime, long durationInMilliseconds, Exception exception)
		{
			if (durationInMilliseconds < 0)
			{
				throw new ArgumentOutOfRangeException("durationInMilliseconds");
			}

			this.ConstructorStartTime = startTime;
			this.ConstructorDurationInMilliseconds = durationInMilliseconds;

			// If the exception is provided, the assumption is that the plug-in execution failed.
			if (null != exception)
			{
				this.ConstructorException = ProfilerSharedUtility.ConvertExceptionToString(exception);
			}
		}

		/// <summary>
		/// Sets the result for the execution of the plug-in
		/// </summary>
		/// <param name="startTime">Start time for the plug-in</param>
		/// <param name="durationInMilliseconds">Length of the execution</param>
		/// <param name="exception">Exception that occurred. If this is excluded, it is assumed that the execution succeeded.</param>
		internal void SetExecutionResult(DateTime startTime, long durationInMilliseconds, Exception exception)
		{
			if (durationInMilliseconds < 0)
			{
				throw new ArgumentOutOfRangeException("durationInMilliseconds");
			}

			this.ExecutionStartTime = startTime;
			this.ExecutionDurationInMilliseconds = durationInMilliseconds;

			// If the exception is provided, the assumption is that the plug-in execution failed.
			if (null != exception)
			{
				this.ExecutionException = ProfilerSharedUtility.ConvertExceptionToString(exception);
			}
		}

		/// <summary>
		/// Serializes the report into a string
		/// </summary>
		public override string ToString()
		{
			return this.ToString(false);
		}

		/// <summary>
		/// Serializes the report into a string
		/// </summary>
		/// <param name="formatReport">Indicates that the report should be formatted</param>
		public string ToString(bool formatReport)
		{
			//Serialize the current object and ensure it starts with the XML declaration
			string originalSerializedReport = PartialTrustSerializer.Serialize(this);
			if (!originalSerializedReport.StartsWith("<?", StringComparison.Ordinal))
			{
				originalSerializedReport = ProfilerSharedUtility.XmlDocumentDeclaration + originalSerializedReport;
			}

			//Format the report (if requested)
			if (formatReport)
			{
				originalSerializedReport = AddReportFormatting(originalSerializedReport);
			}

			return originalSerializedReport;
		}

		/// <summary>
		/// Removes the formatting from the XML
		/// </summary>
		public static string RemoveReportFormatting(string xml)
		{
			if (string.IsNullOrWhiteSpace(xml))
			{
				throw new ArgumentNullException("xml");
			}

			//Create an XML Document to check for the root node.
			XmlDocument reportDoc = CreateXmlDocument(xml);

			//Create a new node (called Profile) so that the two different XML documents can be differentiated
			XmlNode oldParent = reportDoc.DocumentElement;
			XmlNode newParent = reportDoc.CreateElement(UnformattedReportNode, reportDoc.DocumentElement.NamespaceURI);
			while (oldParent.ChildNodes.Count > 0)
			{
				XmlNode contextNode = oldParent.FirstChild;
				if (null != contextNode && contextNode.LocalName == "Context")
				{
					//Convert the Node into XML and append the XML as text to the context node. This is how it is serialized in the Plug-in
					//Profiler Report.
					string context = contextNode.InnerXml;

					//Remove all children and replace them with this
					contextNode.RemoveAll();
					contextNode.AppendChild(newParent.OwnerDocument.CreateTextNode(context));
				}

				//Add the node to the new parent
				newParent.AppendChild(contextNode);
			}

			//Add the new parent to the document
			reportDoc.RemoveAll();
			reportDoc.AppendChild(newParent);

			//Write the document to the String and return it
			StringBuilder sb = new StringBuilder();
			using (XmlWriter writer = CreateXmlWriter(sb, false))
			{
				reportDoc.Save(writer);
			}

			return sb.ToString();
		}

		/// <summary>
		/// Determines if the specified xml contains a formatted profile
		/// </summary>
		public static bool IsFormattedReport(string xml)
		{
			if (string.IsNullOrWhiteSpace(xml))
			{
				throw new ArgumentNullException("xml");
			}

			//Determine the opening and closing tags
			string openTag = string.Format(CultureInfo.InvariantCulture, "<{0}", FormattedReportNode);
			string closeTag = string.Format(CultureInfo.InvariantCulture, "</{0}>", FormattedReportNode);

			//Locate the opening and closing tags in the XML
			int openPosition = xml.IndexOf(openTag, StringComparison.Ordinal);
			if (-1 != openPosition)
			{
				int closePosition = xml.LastIndexOf(closeTag, StringComparison.Ordinal);
				if (-1 != closePosition)
				{
					return true;
				}
			}

			return false;
		}

		#region XML Processing Methods
		private string AddReportFormatting(string xml)
		{
			//Load a document for the serialized report
			XmlDocument reportDoc = CreateXmlDocument(xml);

			//Create a new node (called Profile) so that the two different XML documents can be differentiated
			XmlNode oldParent = reportDoc.DocumentElement;
			XmlNode newParent = reportDoc.CreateElement(FormattedReportNode, reportDoc.DocumentElement.NamespaceURI);
			while (oldParent.ChildNodes.Count > 0)
			{
				XmlNode contextNode = oldParent.FirstChild;
				if (null != contextNode && contextNode.LocalName == "Context")
				{
					//Load the Serialized Context (represented as text) into memory and parse it. The original context node's 
					//children, which contains the text nodes, should be removed and replaced by the XML context
					XmlDocument contextDoc = CreateXmlDocument(ReadNodeText(contextNode));
					contextNode.RemoveAll();

					//Add the context back to the context node as an XML object
					contextNode.AppendChild(newParent.OwnerDocument.ImportNode(contextDoc.DocumentElement, true));
				}

				//Add the node to the new parent
				newParent.AppendChild(contextNode);
			}

			//Add the new parent to the document
			reportDoc.RemoveAll();
			reportDoc.AppendChild(newParent);

			//Write the document to the String and return it
			StringBuilder sb = new StringBuilder();
			using (XmlWriter writer = CreateXmlWriter(sb, true))
			{
				reportDoc.Save(writer);
			}

			return sb.ToString();
		}

		[SuppressMessage("Microsoft.Security", "CA9876:AvoidLoadXmlUsage", Justification = "Executing Client-side")]
		private static XmlDocument CreateXmlDocument(string xml)
		{
			XmlReaderSettings settings = new XmlReaderSettings();
			settings.IgnoreWhitespace = true;
			settings.ConformanceLevel = ConformanceLevel.Fragment;

			using (StringReader reader = new StringReader(xml))
			{
				using (XmlReader xmlReader = XmlReader.Create(reader, settings))
				{
					XmlDocument doc = new XmlDocument();
					doc.XmlResolver = null;
					doc.Load(xmlReader);

					return doc;
				}
			}
		}

		private static XmlWriter CreateXmlWriter(StringBuilder sb, bool indent)
		{
			XmlWriterSettings settings = new XmlWriterSettings();
			settings.Indent = indent;
			settings.OmitXmlDeclaration = true;

			return XmlWriter.Create(sb, settings);
		}

		private static string ReadNodeText(XmlNode node)
		{
			//Ensure that there is at least one child node
			if (0 == node.ChildNodes.Count)
			{
				return null;
			}

			//Loop through the child nodes and append them together. There may be multiple text nodes for a single node.
			StringBuilder sb = new StringBuilder();
			foreach (XmlNode childNode in node.ChildNodes)
			{
				//Ignore the child node
				if (null == childNode)
				{
					continue;
				}

				//Ensure that this is an expected node
				if (XmlNodeType.Text != childNode.NodeType)
				{
					throw new ArgumentException("All child nodes must be Text nodes. Encountered a node of type: " + childNode.NodeType,
						"node");
				}

				//Add the text into the builder
				sb.Append(childNode.Value);
			}

			return sb.ToString();
		}
		#endregion
		#endregion
	}
}
