﻿using System;
using Microsoft.Xrm.Sdk;

namespace Microsoft.Dynamics.ProjectOperations.PluginForge
{
    public class LocalPluginExecutionContextBuilder
    {
        private readonly LocalPluginExecutionContext _context;

        public LocalPluginExecutionContextBuilder()
        {
            _context = new LocalPluginExecutionContext
            {
                // Set default values
                Stage = 0,
                Mode = 0,
                Depth = 1,
                MessageName = string.Empty,
                PrimaryEntityName = string.Empty,
                UserId = Guid.NewGuid(),
                InitiatingUserId = Guid.NewGuid(),
                BusinessUnitId = Guid.NewGuid(),
                OrganizationId = Guid.NewGuid(),
                OrganizationName = "DefaultOrganization",
                IsExecutingOffline = false,
                IsOfflinePlayback = false,
                IsInTransaction = false,
                IsolationMode = 0
            };
        }

        public LocalPluginExecutionContextBuilder WithTargetEntity<T>(T entity) where T : Entity
        {
            return WithInputParameter("Target", entity)
                .WithPrimaryEntityName(entity.LogicalName);
        }

        public LocalPluginExecutionContextBuilder WithTargetEntityReference(EntityReference entityReference)
        {
            return WithInputParameter("Target", entityReference)
                .WithPrimaryEntityName(entityReference.LogicalName);
        }

        public LocalPluginExecutionContextBuilder WithStage(int stage)
        {
            _context.Stage = stage;
            return this;
        }

        public LocalPluginExecutionContextBuilder WithMode(int mode)
        {
            _context.Mode = mode;
            return this;
        }

        public LocalPluginExecutionContextBuilder WithDepth(int depth)
        {
            _context.Depth = depth;
            return this;
        }

        public LocalPluginExecutionContextBuilder WithMessageName(string messageName)
        {
            _context.MessageName = messageName;
            return this;
        }

        public LocalPluginExecutionContextBuilder WithPrimaryEntityName(string entityName)
        {
            _context.PrimaryEntityName = entityName;
            return this;
        }

        public LocalPluginExecutionContextBuilder WithUserId(Guid userId)
        {
            _context.UserId = userId;
            return this;
        }

        public LocalPluginExecutionContextBuilder WithInputParameter(string key, object value)
        {
            _context.InputParameters[key] = value;
            return this;
        }

        public LocalPluginExecutionContextBuilder WithOutputParameter(string key, object value)
        {
            _context.OutputParameters[key] = value;
            return this;
        }

        public LocalPluginExecutionContextBuilder WithSharedVariable(string key, object value)
        {
            _context.SharedVariables[key] = value;
            return this;
        }

        public LocalPluginExecutionContextBuilder WithPreEntityImage(string key, Entity entity)
        {
            _context.PreEntityImages[key] = entity;
            return this;
        }

        public LocalPluginExecutionContextBuilder WithPostEntityImage(string key, Entity entity)
        {
            _context.PostEntityImages[key] = entity;
            return this;
        }

        public LocalPluginExecutionContext Build()
        {
            return _context;
        }
    }
}
