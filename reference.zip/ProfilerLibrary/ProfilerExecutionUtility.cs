﻿using System;
using System.IO;
using System.Net;
using System.Reflection;
using System.Security;
using System.Security.Permissions;
using System.Text.RegularExpressions;

using PluginProfiler.Library.Reporting;
using PluginProfiler.Plugins;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Utility that allows for basic operation configuration during execution
	/// </summary>
	public static class ProfilerExecutionUtility
	{
		/// <summary>
		/// Executes the given plug-in and provides a report about the execution
		/// </summary>
		/// <param name="permissions">Permissions under which to execute the plug-in</param>
		/// <param name="operation">Configuration for the operation to be executed</param>
		/// <param name="reporting">Reporting configuration</param>
		/// <param name="administratorProxy">Proxy to be used when connecting to the service</param>
		/// <param name="tracing">Tracing service that should be used</param>
		public static ProfilerExecutionReport Execute(PluginPermissions permissions, OperationConfiguration operation,
			ProfilerReportingConfiguration reporting, OrganizationServiceProxy administratorProxy, ITracingService tracing)
		{
			if (null == operation)
			{
				throw new ArgumentNullException("operation");
			}
			else if (null == administratorProxy)
			{
				throw new ArgumentNullException("administratorProxy");
			}

			using (ProfilerContextOrganizationServiceFactory factory = new ProfilerContextOrganizationServiceFactory(administratorProxy))
			{
				return Execute(permissions, new ProfilerContextExecutionConfiguration(operation, reporting, tracing, factory, null));
			}
		}

		/// <summary>
		/// Executes the given plug-in and provides a report about the execution
		/// </summary>
		/// <param name="permissions">Permissions under which to execute the plug-in</param>
		/// <param name="operation">Configuration for the operation to be executed</param>
		/// <param name="reporting">Reporting configuration</param>
		/// <param name="tracing">Tracing service that should be used</param>
		public static ProfilerExecutionReport Replay(PluginPermissions permissions, OperationConfiguration operation,
			ProfilerReportingConfiguration reporting, ITracingService tracing)
		{
			if (null == operation)
			{
				throw new ArgumentNullException("operation");
			}

			return Execute(permissions, new ProfilerReplayExecutionConfiguration(operation, reporting, tracing));
		}

		/// <summary>
		/// Retrieves the profiler report that was provided by the plug-in
		/// </summary>
		/// <param name="logFilePath">Path to the Log</param>
		public static ProfilerPluginReport RetrieveReport(string logFilePath)
		{
			if (string.IsNullOrWhiteSpace(logFilePath))
			{
				throw new ArgumentNullException("logFilePath");
			}

			return ProfilerUtility.DeserializeProfilerReport(null, logFilePath).Report;
		}

		/// <summary>
		/// Retrieves the profiler report that was provided by the plug-in
		/// </summary>
		/// <param name="fault">Outermost Fault that contains the exception</param>
		/// <remarks>
		/// The log file that can be downloaded for an operation contains a serialized version of the fault
		/// </remarks>
		public static ProfilerPluginReport RetrieveReport(OrganizationServiceFault fault)
		{
			if (null == fault)
			{
				throw new ArgumentNullException("fault");
			}

			return ProfilerUtility.DeserializeProfilerReport(null, fault).Report;
		}

		#region Private Methods
		private static ProfilerExecutionReport Execute(PluginPermissions permissions, ProfilerExecutionConfiguration configuration)
		{
			using (ProfilerExecutionEngine engine = new ProfilerExecutionEngine(permissions, configuration.ProfilerTracingService))
			{
				return engine.Execute(configuration);
			}
		}
		#endregion
	}
}
