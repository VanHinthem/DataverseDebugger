﻿using System;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Reference for a Custom Activity Step
	/// </summary>
	public sealed class CustomActivityStep
	{
		private Guid _assemblyId;
		private Guid _typeId;

		public CustomActivityStep(string stepId, Guid pluginAssemblyId, Guid pluginTypeId, string typeName)
		{
			if (string.IsNullOrWhiteSpace(stepId))
			{
				throw new ArgumentNullException("stepId");
			}
			else if (Guid.Empty == pluginAssemblyId)
			{
				throw new ArgumentNullException("pluginAssemblyId");
			}
			else if (Guid.Empty == pluginTypeId)
			{
				throw new ArgumentNullException("pluginTypeId");
			}
			else if (string.IsNullOrWhiteSpace(typeName))
			{
				throw new ArgumentNullException("typeName");
			}

			this.TypeName = typeName;
			this.StepId = stepId;
			this.PluginAssemblyId = pluginAssemblyId;
			this.PluginTypeId = pluginTypeId;
		}

		#region Properties
		/// <summary>
		/// Id for the PluginAssemblyId referenced by this step
		/// </summary>
		public Guid PluginAssemblyId
		{
			get
			{
				return this._assemblyId;
			}

			internal set
			{
				if (Guid.Empty == value)
				{
					throw new ArgumentNullException("value");
				}

				this._assemblyId = value;
			}
		}

		/// <summary>
		/// Id for the PluginType referenced by this step
		/// </summary>
		public Guid PluginTypeId
		{
			get
			{
				return this._typeId;
			}

			internal set
			{
				if (Guid.Empty == value)
				{
					throw new ArgumentNullException("value");
				}

				this._typeId = value;
			}
		}

		/// <summary>
		/// Step ID for the Custom Workflow Activity in XAML
		/// </summary>
		public string StepId { get; private set; }

		/// <summary>
		/// Type Name for the step
		/// </summary>
		public string TypeName { get; private set; }
		#endregion
	}
}
