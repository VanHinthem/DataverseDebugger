﻿using System;
using System.Activities;
using System.Collections.Generic;
using System.Reflection;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;

namespace PluginProfiler.Plugins.ServiceWrappers
{
	/// <summary>
	/// Wrapper for the IServiceEndpointNotificationService provided by the IOrganizationServiceFactory during execution of a plug-in.
	/// </summary>
	internal sealed class ServiceProviderWrapper : IServiceProvider
	{
		private static readonly Dictionary<Type, Type> DefaultServices;
		private readonly Dictionary<Type, object> ServiceList;

		static ServiceProviderWrapper()
		{
			DefaultServices = new Dictionary<Type, Type>();
			DefaultServices.Add(typeof(IPluginExecutionContext), typeof(PluginExecutionContextWrapper));
			DefaultServices.Add(typeof(IWorkflowContext), typeof(WorkflowExecutionContextWrapper));
			DefaultServices.Add(typeof(IOrganizationServiceFactory), typeof(OrganizationServiceFactoryWrapper));
			DefaultServices.Add(typeof(IServiceEndpointNotificationService), typeof(ServiceEndpointNotificationWrapper));
			DefaultServices.Add(typeof(ITracingService), null);
		}

		/// <summary>
		/// Instantiates an instance of the IServiceProvider wrapper
		/// </summary>
		/// <param name="services">Provider of the original services</param>
		/// <param name="context">Context for execution in the plug-in profiler.</param>
		public ServiceProviderWrapper(Dictionary<Type, object> services, ProfilerPluginContext context)
		{
			if (null == services)
			{
				throw new ArgumentNullException("services");
			}
			else if (null == context)
			{
				throw new ArgumentNullException("context");
			}

			this.ServiceList = ApplyWrappers(services, context);
		}

		#region Public Methods
		/// <summary>
		/// Adds the services to the <paramref name="invoker"/> instance.
		/// </summary>
		/// <param name="invoker">WorkflowInvoker to which the services should be added.</param>
		/// <returns>WorkflowInvoker with all of the services configured</returns>
		public void AddExtensionsToWorkflowInvoker(WorkflowInvoker invoker)
		{
			if (null == invoker)
			{
				throw new ArgumentNullException("invoker");
			}

			// Currently, if instances of the extensions are added the workflow activity receives null back. However, using the generic Add
			// forces the WorkflowContext to query for the instance of the class which appears to work without issue.
			// TODO: Do this in a more generic way.
			invoker.Extensions.Add<IWorkflowContext>(delegate() { return this.GetService<IWorkflowContext>(); });
			invoker.Extensions.Add<IOrganizationServiceFactory>(delegate() { return this.GetService<IOrganizationServiceFactory>(); });
			invoker.Extensions.Add<IServiceEndpointNotificationService>(delegate() { return this.GetService<IServiceEndpointNotificationService>(); });
			invoker.Extensions.Add<ITracingService>(delegate() { return this.GetService<ITracingService>(); });
		}

		/// <summary>
		/// Extracts the default services from the provider
		/// </summary>
		/// <param name="provider">Provider of the services</param>
		/// <returns>List of services contained by the provider</returns>
		internal static Dictionary<Type, object> ExtractServices(IServiceProvider provider)
		{
			if (null == provider)
			{
				throw new ArgumentNullException("provider");
			}

			return ExtractServices(serviceType => provider.GetService(serviceType));
		}

		/// <summary>
		/// Extracts the default services from the provider
		/// </summary>
		/// <param name="provider">Provider of the services</param>
		/// <returns>List of services contained by the provider</returns>
		internal static Dictionary<Type, object> ExtractServices(ActivityContext provider)
		{
			if (null == provider)
			{
				throw new ArgumentNullException("provider");
			}

			// The GetExtension method is only exposed as a generic method. In order to do this with a single code path,
			// reflection needs to be used to instantiate this method.
			MethodInfo method = typeof(ActivityContext).GetMethod("GetExtension").GetGenericMethodDefinition();

			// When a type is provided to the method, a generic method needs to be instantiated and then invoked.
			return ExtractServices(serviceType => method.MakeGenericMethod(serviceType).Invoke(provider, new object[0]));
		}
		#endregion

		#region Private Helper Methods
		private static Dictionary<Type, object> ExtractServices(Func<Type, object> method)
		{
			Dictionary<Type, object> services = new Dictionary<Type, object>();
			foreach (Type serviceType in DefaultServices.Keys)
			{
				object service = method(serviceType);
				services.Add(serviceType, service);
			}

			return services;
		}

		private static Dictionary<Type, object> ApplyWrappers(Dictionary<Type, object> services, ProfilerPluginContext profilerContext)
		{
			IExecutionContext existingContext = null;

			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			try
			{
				Dictionary<Type, object> wrappedServices = new Dictionary<Type, object>();
				foreach (KeyValuePair<Type, object> servicePair in services)
				{
					object service = servicePair.Value;
					if (null == service)
					{
						continue;
					}
					sb.AppendLine("Type = " + servicePair.Key);

					// This is either not a context OR a context has not been requested yet. The context interface will be in the services
					// list at least two times -- IExecutionContext and IWorkflowContext/IPluginExecutionContext
					if (!typeof(IExecutionContext).IsAssignableFrom(servicePair.Key) || null == existingContext)
					{
						Type wrapperType;
						if (DefaultServices.TryGetValue(servicePair.Key, out wrapperType) &&
							null != wrapperType)
						{
							// Locate the constructor for the type
							ConstructorInfo constructor = wrapperType.GetConstructor(BindingFlags.Instance | BindingFlags.Public, null,
								new Type[]
								{
									servicePair.Key, typeof(ProfilerPluginContext) 
								}, null);

							if (null == constructor)
							{
								constructor = wrapperType.GetConstructor(BindingFlags.Instance | BindingFlags.Public, null,
								new Type[]
								{
									servicePair.Key
								}, null);

								if (null == constructor)
								{
									throw new InvalidOperationException("Unable to find the correct constructor for the wrapper: " + wrapperType.FullName);
								}

								// Construct the wrapper for the type
								service = constructor.Invoke(new object[] { service });
							}
							else
							{
								// Construct the wrapper for the type
								service = constructor.Invoke(new object[] { service, profilerContext });
							}
						}

						// Save the context for the next time that a context is encountered
						if (null == existingContext && typeof(IExecutionContext).IsAssignableFrom(servicePair.Key))
						{
							existingContext = service as IExecutionContext;
						}
					}
					else
					{
						// Reuse the existing instance instead of constructing a second wrapper.
						service = existingContext;
					}

					wrappedServices.Add(servicePair.Key, service);
				}

				return wrappedServices;
			}
			catch (Exception ex)
			{
				throw new InvalidPluginExecutionException("Errors: " + sb.ToString(), ex);
			}
		}
		#endregion

		#region IServiceProvider Members
		/// <summary>
		/// Retrieves a service of the given type
		/// </summary>
		/// <param name="serviceType">Type of service to be retrieved</param>
		public object GetService(Type serviceType)
		{
			if (null == serviceType)
			{
				throw new ArgumentNullException("serviceType");
			}

			object service;
			if (this.ServiceList.TryGetValue(serviceType, out service))
			{
				return service;
			}

			return null;
		}
		#endregion
	}
}
