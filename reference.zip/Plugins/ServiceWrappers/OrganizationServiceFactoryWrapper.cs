﻿using System;

using Microsoft.Xrm.Sdk;

namespace PluginProfiler.Plugins.ServiceWrappers
{
	/// <summary>
	/// Wrapper for the IOrganizationServiceFactory provided by the IServiceProvider during execution of a plug-in.
	/// </summary>
	internal sealed class OrganizationServiceFactoryWrapper : ServiceWrapperBase<IOrganizationServiceFactory>, IOrganizationServiceFactory
	{
		/// <summary>
		/// Instantiates an instance of the OrganizationServiceFactoryWrapper
		/// </summary>
		/// <param name="service">Actual service provided by the original IServiceProvider instance.</param>
		/// <param name="context">Context for execution in the plug-in profiler.</param>
		public OrganizationServiceFactoryWrapper(IOrganizationServiceFactory service, ProfilerPluginContext context)
			: base(service, context)
		{
		}

		#region IOrganizationServiceFactory Members
		/// <summary>
		/// Creates an OrganizationServiceWrapper for the given user
		/// </summary>
		/// <param name="userId">User ID that should be used by IOrganizationService to connect to the server</param>
		public IOrganizationService CreateOrganizationService(Guid? userId)
		{
			return new OrganizationServiceWrapper(this.InternalService.CreateOrganizationService(userId), this.Context,
				userId ?? this.Context.UserId);
		}
		#endregion
	}
}
