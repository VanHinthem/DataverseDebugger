# PR-A04 – Centralized Runner Start Configuration

## Objective
Single authoritative Runner startup config.

## Illegal Changes
- View-level config logic
- Implicit defaults
