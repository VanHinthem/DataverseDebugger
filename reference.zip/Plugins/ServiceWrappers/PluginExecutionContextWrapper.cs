﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

using Microsoft.Xrm.Sdk;

namespace PluginProfiler.Plugins.ServiceWrappers
{
	/// <summary>
	/// Wrapper for the IPluginExecutionContext provided by the IOrganizationServiceFactory during execution of a plug-in.
	/// </summary>
	/// <remarks>
	/// This class can be serialized into a string using the ToString() method and deserialized using the Deserialize method.
	/// </remarks>
	[DataContract(Name = "PluginExecutionContext", Namespace = "")]
	public sealed class PluginExecutionContextWrapper : ExecutionContextWrapper, IPluginExecutionContext
	{
		/// <summary>
		/// Instantiates an instance of the PluginExecutionContextWrapper.
		/// </summary>
		/// <remarks>
		/// This constructor is called by the static Deserialize method.
		/// </remarks>
		private PluginExecutionContextWrapper()
			: base()
		{
		}

		/// <summary>
		/// Instantiates an instance of the PluginExecutionContextWrapper for the given context.
		/// </summary>
		/// <param name="context">IPluginExecutionContext instance that should be wrapped.</param>
		public PluginExecutionContextWrapper(IPluginExecutionContext context)
			: base(context)
		{
			this.PopulateMethods<IPluginExecutionContext>();
		}

		#region IPluginExecutionContext Members
		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Setter is called via reflection when the properties are set.")]
		public IPluginExecutionContext ParentContext { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Setter is called via reflection when the properties are set.")]
		public int Stage { get; private set; }

        [DataMember(IsRequired = false)]
        public Guid UserAzureActiveDirectoryObjectId { get; private set; }

        [DataMember(IsRequired = false)]
        public Guid InitiatingUserAzureActiveDirectoryObjectId { get; private set; }

        #endregion

        #region ExecuteContextWrapper Members
        internal override OperationType OperationType
		{
			get
			{
				return OperationType.Plugin;
			}
		}

		protected override string SerializeContext()
		{
			return PartialTrustSerializer.Serialize<IPluginExecutionContext>(this);
		}
		#endregion

		#region Internal Methods
		internal override IExecutionContext InstantiateContextWrapper(IExecutionContext context)
		{
			return new PluginExecutionContextWrapper(context as IPluginExecutionContext);
		}

		protected override void SetContextProperty(System.Reflection.PropertyInfo property, object value)
		{
			property.SetValue(this, value, null);
		}
		#endregion
	}
}
