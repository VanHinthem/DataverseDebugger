﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;

using Microsoft.Crm.Sdk.Messages;

using Microsoft.Xrm.Sdk;

namespace PluginProfiler.Plugins
{
	/// <summary>
	/// Utility to serialize data contracts in partial trust
	/// </summary>
	/// <remarks>
	/// This utility has been optimized for serializing XRM classes.
	/// </remarks>
	internal static class PartialTrustSerializer
	{
		#region Methods
		/// <summary>
		/// Serializes the given value
		/// </summary>
		/// <param name="value">Value to serialize</param>
		internal static string Serialize<T>(T value)
		{
			return Serialize(typeof(T), value);
		}

		/// <summary>
		/// Serializes the given value
		/// </summary>
		/// <param name="type">Type of the object that is being serialized</param>
		/// <param name="value">Value to serialize</param>
		[SuppressMessage("Microsoft.Usage", "CA2202:Do not dispose objects multiple times",
			Justification = "The stream class is closed automatically by the StreamReader class without an issue. The current design produces cleaner code.")]
		internal static string Serialize(Type type, object value)
		{
			using (MemoryStream stream = new MemoryStream())
			{
				DataContractSerializer serializer = CreateSerializer(type, null, true);
				serializer.WriteObject(stream, value);
				stream.Seek(0, SeekOrigin.Begin);
				using (StreamReader reader = new StreamReader(stream))
				{
					return reader.ReadToEnd();
				}
			}
		}

		/// <summary>
		/// Populates the context from a serialized value
		/// </summary>
		/// <param name="value">Value to deserialize</param>
		internal static T Deserialize<T>(string value)
		{
			return Deserialize<T>(value, null);
		}

		/// <summary>
		/// Populates the context from a serialized value
		/// </summary>
		/// <param name="value">Value to deserialize</param>
		/// <param name="proxyTypesAssembly">Assembly that contains the proxy types</param>
		internal static T Deserialize<T>(string value, Assembly proxyTypesAssembly)
		{
			return (T)Deserialize(typeof(T), value, proxyTypesAssembly);
		}

		/// <summary>
		/// Populates the context from a serialized value
		/// </summary>
		/// <param name="type">Type of the serialized value</param>
		/// <param name="value">Value to deserialize</param>
		/// <param name="proxyTypesAssembly">Assembly that contains the proxy types</param>
		internal static object Deserialize(Type type, string value, Assembly proxyTypesAssembly)
		{
			return Deserialize(type, Encoding.UTF8.GetBytes(value), proxyTypesAssembly);
		}

		/// <summary>
		/// Populates the context from a serialized value
		/// </summary>
		/// <param name="type">Type of the serialized value</param>
		/// <param name="value">Value to deserialize</param>
		/// <param name="proxyTypesAssembly">Assembly that contains the proxy types</param>
		internal static object Deserialize(Type type, byte[] value, Assembly proxyTypesAssembly)
		{
			using (MemoryStream stream = new MemoryStream(value))
			{
				DataContractSerializer serializer = CreateSerializer(type, proxyTypesAssembly, true);
				return serializer.ReadObject(stream);
			}
		}
		#endregion

		#region Private Methods
		/// <summary>
		/// Instantiates the DataContractSerializer
		/// </summary>
		private static DataContractSerializer CreateSerializer(Type type, Assembly proxyTypesAssembly, bool convertProxyTypes)
		{
			return new DataContractSerializer(type, new Type[] { typeof(Entity), typeof(WhoAmIResponse) },
				int.MaxValue, true, false, new SpecialTypeSerializationSurrogate(proxyTypesAssembly, convertProxyTypes),
				new KnownTypesResolver());
		}
		#endregion

		#region Private Classes
		private sealed class SpecialTypeSerializationSurrogate : IDataContractSurrogate
		{
			private readonly bool ConvertProxyTypes;
			private readonly Assembly ProxyTypesAssembly;
			private ServiceWrappers.ProxyTypesWrapper _proxyWrapper;

			public SpecialTypeSerializationSurrogate(Assembly proxyTypesAssembly, bool convertProxyTypes)
			{
				this.ProxyTypesAssembly = proxyTypesAssembly;
				if (null != proxyTypesAssembly)
				{
					convertProxyTypes = true;
				}

				this.ConvertProxyTypes = convertProxyTypes;
			}

			#region IDataContractSurrogate Members
			public object GetCustomDataToExport(Type clrType, Type dataContractType)
			{
				return null;
			}

			public object GetCustomDataToExport(MemberInfo memberInfo, Type dataContractType)
			{
				return null;
			}

			public Type GetDataContractType(Type type)
			{
				if (type.IsGenericType && typeof(KeyValuePair<,>) == type.GetGenericTypeDefinition())
				{
					//KeyValuePair cannot be deserialized in partial trust because it requires private reflection.
					//The KeyValuePairWrapper wraps the KeyValuePair to workaround this behavior.
					return typeof(KeyValuePairWrapper<,>).MakeGenericType(type.GetGenericArguments());
				}
				else if (typeof(Entity).IsAssignableFrom(type))
				{
					//Ensures that strongly-typed entities are not persisted to the context
					return typeof(Entity);
				}

				return type;
			}

			public object GetDeserializedObject(object obj, Type targetType)
			{
				if (null == obj)
				{
					return obj;
				}

				if (targetType.IsGenericType &&
					typeof(KeyValuePair<,>).GetGenericTypeDefinition() == targetType.GetGenericTypeDefinition())
				{
					//If the target type is a KeyValuePair (and this object was serialized using this class), 
					//the actual class that is stored in the obj variable will be the KeyValuePairWrapper.
					dynamic wrapper = obj;
					return wrapper.ToPair();
				}

				Entity entity = obj as Entity;
				if (null != this.ProxyTypesAssembly && null != entity && !string.IsNullOrWhiteSpace(entity.LogicalName))
				{
					if (null == _proxyWrapper)
					{
						lock (ProxyTypesAssembly)
						{
							if (null == _proxyWrapper)
							{
								_proxyWrapper = new ServiceWrappers.ProxyTypesWrapper(this.ProxyTypesAssembly);
							}
						}
					}

					return _proxyWrapper.ConvertToEarlyBound(obj);
				}

				return obj;
			}

			public void GetKnownCustomDataTypes(Collection<Type> customDataTypes)
			{
			}

			public object GetObjectToSerialize(object obj, Type targetType)
			{
				if (null == obj)
				{
					return obj;
				}

				if (targetType.IsGenericType && typeof(KeyValuePairWrapper<,>) == targetType.GetGenericTypeDefinition())
				{
					//If the target type is a KeyValuePairWrapper, then the obj variable contains a KeyValuePair<TKey, TValue>
					//that needs to be wrapped inside the wrapper.
					dynamic pair = obj;
					Type type = typeof(KeyValuePairWrapper<,>).MakeGenericType(targetType.GetGenericArguments());
					return Activator.CreateInstance(type, pair.Key, pair.Value);
				}
				else if (this.ConvertProxyTypes && typeof(Entity).IsAssignableFrom(obj.GetType()))
				{
					return ((Entity)obj).ToEntity<Entity>();
				}

				return obj;
			}

			public Type GetReferencedTypeOnImport(string typeName, string typeNamespace, object customData)
			{
				return null;
			}

			public System.CodeDom.CodeTypeDeclaration ProcessImportedType(System.CodeDom.CodeTypeDeclaration typeDeclaration, System.CodeDom.CodeCompileUnit compileUnit)
			{
				return null;
			}
			#endregion
		}
		#endregion
	}

	#region Special Data Contracts
	/// <summary>
	/// Wrapper class for the KeyValuePair&lt;TKey, TValue&gt; to allow the class to be serialized in partial trust
	/// </summary>
	/// <remarks>
	/// KeyValuePair&lt;TKey, TValue&gt; cannot be serialized in partial trust as the serialization process uses private reflection
	/// to retrieve the key and value property values. This wrapper class works around this issue by accessing the properties during
	/// serialization.
	/// </remarks>
	[DataContract(Name = "KeyValuePair", Namespace = "http://schemas.datacontract.org/2004/07/System.Collections.Generic")]
	public sealed class KeyValuePairWrapper<TKey, TValue>
	{
		public KeyValuePairWrapper(TKey key, TValue value)
		{
			this.Key = key;
			this.Value = value;
		}

		#region Properties
		[DataMember(Name = "key")]
		public TKey Key { get; private set; }

		[DataMember(Name = "value")]
		public TValue Value { get; private set; }
		#endregion

		#region Methods
		public KeyValuePair<TKey, TValue> ToPair()
		{
			return new KeyValuePair<TKey, TValue>(this.Key, this.Value);
		}
		#endregion
	}
	#endregion
}
