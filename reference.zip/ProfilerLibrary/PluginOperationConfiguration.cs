﻿using System;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Configuration to be used for the operation for replay or debug of the plug-in
	/// </summary>
	[Serializable]
	public sealed class PluginOperationConfiguration : OperationConfiguration
	{
		public PluginOperationConfiguration(string assemblyFilePath, string typeName, string logFilePath)
			: base(OperationType.Plugin, assemblyFilePath, typeName, logFilePath)
		{
		}

		public PluginOperationConfiguration(string assemblyFilePath, string typeName, string logFilePath,
			string unsecureConfiguration, string secureConfiguration)
			: this(assemblyFilePath, typeName, logFilePath)
		{
			this.UnsecureConfiguration = unsecureConfiguration;
			this.SecureConfiguration = secureConfiguration;
			this.IgnoreProfilerPluginReportConfiguration = true;
		}

		#region Properties
		/// <summary>
		/// Unsecure configuration that should be provided to the plug-in
		/// </summary>
		public string UnsecureConfiguration { get; private set; }

		/// <summary>
		/// Secure configuration that should be provided to the plug-in
		/// </summary>
		public string SecureConfiguration { get; private set; }

		/// <summary>
		/// Indicates that the ProfilerPluginReport's configuration should be ignored
		/// </summary>
		internal bool IgnoreProfilerPluginReportConfiguration { get; private set; }
		#endregion
	}
}