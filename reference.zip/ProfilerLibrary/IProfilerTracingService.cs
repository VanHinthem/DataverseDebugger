﻿using System;

namespace PluginProfiler.Library.Reporting
{
	/// <summary>
	/// Tracing Engine that will trace the status of the Profiler Enginer
	/// </summary>
	public interface IProfilerTracingService
	{
		void Trace(string format, params object[] args);
	}
}
