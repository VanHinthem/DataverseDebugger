﻿using System;
using Microsoft.Xrm.Sdk;

namespace Microsoft.Dynamics.ProjectOperations.PluginForge
{
    public class LocalrganizationServiceFactory : IOrganizationServiceFactory
    {
        private readonly IOrganizationService _organizationService;

        public LocalrganizationServiceFactory(IOrganizationService organizationService)
        {
            _organizationService = organizationService ?? throw new ArgumentNullException(nameof(organizationService));
        }

        public IOrganizationService CreateOrganizationService(Guid? userId)
        {
            // You can customize this to return a service based on the userId if needed.
            return _organizationService;
        }
    }
}
