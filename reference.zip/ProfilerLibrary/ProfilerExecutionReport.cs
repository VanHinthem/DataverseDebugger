﻿using System;
using System.Collections.Generic;
using System.Reflection;

using Microsoft.Xrm.Sdk;

using PluginProfiler.Plugins;
using PluginProfiler.Plugins.ServiceWrappers;

namespace PluginProfiler.Library.Reporting
{
	/// <summary>
	/// PluginReport about the plug-in execution that occurred
	/// </summary>
	public sealed class ProfilerExecutionReport : MarshalByRefObject
	{
		#region Constructors
		internal ProfilerExecutionReport()
		{
			this.Operations = new List<ProfilerClientOperationBase>();
		}
		#endregion

		#region Method
		internal void AddOperationFromAppDomain(Type type, string serializedOperation)
		{
			if (null == type)
			{
				throw new ArgumentNullException("type");
			}
			else if (string.IsNullOrWhiteSpace(serializedOperation))
			{
				throw new ArgumentNullException("serializedOperation");
			}

			this.AddOperation((ProfilerClientOperationBase)ProfilerSharedUtility.Deserialize(type, serializedOperation,
				this.ProxyTypesAssembly));
		}

		internal void AddOperation(ProfilerClientOperationBase operation)
		{
			if (null == operation)
			{
				throw new ArgumentNullException("operation");
			}

			this.Operations.Add(operation);
		}

		internal void SetSerializedContext(OperationType type, string serializedContext)
		{
			if (string.IsNullOrWhiteSpace(serializedContext))
			{
				throw new ArgumentNullException("serializedContext");
			}

			this.Context = ExecutionContextWrapper.Deserialize(type, serializedContext);
		}

		internal void SetSerializedProfilerReport(string serializedReport)
		{
			if (string.IsNullOrWhiteSpace(serializedReport))
			{
				throw new ArgumentNullException("serializedReport");
			}

			this.ProfilerReport = ProfilerPluginReport.Deserialize(serializedReport, this.ProxyTypesAssembly);
		}

		internal void MarkReadOnly()
		{
			this.Operations = ((List<ProfilerClientOperationBase>)this.Operations).AsReadOnly();
		}
		#endregion

		#region Properties
		/// <summary>
		/// Context for the plug-in
		/// </summary>
		public IExecutionContext Context { get; private set; }

		/// <summary>
		/// Operations that were executed by the plug-in
		/// </summary>
		public IList<ProfilerClientOperationBase> Operations { get; private set; }

		/// <summary>
		/// Fault that occurred (if any)
		/// </summary>
		public OrganizationServiceFault Fault { get; internal set; }

		/// <summary>
		/// Profiler Report that was created
		/// </summary>
		public ProfilerPluginReport ProfilerReport { get; private set; }

		/// <summary>
		/// Assembly that should be used for serialzation
		/// </summary>
		internal Assembly ProxyTypesAssembly { get; set; }
		#endregion
	}
}
