﻿using System;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization;
using System.Security;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;

using PluginProfiler.Plugins;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Internal utility for the profiler library
	/// </summary>
	internal static class ProfilerUtility
	{
		private static readonly Regex NewlineNormalizationExpression = new Regex("\r\n?");

		/// <summary>
		/// Converts a serialized OrganizationServiceFault persisted in a file to an OrganizationServiceFault
		/// </summary>
		/// <param name="serializedReport">Serialized report that should be deserialized</param>
		internal static string ExtractReport(string serializedReport)
		{
			if (string.IsNullOrWhiteSpace(serializedReport))
			{
				throw new ArgumentNullException("serializedReport");
			}

			// In the case of async workflow activities, the serialized form will not be a fault.
			string decompressedReport = ExtractReportFromNonFault(serializedReport);
			if (!string.IsNullOrWhiteSpace(decompressedReport))
			{
				return decompressedReport;
			}

			try
			{
				using (MemoryStream stream = ConvertFaultToStream(serializedReport))
				{
					DataContractSerializer serializer = new DataContractSerializer(typeof(OrganizationServiceFault));
					return ExtractReportFromFault((OrganizationServiceFault)serializer.ReadObject(stream));
				}
			}
			catch (Exception ex)
			{
				throw new ArgumentException("Unable to parse the OrganizationServiceFault.", "serializedReport", ex);
			}
		}

		/// <summary>
		/// Extracts the serialized value from the fault
		/// </summary>
		/// <param name="fault">Fault that contains the message</param>
		/// <returns>The value that is stored in the fault</returns>
		internal static string ExtractReportFromFault(OrganizationServiceFault fault)
		{
			if (null == fault)
			{
				throw new ArgumentNullException("fault");
			}

			//The inner most fault will contain the serialized value
			while (null != fault.InnerFault)
			{
				fault = fault.InnerFault;
			}

			//Identify the separator
			string message = fault.Message;
			if (!string.IsNullOrWhiteSpace(message))
			{
				int closeSeparator = message.LastIndexOf(ProfilerSharedUtility.ProfilerErrorMessageSeparator);
				if (-1 != closeSeparator)
				{
					int openSeparator = message.LastIndexOf(ProfilerSharedUtility.ProfilerErrorMessageSeparator, closeSeparator - 1);
					if (-1 != openSeparator)
					{
						return ExtractCompressedReport(message.Substring(openSeparator + 1, closeSeparator - openSeparator - 1));
					}
				}
			}

			throw new InvalidOperationException("Message does not contain a serialized value.");
		}

		/// <summary>
		/// Loads the given assembly from the given path
		/// </summary>
		internal static Assembly LoadAssembly(string assemblyFilePath)
		{
			if (string.IsNullOrWhiteSpace(assemblyFilePath))
			{
				throw new ArgumentNullException("assemblyFilePath");
			}

			// The assembly has to be loaded in the context of the current AppDomain (which is partial trust) instead of
			// the current assembly, which is fully trusted. If we load it in the context of the current assembly, it will
			// also be loaded as full trust.
			return Assembly.Load(File.ReadAllBytes(assemblyFilePath), null, SecurityContextSource.CurrentAppDomain);
		}

		/// <summary>
		/// Returns the Assembly for the given plug-in assembly (if it defines proxy types)
		/// </summary>
		internal static Assembly GetProxyTypesAssembly(Assembly pluginAssembly)
		{
			if (null == pluginAssembly)
			{
				throw new ArgumentNullException("pluginAssembly");
			}

			ProxyTypesAssemblyAttribute[] attributes = (ProxyTypesAssemblyAttribute[])pluginAssembly.GetCustomAttributes(
				typeof(ProxyTypesAssemblyAttribute), true);
			if (null == attributes || 0 == attributes.Length)
			{
				return null;
			}
			else
			{
				return pluginAssembly;
			}
		}

		/// <summary>
		/// Converts an Exception to a Fault
		/// </summary>
		internal static OrganizationServiceFault ConvertToFault(Exception exception)
		{
			if (null == exception)
			{
				throw new ArgumentNullException("exception");
			}

			OrganizationServiceFault fault = null;
			Exception ex = exception;
			while (null != ex)
			{
				OrganizationServiceFault updateFault;
				if (null == fault)
				{
					fault = new OrganizationServiceFault();
					updateFault = fault;
				}
				else
				{
					updateFault = new OrganizationServiceFault();
					fault.InnerFault = updateFault;
				}

				fault.ErrorCode = -2147220970; //Unexpected Error Code
				fault.ErrorDetails["CallStack"] = ex.StackTrace;
				fault.Message = ex.Message;
				fault.Timestamp = DateTime.UtcNow;

				ex = ex.InnerException;
			}

			return fault;
		}

		/// <summary>
		/// Retrieve the ProfilerPluginReport
		/// </summary>
		internal static DeserializedProfilerReport DeserializeProfilerReport(string assemblyFilePath, string logFilePath)
		{
			if (string.IsNullOrWhiteSpace(logFilePath))
			{
				throw new ArgumentNullException("logFilePath");
			}

			using (FileStream stream = new FileStream(logFilePath, FileMode.Open, FileAccess.Read))
			{
				using (StreamReader reader = new StreamReader(stream))
				{
					// In some cases, the newline format may have been different.
					string serializedReport = NormalizeNewlines(reader.ReadToEnd());

					//Check if this is a formatted report
					if (ProfilerPluginReport.IsFormattedReport(serializedReport))
					{
						serializedReport = ProfilerPluginReport.RemoveReportFormatting(serializedReport);
					}
					else
					{
						serializedReport = ProfilerUtility.ExtractReport(serializedReport);
					}

					return DeserializeProfilerReportInternal(assemblyFilePath, serializedReport);
				}
			}
		}

		/// <summary>
		/// Retrieve the ProfilerPluginReport
		/// </summary>
		internal static DeserializedProfilerReport DeserializeProfilerReport(string assemblyFilePath, OrganizationServiceFault fault)
		{
			if (null == fault)
			{
				throw new ArgumentNullException("fault");
			}

			return DeserializeProfilerReportInternal(assemblyFilePath, ProfilerUtility.ExtractReportFromFault(fault));
		}

		#region Private Methods
		private static string ExtractCompressedReport(string compressedValue)
		{
			return Encoding.UTF8.GetString(ProfilerSharedUtility.Decompress(compressedValue));
		}

		private static string ExtractReportFromNonFault(string serializedReport)
		{
			if (-1 != serializedReport.IndexOf("OrganizationServiceFault", StringComparison.OrdinalIgnoreCase))
			{
				return null;
			}

			// If this is a profiler entity, then the contents of the report will only be a compressed report. To detect if this is the case,
			// attempt to decompress it. If this is not the case, it will fail with a FormatException
			try
			{
				return ExtractCompressedReport(serializedReport);
			}
			catch (FormatException)
			{
			}

			// Locate the start of the error message
			int openSeparator = serializedReport.LastIndexOf(ProfilerSharedUtility.ProfilerErrorMessagePrefix, StringComparison.OrdinalIgnoreCase);
			if (-1 == openSeparator)
			{
				return null;
			}

			// Locate the start of the compressed value
			openSeparator = serializedReport.IndexOf(ProfilerSharedUtility.ProfilerErrorMessageSeparator,
				openSeparator + ProfilerSharedUtility.ProfilerErrorMessagePrefix.Length);
			if (-1 == openSeparator)
			{
				return null;
			}

			// Locate the end of the compressed error
			int closeSeparator = serializedReport.IndexOf(ProfilerSharedUtility.ProfilerErrorMessageSeparator, openSeparator + 1);
			if (-1 == closeSeparator)
			{
				return null;
			}

			return ExtractCompressedReport(serializedReport.Substring(openSeparator + 1, closeSeparator - openSeparator - 1));
		}

		private static DeserializedProfilerReport DeserializeProfilerReportInternal(string assemblyFilePath, string serializedReport)
		{
			//Load the assembly for the plug-in
			Assembly assembly;
			if (string.IsNullOrWhiteSpace(assemblyFilePath))
			{
				assembly = null;
			}
			else
			{
				assembly = ProfilerUtility.LoadAssembly(assemblyFilePath);
			}

			return new DeserializedProfilerReport(serializedReport, assembly);
		}

		private static MemoryStream ConvertFaultToStream(string serializedFault)
		{
			if (string.IsNullOrWhiteSpace(serializedFault))
			{
				throw new ArgumentNullException("serializedFault");
			}

			const string OpenPosition = "<OrganizationServiceFault";
			const string ClosePosition = "</OrganizationServiceFault>";

			//Extract the serialized fault from the provided data. In some cases, this will be the persisted ErrorDetails.txt
			//that was downloaded from the server.
			if (!string.IsNullOrWhiteSpace(serializedFault))
			{
				int openPosition = serializedFault.IndexOf(OpenPosition, StringComparison.Ordinal);
				if (-1 != openPosition)
				{
					int closePosition = serializedFault.LastIndexOf(ClosePosition, StringComparison.Ordinal);
					if (-1 != closePosition)
					{
						string fault = serializedFault.Substring(openPosition, closePosition + ClosePosition.Length - openPosition);
						return new MemoryStream(Encoding.UTF8.GetBytes(fault));
					}
				}
			}

			throw new InvalidOperationException("File does not contain a valid serialized OrganizationServiceFault.");
		}

		private static string NormalizeNewlines(string value)
		{
			// Intermediate normalization to \n.
			string normalizedNewlines = NewlineNormalizationExpression.Replace(value ?? string.Empty, "\n");

			// Replace all of the \n with a full newline
			return normalizedNewlines.Replace("\n", Environment.NewLine);
		}
		#endregion
	}
}
