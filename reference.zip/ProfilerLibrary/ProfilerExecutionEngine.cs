﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Net;
using System.Reflection;
using System.Security;
using System.Security.Permissions;
using System.Security.Policy;
using System.Text.RegularExpressions;

using PluginProfiler.Library.Reporting;
using PluginProfiler.Plugins;
using System.Collections.ObjectModel;
using System.Globalization;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Engine that is used to replay or debug the plug-in
	/// </summary>
	public sealed class ProfilerExecutionEngine : IDisposable
	{
		private AppDomain _domain;
		private IProfilerTracingService _tracing;
		private static readonly IList<Assembly> TrustedAssemblies = new ReadOnlyCollection<Assembly>(new Assembly[] 
		{
				// Microsoft.Xrm.Sdk.dll
				typeof(Microsoft.Xrm.Sdk.Entity).Assembly,

				// Microsoft.Crm.Sdk.Proxy.dll
				typeof(Microsoft.Crm.Sdk.Messages.WhoAmIRequest).Assembly,

				// PluginProfiler.Library.dll
				typeof(ProfilerExecutionReport).Assembly,

				// PluginProfiler.Plugins.dll
				typeof(ProfilerPlugin).Assembly
		});

		private static readonly IList<Assembly> VisibleToPartialTrustAssemblies = new ReadOnlyCollection<Assembly>(new Assembly[]
		{
			// System.Activities.dll
			typeof(System.Activities.CodeActivity).Assembly,

			// System.ServiceMode.Activities.dll
			typeof(System.ServiceModel.Activities.WorkflowService).Assembly,
			
			// System.Activities.DurableInstancing.dll
			typeof(System.Activities.DurableInstancing.InstanceEncodingOption).Assembly,

			// Microsoft.Xrm.Sdk.Workflow.dll
			typeof(Microsoft.Xrm.Sdk.Workflow.InputAttribute).Assembly
		});

		/// <summary>
		/// Instantiates an instance of the ProfilerPluginEngine class.
		/// </summary>
		/// <param name="permissions">Permissions to be used in the engine</param>
		/// <param name="tracing">Tracing service for the engine</param>
		public ProfilerExecutionEngine(PluginPermissions permissions, IProfilerTracingService tracing)
		{
			this._tracing = tracing ?? new ProfilerConsoleTracingService();
			this._domain = this.CreateAppDomain(permissions);
			this._tracing.Trace("Plug-in AppDomain Created");
		}

		~ProfilerExecutionEngine()
		{
			this.Dispose(false);
		}

		#region IDisposable Members
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}
		#endregion

		#region Methods
		/// <summary>
		/// Execute the plug-in
		/// </summary>
		/// <param name="configuration">Configuration for the execution</param>
		/// <returns>true if no exceptions occurred, or false if an exception occurred.</returns>
		public ProfilerExecutionReport Execute(ProfilerExecutionConfiguration configuration)
		{
			if (null == this._domain)
			{
				throw new ObjectDisposedException(this.GetType().FullName);
			}
			else if (null == configuration)
			{
				throw new ArgumentNullException("configuration");
			}

			AppDomainProxy proxy = configuration.OperationConfiguration.Proxy;
			if (null == proxy)
			{
				Type proxyType;
				switch (configuration.OperationConfiguration.OperationType)
				{
					case OperationType.Plugin:
						proxyType = typeof(PluginAppDomainProxy);
						break;
					case OperationType.WorkflowActivity:
						proxyType = typeof(WorkflowAppDomainProxy);
						break;
					default:
						throw new NotImplementedException("OperationType = " + configuration.OperationConfiguration.OperationType);
				}

				proxy = AppDomainProxy.CreateProxy(proxyType, this._domain, configuration.OperationConfiguration, TrustedAssemblies);
				configuration.OperationConfiguration.Proxy = proxy;
			}

			ProfilerExecutionReport report = new ProfilerExecutionReport();
			proxy.Execute(configuration, report);
			report.MarkReadOnly();

			return report;
		}
		#endregion

		#region Private Methods
		private void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (null != this._domain)
				{
					AppDomain.Unload(this._domain);
					this._tracing.Trace("Profiler AppDomain Unloaded");
					this._domain = null;
				}
			}
		}

		private AppDomain CreateAppDomain(PluginPermissions domainPermissions)
		{
			if (domainPermissions.HasFlag(PluginPermissions.NonIsolated))
			{
				return AppDomain.CreateDomain("Profiler Domain");
			}

			AppDomainSetup setup = new AppDomainSetup();

			if (domainPermissions.HasFlag(PluginPermissions.ExecutePartialTrustCode))
			{
				//Set the path to a random location to eliminate the ability to access the file system while loading an assembly
				setup.ApplicationBase = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("B"));
			}

			// Create the list of assemblies that will be able to execute in full trust
			StrongName[] trustedAssemblyNames = new StrongName[TrustedAssemblies.Count];
			for (int i = 0; i < TrustedAssemblies.Count; i++)
			{
				trustedAssemblyNames[i] = CreateStrongName(TrustedAssemblies[i]);
			}

			// Create the list of assemblies that must be marked as visible to partial trust
			string[] partialTrustVisibleAssemblies = new string[VisibleToPartialTrustAssemblies.Count];
			for (int i = 0; i < VisibleToPartialTrustAssemblies.Count; i++)
			{
				partialTrustVisibleAssemblies[i] = CreateAssemblyKeyName(VisibleToPartialTrustAssemblies[i]);
			}
			setup.PartialTrustVisibleAssemblies = partialTrustVisibleAssemblies;

			PermissionSet permissions = this.CreatePermissionSet(domainPermissions);
			return AppDomain.CreateDomain("Plug-in Domain", null, setup, permissions, trustedAssemblyNames);
		}

		private PermissionSet CreatePermissionSet(PluginPermissions requestedPermissions)
		{
			if (requestedPermissions.HasFlag(PluginPermissions.NonIsolated))
			{
				return new PermissionSet(PermissionState.Unrestricted);
			}

			PermissionSet permissionSet = new PermissionSet(PermissionState.None);
			permissionSet.AddPermission(new SecurityPermission(SecurityPermissionFlag.Execution));

			if (requestedPermissions.HasFlag(PluginPermissions.ExecuteHttpRequests))
			{
				string defaultUriPattern = @"^http[s]?://(?!((localhost[:/])|(\[.*\])|([0-9]+[:/])|(0x[0-9a-f]+[:/])|(((([0-9]+)|(0x[0-9A-F]+))\.){3}(([0-9]+)|(0x[0-9A-F]+))[:/]))).+";

				WebPermission webPermission = new WebPermission();
				webPermission.AddPermission(NetworkAccess.Connect,
					new Regex(defaultUriPattern, RegexOptions.Compiled | RegexOptions.IgnoreCase |
						RegexOptions.Singleline | RegexOptions.CultureInvariant));
				permissionSet.AddPermission(webPermission);
			}

			return permissionSet;
		}

		private static string CreateAssemblyKeyName(Assembly assembly)
		{
			// Create the strong name, which includes the version and the culture in addition to the required values
			StrongName name = CreateStrongName(assembly);

			// Format into the assembly / key name
			return string.Format(CultureInfo.InvariantCulture, "{0}, PublicKey={1}", assembly.GetName().Name, name.PublicKey.ToString());
		}

		private static StrongName CreateStrongName(Assembly assembly)
		{
			if (null == assembly)
			{
				throw new ArgumentNullException("assembly");
			}

			AssemblyName name = assembly.GetName();
			if (null == name)
			{
				throw new ArgumentNullException("assembly", "Assembly.GetName() did not return a value.");
			}

			//Retrieve the public key blob. If there isn't one, then this isn't a strongly-named assembly
			byte[] key = name.GetPublicKey();
			if (null == key || 0 == key.Length)
			{
				throw new InvalidOperationException("Assembly must be strongly-named.");
			}

			return new StrongName(new StrongNamePublicKeyBlob(key),
				name.Name, name.Version);
		}
		#endregion
	}

	#region Enums
	/// <summary>
	/// Permissions to be applied to the AppDomain
	/// </summary>
	[Flags]
	[SuppressMessage("Microsoft.Design", "CA1008:EnumsShouldHaveZeroValue",
		Justification = "ExecutePartialTrustCode is the correct default value.")]
	public enum PluginPermissions
	{
		/// <summary>
		/// Indicates that partial trust should be executable
		/// </summary>
		ExecutePartialTrustCode = 0,

		/// <summary>
		/// Indicates that HTTP requests should be allowed
		/// </summary>
		ExecuteHttpRequests,

		/// <summary>
		/// Set of permissions that are enabled in the CRM Sandbox
		/// </summary>
		Sandbox = ExecutePartialTrustCode | ExecuteHttpRequests,

		/// <summary>
		/// All permissions are granted to the code
		/// </summary>
		NonIsolated
	}
	#endregion
}
