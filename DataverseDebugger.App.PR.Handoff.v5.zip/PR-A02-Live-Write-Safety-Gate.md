# PR-A02 – Live Write Safety Gate (Explicit Opt-In)

## Objective
Implement an explicit AllowLiveWrites safety gate in the App UI and behavior.

## Invariants
- No Runner changes.
- Enabling live writes requires explicit confirmation.
- Preserve existing async-step disable/reenable behavior.

## Target Files (In-Scope)
- `MainWindow.xaml.cs`
- `Views/SettingsView.xaml`
- `Models/RunnerSettingsModel.cs`

## Required UX Behavior (Authoritative)
- AllowLiveWrites:
  - Default OFF
  - Only interactive when ExecutionMode == Online
  - Enabling shows warning dialog
  - Cancelling reverts toggle
  - Failure to disable async steps reverts toggle
  - Disabling re-enables async steps

## Acceptance Criteria (Manual)
- Toggle disabled unless Online.
- Enabling prompts; cancel reverts.
- Enabling disables async steps; failure reverts.
- Disabling re-enables async steps.
- Derived WriteMode matches PR-A00 mapping.
