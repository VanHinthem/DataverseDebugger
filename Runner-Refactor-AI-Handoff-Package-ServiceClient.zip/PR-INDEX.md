# Unified Runner Refactor — PR Execution Index (v1.1)

This index references the patched PR documents that lock down:
- standardized `RunnerNotSupportedException`
- PluginInvocationEngine return contract (behavior-preserving)
- constructor selection preservation
- AllowLiveWrites configuration source
- ServiceClient-backed live `IOrganizationService` for plugin debugging (Online/Hybrid)


This index is the **single entry point** for executing the DataverseDebugger.Runner refactor.
PRs **must be executed sequentially**. Do **not** skip acceptance criteria.

---

## How to use this index

**Internal projects rule:** All new execution logic must be implemented in `DataverseDebugger.Runner`. Changes to `DataverseDebugger.Protocol` and `DataverseDebugger.Runner.Conversion` are allowed only for backward-compatible contract/DTO additions and required mapping/translation updates.

1. Execute PRs **in order (PR01 → PR06)**.
2. Each PR has:
   - clear scope
   - non-negotiables
   - acceptance criteria
   - a copy-paste AI prompt
3. **Do not start the next PR until the current PR meets all acceptance criteria.**
4. Preserve backward compatibility unless explicitly instructed otherwise.

---

## PR Sequence (Authoritative)

### PR01 — Scaffolding + ExecutionMode Contract (No Behavior Change)
**Purpose**
- Introduce structural scaffolding
- Add optional sender-controlled `ExecutionMode`
- Zero runtime behavior change

**Document**
- `PR01-Scaffolding-+-ExecutionMode-Contract-(No-Behavior-Change).md`

**Gate**
- Solution compiles
- Existing behavior unchanged
- Old clients still function

---

### PR02 — Extract Unified PluginInvocationEngine (Behavior-Preserving)
**Purpose**
- Create a single unified execution engine
- Preserve behavior exactly

**Document**
- `PR02-Extract-Unified-PluginInvocationEngine-(Behavior-Preserving).md`

**Gate**
- Outputs and traces match pre-PR behavior
- RunnerPipeServer delegates cleanly

---

### PR03 — Sender-Controlled Mode Selection + Online Safety Gate
**Also introduces:** ServiceClient-backed live `IOrganizationService` for plugin debugging paths.
**Purpose**
- Make `ExecutionMode` authoritative
- Preserve legacy fallback
- Prevent accidental live writes

**Document**
- `PR03-Sender-Controlled-Mode-Selection-+-Online-Safety-Gate.md`

**Gate**
- Hybrid/Online selectable by sender
- Online blocked unless `AllowLiveWrites=true`

---

### PR04 — Offline MVP (Deterministic, No Live Access)
**Purpose**
- True offline execution
- Deterministic, isolated behavior

**Document**
- `PR04-Offline-MVP-(Deterministic,-No-Live-Access).md`

**Gate**
- No live calls in Offline mode
- Plugins execute end-to-end offline
- Execute supports WhoAmI only

---

### PR05 — Hybrid Correctness (Merge + Overlay + Execute Whitelist)
**Purpose**
- Correct Hybrid semantics
- Cache-prevails reads
- Strict Execute policy

**Document**
- `PR05-Hybrid-Correctness-(Merge-+-Overlay-+-Execute-Whitelist).md`

**Gate**
- Cached writes never hit live
- Reads reflect cached changes correctly
- All rules test-covered

---

### PR06 — Regression + Documentation + Final Validation
**Purpose**
- Prove no regressions
- Document architecture and limitations

**Document**
- `PR06-Regression-+-Documentation-+-Final-Validation.md`

**Gate**
- All tests pass
- Documentation matches implementation
- System ready for handoff

---

## Final Rule

If a PR fails its gate, **do not proceed**.

If an ambiguity or conflict arises that cannot be resolved unambiguously using the PR documents and v2 plan:
- Stop
- Do not guess
- Ask the repository owner for clarification before continuing

Fix the PR, update tests, and re-validate before continuing.

---

_End of index_
