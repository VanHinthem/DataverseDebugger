﻿namespace Microsoft.Dynamics.ProjectOperations.PluginForge
{
    public class SettingsFileConnectionSettings : IConnectionSettings
    {
        public string Profile { get; set; }
        public string OrganizationUrl { get; set; }
        public string FQDNOrgUrl { get; set; }
        public string Audience { get; set; }
        public string UserPrincipalName { get; set; }
        public string Password {    get; set; }
        public string TenantId { get; set; }
        public string SubjectName { get; set; }
        public string TestUserPrincipalName { get; set; }
        public string TestUserSubjectName { get; set; }
        public string TokenCacheStorePath { get; set; }
    }
}
