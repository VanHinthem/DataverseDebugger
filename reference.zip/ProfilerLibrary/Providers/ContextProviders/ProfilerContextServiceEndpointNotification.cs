﻿using System;

using Microsoft.Xrm.Sdk;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Plug-in profiler implementation of the IServiceEndpointNotificationService interface
	/// </summary>
	/// <remarks>
	/// This class is currently a placeholder that is not ready for use
	/// </remarks>
	public sealed class ProfilerContextServiceEndpointNotification : IServiceEndpointNotificationService
	{
		#region IServiceEndpointNotificationService Members
		public string Execute(EntityReference serviceEndpoint, IExecutionContext context)
		{
			throw new NotImplementedException();
		}
		#endregion
	}
}
