﻿using System;
using System.IO;
using System.Net;
using System.Reflection;
using System.Security;
using System.Security.Permissions;
using System.Text.RegularExpressions;

using PluginProfiler.Library.Reporting;

using Microsoft.Xrm.Sdk;
using System.Globalization;
using System.ServiceModel;
using PluginProfiler.Plugins;
using PluginProfiler.Plugins.ServiceWrappers;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Configuration to be used for the operation for replay or debug of the operation
	/// </summary>
	[Serializable]
	public abstract class OperationConfiguration
	{
		protected OperationConfiguration(OperationType type, string assemblyFilePath, string typeName, string logFilePath)
		{
			if (string.IsNullOrWhiteSpace(assemblyFilePath))
			{
				throw new ArgumentNullException("assemblyFilePath");
			}
			else if (string.IsNullOrWhiteSpace(logFilePath))
			{
				throw new ArgumentNullException("logFilePath");
			}

			this.AssemblyFilePath = assemblyFilePath;
			this.ProfilerLogPath = logFilePath;
			this.TypeName = typeName;
			this.OperationType = type;
		}

		#region Properties
		/// <summary>
		/// Path to the assembly
		/// </summary>
		public string AssemblyFilePath { get; private set; }

		/// <summary>
		/// Path to the profiler log
		/// </summary>
		public string ProfilerLogPath { get; private set; }

		/// <summary>
		/// Name of the type
		/// </summary>
		public string TypeName { get; private set; }

		/// <summary>
		/// Type of operation that will be executed
		/// </summary>
		public OperationType OperationType { get; private set; }

		/// <summary>
		/// Proxy for the Plug-in
		/// </summary>
		internal AppDomainProxy Proxy { get; set; }
		#endregion
	}
}