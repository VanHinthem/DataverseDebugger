# PR 4 — Offline MVP (Deterministic, No Live Access)

**Repo:** DataverseDebugger

## Global Non-Negotiables
1. No new external project references; reference ZIPs are conceptual only.
2. Do not refactor WebAPI entry wiring; only add a thin delegation seam when instructed.
3. Single-plugin execution only; no pipeline re-entry simulation.
4. Sender-controlled `ExecutionMode` is authoritative when provided; legacy fallback remains when absent.
5. Keep all changes inside existing `DataverseDebugger.Runner` project (no new projects).
6. Keep diffs minimal and reviewable; avoid opportunistic refactors.
7. Add deterministic errors for guards/NotSupported (include mode + operation + guidance).

## AI Implementation Rules
- Preserve current behavior unless this PR explicitly changes it.
- Maintain backward compatibility for request/response serialization.
- Add tests as specified; do not skip tests.



## Objective
Implement true Offline mode: fully isolated from live, deterministic, in-memory.

## Scope
- Add `Services/Offline/OfflineOrganizationService` implementation.
- No live connectivity in Offline mode, even if token exists.
- CRUD + RetrieveMultiple + Retrieve.
- Execute supports **WhoAmIRequest only**; all other Execute requests throw deterministic NotSupported.

## Deliverables
### A) Offline entity store
- In-memory store keyed by (logicalName, id)
- Deep clone on store and return
- Immediate application semantics (no rollback)

### B) OfflineOrganizationService
- Implement `Create`, `Update`, `Delete`, `Retrieve`, `RetrieveMultiple`
- Implement `Execute`:
  - WhoAmIRequest only
    - Default: return **fixed GUIDs** for UserId/BusinessUnitId/OrganizationId unless explicitly provided by the sender or runner config
  - else throw `RunnerNotSupportedException` (include mode + request type + guidance)

### C) Seeding
For MVP: seed store with:
- Target entity (if provided)
- Pre/Post images (if provided)

### D) Engine wiring
- When resolved mode is Offline, engine uses OfflineOrganizationService.

### Tests
- Unit tests for OfflineOrganizationService CRUD and RetrieveMultiple basics
- Integration test: Profiler Entry (or existing entry) + Offline mode executes a minimal test plugin successfully

### Acceptance criteria
- Offline mode never attempts live calls
- Offline mode can run a plugin end-to-end using in-memory data
- Execute is WhoAmI only; others deterministic NotSupported

## AI Prompt (copy/paste)
> Implement PR4: add a true OfflineOrganizationService with an in-memory entity store (deep clone on store/return). Support Create/Update/Delete/Retrieve/RetrieveMultiple and Execute(WhoAmI only). Wire Offline mode in PluginInvocationEngine. Seed the store with Target and images for MVP. Add unit and integration tests proving deterministic offline execution and no live calls.

