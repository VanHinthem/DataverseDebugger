﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.PluginTelemetry;

namespace Microsoft.Dynamics.ProjectOperations.PluginForge
{


    public static class DependencyInjectionConfig
    {
        public static IServiceCollection ConfigurePluginExecutionContext(this IServiceCollection services,
            LocalPluginExecutionContext context)
        {

            services.AddSingleton<IPluginExecutionContext>(x =>
            {
                return context;
            });

            return services;
        }

        public static IServiceCollection ConfigurePluginCommonAttributes(this IServiceCollection services,
            IOrganizationService OrganizationService)
        {

            // Register tracing service
            services.AddSingleton<IOrganizationService>(x =>
            {
                return OrganizationService;
            }
            );
            services.AddSingleton<IOrganizationServiceFactory, LocalrganizationServiceFactory>();

            services.AddSingleton<ILogger, LocalLogger>();

            return services;

        }
    }
}
