﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.ServiceModel.Description;

using Microsoft.Crm.Sdk.Messages;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System.Diagnostics.CodeAnalysis;
using PluginProfiler.Library.Reporting;
using System.Security;
using System.Security.Permissions;

namespace PluginProfiler.Library
{
	/// <summary>
	/// IOrganizationServiceFactory that connects back to the server for any given user.
	/// </summary>
	[Serializable]
	internal sealed class ProfilerContextAppDomainOrganizationServiceFactory : IOrganizationServiceFactory
	{
		private readonly ProfilerContextOrganizationServiceFactory ProxyFactory;
		private readonly Guid AdministratorUserId;

		/// <summary>
		/// Instantiates an instance of the ProfilerContextAppDomainOrganizationServiceFactory class.
		/// </summary>
		public ProfilerContextAppDomainOrganizationServiceFactory(ProfilerContextOrganizationServiceFactory factory)
		{
			if (null == factory)
			{
				throw new ArgumentNullException("factory");
			}

			this.ProxyFactory = factory;
			this.AdministratorUserId = factory.AdministratorUserId;
		}

		#region Methods
		internal Guid CurrentUserId { get; set; }

		internal Assembly ProxyTypesAssembly { get; set; }

		internal bool IncludeProxyTypesInDefaultDomain { get; set; }

		internal ProfilerExecutionReport Report { get; set; }
		#endregion

		#region IOrganizationServiceFactory Members
		/// <summary>
		/// Creates an organization service for the given user
		/// </summary>
		/// <param name="userId">User ID that should be used</param>
		[SuppressMessage("Microsoft.Usage", "CA9888:DisposeObjectsCorrectly", MessageId = "proxy",
			Justification = "Proxy is null before it is set. It is returned to the user and cannot be disposed.")]
		public IOrganizationService CreateOrganizationService(Guid? userId)
		{
			// If userId is Guid.Empty, it means the CurrentUserId should be used.
			if (Guid.Empty == userId)
			{
				userId = this.CurrentUserId;
			}

			// In the case where the SdkMessageProcessingStep.ImpersonatingUserId is set to SYSTEM, the Current User ID will be "SYSTEM"
			// which has an id of Guid.Empty. In that case, the AdministratorId should be used. If the ID is null, it means that "SYSTEM"
			// is being explicitly requested.
			if (null == userId || Guid.Empty == userId)
			{
				userId = this.AdministratorUserId;
			}

			return new ProfilerContextAppDomainOrganizationService(this.ProxyFactory.CreateProxy(this.Report, userId.GetValueOrDefault()),
				this.ProxyTypesAssembly, this.IncludeProxyTypesInDefaultDomain);
		}
		#endregion
	}
}
