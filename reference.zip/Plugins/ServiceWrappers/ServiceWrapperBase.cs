﻿using System;
using System.Globalization;
using System.Reflection;
using System.ServiceModel;

using Microsoft.Xrm.Sdk;

namespace PluginProfiler.Plugins.ServiceWrappers
{
	/// <summary>
	/// Base class for the ServiceWrappers
	/// </summary>
	internal abstract class ServiceWrapperBase<T>
		where T : class
	{
		/// <summary>
		/// Instantiates an instance of the ServiceWrapperBase class.
		/// </summary>
		/// <param name="service">Actual service provided by the original IServiceProvider instance.</param>
		/// <param name="context">Context for execution in the plug-in profiler.</param>
		public ServiceWrapperBase(T service, ProfilerPluginContext context)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}
			else if (null == context)
			{
				throw new ArgumentNullException("context");
			}

			this.InternalService = service;
			this.Context = context;
		}

		#region Properties
		/// <summary>
		/// Context for execution in the plug-in profiler.
		/// </summary>
		protected ProfilerPluginContext Context { get; private set; }

		/// <summary>
		/// Actual service provided by the original IServiceProvider instance.
		/// </summary>
		protected T InternalService { get; private set; }
		#endregion
	}
}
