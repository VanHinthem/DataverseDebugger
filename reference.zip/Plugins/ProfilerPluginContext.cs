﻿using System;
using System.Collections.Generic;

using Microsoft.Xrm.Sdk;

using PluginProfiler.Plugins.ServiceWrappers;

namespace PluginProfiler.Plugins
{
	/// <summary>
	/// Tracks the current context of the profiler
	/// </summary>
	internal sealed class ProfilerPluginContext
	{
		private readonly ITracingService Tracing;

		/// <summary>
		/// Instantiates an instance of the ProfilerPluginContext class.
		/// </summary>
		/// <param name="config">ProfilerConfiguration instance indicating the configuration of the current activity</param>
		/// <param name="proxyWrapper">Conversion utility instance to convert early/late bound objects</param>
		/// <param name="report">ProfilerPluginReport that will contain the results of the profiler</param>
		/// <param name="context">IExecutionContext instance that will be provided for the activity</param>
		/// <param name="services">Services that should be added to the Service Provider</param>
		internal ProfilerPluginContext(ProfilerConfiguration config, ProxyTypesWrapper proxyWrapper, ProfilerPluginReport report,
			ExecutionContextWrapper context, Dictionary<Type, object> services)
		{
			if (null == config)
			{
				throw new ArgumentNullException("config");
			}
			else if (null == proxyWrapper)
			{
				throw new ArgumentNullException("proxyWrapper");
			}
			else if (null == report)
			{
				throw new ArgumentNullException("report");
			}
			else if (null == context)
			{
				throw new ArgumentNullException("context");
			}
			else if (null == services)
			{
				throw new ArgumentNullException("services");
			}

			this.ServiceProvider = new ServiceProviderWrapper(services, this);
			this.ProxyWrapper = proxyWrapper;
			this.Report = report;
			this.UserId = context.UserId;
			this.Tracing = this.ServiceProvider.GetService<ITracingService>();
		}

		#region Properties
		/// <summary>
		/// Conversion utility instance to convert early/late bound objects
		/// </summary>
		public ProxyTypesWrapper ProxyWrapper { get; private set; }

		/// <summary>
		/// ProfilerPluginReport that will contain the results of the profiler
		/// </summary>
		public ProfilerPluginReport Report { get; private set; }

		/// <summary>
		/// IServiceProvider that was initially provided to the plug-in
		/// </summary>
		public ServiceProviderWrapper ServiceProvider { get; private set; }

		/// <summary>
		/// User ID for the current user
		/// </summary>
		public Guid UserId { get; private set; }
		#endregion

		#region Methods
		/// <summary>
		/// Trace the given statement to the ITracingService
		/// </summary>
		public void Trace(string format, params object[] args)
		{
			if (null != this.Tracing)
			{
				this.Tracing.Trace(format, args);
			}
		}
		#endregion
	}
}
