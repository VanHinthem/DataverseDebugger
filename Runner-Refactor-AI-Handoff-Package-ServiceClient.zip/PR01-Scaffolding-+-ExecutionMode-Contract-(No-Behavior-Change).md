# PR 1 — Scaffolding + ExecutionMode Contract (No Behavior Change)

**Repo:** DataverseDebugger

## Global Non-Negotiables
1. No new external project references; reference ZIPs are conceptual only.
2. Do not refactor WebAPI entry wiring; only add a thin delegation seam when instructed.
3. Single-plugin execution only; no pipeline re-entry simulation.
4. Sender-controlled `ExecutionMode` is authoritative when provided; legacy fallback remains when absent.
5. Keep all changes inside existing `DataverseDebugger.Runner` project (no new projects).
6. Keep diffs minimal and reviewable; avoid opportunistic refactors.
7. Add deterministic errors for guards/NotSupported (include mode + operation + guidance).

## AI Implementation Rules
- Preserve current behavior unless this PR explicitly changes it.
- Maintain backward compatibility for request/response serialization.
- Add tests as specified; do not skip tests.



## Objective
Introduce structural scaffolding for the unified execution pipeline and add an optional sender-controlled `ExecutionMode` field to the request contract. **No runtime behavior changes**.

## Project scope rule
- All new execution logic must be implemented in `DataverseDebugger.Runner`.
- Changes to `DataverseDebugger.Protocol` are allowed only for **backward-compatible** DTO/contract additions.
- Changes to `DataverseDebugger.Runner.Conversion` are allowed only for required mapping/translation updates to support those DTO changes.

## Deliverables

### A) Protocol (backward compatible)
**File:** `DataverseDebugger.Protocol` (where `PluginInvokeRequest` lives)

- Add optional string property: `ExecutionMode`
  - Allowed values (case-insensitive): `Offline`, `Hybrid`, `Online`
  - Keep existing `WriteMode` unchanged
- Do not change existing serialization format beyond adding the new optional field

### B) Runner scaffolding (compile-safe, minimal implementations)
Create folders under `DataverseDebugger.Runner`:

```
Abstractions/
Configuration/
Pipeline/
EntryAdapters/
ExecutionContext/
Logging/
Services/Offline/
Services/Hybrid/
Services/Live/
```

Create these files (skeletons; compile-safe defaults where trivial):

**Abstractions**
- `Abstractions/ExecutionMode.cs` (enum: Offline, Hybrid, Online)
- `Abstractions/EntryMechanism.cs` (enum: WebApi, Profiler)
- `Abstractions/RunnerNotSupportedException.cs` (derives from NotSupportedException; includes Mode + Operation + Guidance)

**Configuration**
- `Configuration/RunnerExecutionOptions.cs`
  - `bool AllowLiveWrites` default `false`

**Pipeline**
- `Pipeline/ExecutionRequest.cs` (container for normalized request data)
- `Pipeline/ExecutionResult.cs` (container for outputs + logs + error)
- `Pipeline/PluginInvocationEngine.cs` (stub; throws NotImplementedException for now)

**EntryAdapters**
- `EntryAdapters/WebApiEntryAdapter.cs` (stub mapping; not wired yet)
- `EntryAdapters/ProfilerEntryAdapter.cs` (stub mapping; not wired yet)

**ExecutionContext**
- `ExecutionContext/RunnerPluginExecutionContext.cs`
  - Implements `IPluginExecutionContext`
  - Must guarantee: non-null dictionaries/collections, safe defaults, CorrelationId non-empty
- `ExecutionContext/IExecutionContextBuilder.cs` (interface)
- `ExecutionContext/WebApiContextBuilder.cs` (stub)
- `ExecutionContext/ProfilerContextBuilder.cs` (stub)

**Logging**
- `Logging/RunnerLogEntry.cs`
- `Logging/IRunnerLogger.cs`
- `Logging/RunnerLogger.cs` (in-memory list)
- `Logging/TracingServiceAdapter.cs` (implements `ITracingService`, writes to logger)

**Services**
- `Services/Offline/OfflineOrganizationService.cs` (stub; throws NotImplementedException)
- `Services/Hybrid/HybridWriteCache.cs` (data structure only)
- `Services/Hybrid/EntityMergeUtility.cs` (stub)

### C) Standardized error type
- Add `RunnerNotSupportedException` for deterministic NotSupported failures across modes.

### D) Acceptance criteria
- Solution compiles
- Existing tests pass
- Runner runtime behavior unchanged (ExecutionMode not used yet)
- Old senders still work (ExecutionMode absent)

## AI Prompt (copy/paste)
> Implement PR1 scaffolding inside DataverseDebugger.Runner (no new projects). Add optional string ExecutionMode to PluginInvokeRequest (case-insensitive: Offline/Hybrid/Online). Do not change runtime behavior. Ensure compilation, safe defaults in RunnerPluginExecutionContext, and add no-op/stub classes listed in the PR1 doc. Keep WriteMode unchanged and preserve backward compatibility.

