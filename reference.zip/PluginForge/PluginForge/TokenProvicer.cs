﻿using System;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CertBasedAuth.Test;

namespace Microsoft.Dynamics.ProjectOperations.PluginForge
{
    /// <summary>
    /// Static class container comprising a token provider.
    /// </summary>
    internal static class TokenProvider
    {
        private static readonly MemoryCache<string> cache = new MemoryCache<string>(TimeSpan.FromMinutes(10));

        /// <summary>
        /// Obtains an authentication token from the specified information.
        /// </summary>
        /// <param name="baseUrl">The organization url.</param>
        /// <param name="username">An organization user name.</param>
        /// <param name="clientId">Application client identifier.</param>
        /// <param name="aadAuthority">The sign-in audience URI for the application.</param>
        /// <param name="certName">The subject name of a certificate associated with <paramref name="username"/>.</param>
        /// <param name="redirectUri">A redirect URI.</param>
        /// <param name="tenantId">The tenant identifier associated with <paramref name="username"/>.</param>
        /// <returns>An authentication token from the given information.</returns>
        /// <exception cref="ArgumentNullException">Thrown when any argument is null, empty, or white space.</exception>
        /// <remarks>
        /// Uses non-interactive certificate based authentication.
        /// 
        /// Ref:  Sourced from <![CDATA[https://dev.azure.com/dynamicscrm/OneCRM/_git/CAP.Engineering?path=/src/CertBasedAuth/CertBasedAuthTest.cs&version=GBmaster&line=84&lineEnd=84&lineStartColumn=23&lineEndColumn=40&lineStyle=plain&_a=contents]]>
        /// Awaiting nuget package for proper consumption.
        /// </remarks>
        public static string ObtainNonInteractiveCba(
            string baseUrl,
            string username,
            string clientId,
            string aadAuthority,
            string certName,
            string redirectUri,
            string tenantId)
        {
            if (string.IsNullOrWhiteSpace(baseUrl))
            {
                throw new ArgumentNullException(nameof(baseUrl));
            }

            if (string.IsNullOrWhiteSpace(username))
            {
                throw new ArgumentNullException(nameof(username));
            }

            if (string.IsNullOrWhiteSpace(clientId))
            {
                throw new ArgumentNullException(nameof(clientId));
            }

            if (string.IsNullOrWhiteSpace(aadAuthority))
            {
                throw new ArgumentNullException(nameof(aadAuthority));
            }

            if (string.IsNullOrWhiteSpace(certName))
            {
                throw new ArgumentNullException(nameof(certName));
            }

            if (string.IsNullOrWhiteSpace(redirectUri))
            {
                throw new ArgumentNullException(nameof(redirectUri));
            }

            if (string.IsNullOrWhiteSpace(tenantId))
            {
                throw new ArgumentNullException(nameof(tenantId));
            }

            string keyName = $"{username}{certName}{tenantId}{baseUrl}{clientId}{aadAuthority}{redirectUri}";

            CreateCacheItem<string> createItem = (key) =>
            {
                (string Token, TimeSpan Expiration) accessToken;

                using (var certificate = CertificateProvider.FindBySubjectName(certName))
                using (var browserBasedNonInteractiveCba = new BrowserBasedNonInteractiveCba())
                {
                    // Remove any trailing port from the resource before token acquisition
                    string resource = Regex.Replace(baseUrl, @":\d+\/*$", string.Empty);
                    string scope = $"{resource}/user_impersonation";
                    string[] scopes = { scope };

                    accessToken = Task.Run<(string, TimeSpan)>(
                                    async () => await browserBasedNonInteractiveCba.GetTokenWithCertificateSilentlyAsync(
                                                        authority: aadAuthority,
                                                        clientId: clientId,
                                                        scope: string.Join(" ", scopes), // https://learn.microsoft.com/en-us/entra/identity-platform/v2-oauth2-auth-code-flow
                                                        redirectUri: redirectUri,
                                                        tenantId: tenantId,
                                                        username: username,
                                                        certificate: certificate))
                                    .ConfigureAwait(false)
                                    .GetAwaiter()
                                    .GetResult();

                    accessToken.Expiration = accessToken.Expiration == TimeSpan.FromSeconds(0)
                                                ? TimeSpan.FromSeconds(300)
                                                : accessToken.Expiration;
                }

                if (string.IsNullOrWhiteSpace(accessToken.Token))
                {
                    throw new InvalidOperationException($"Error occurred while fetching access token using cert based authentication for {username} user.");
                }

                DateTimeOffset tokenExpiration = DateTimeOffset.Now.Add(accessToken.Expiration).Subtract(TimeSpan.FromMinutes(5));
                DateTimeOffset maxExpiration = DateTimeOffset.Now.AddHours(1);

                return new CacheItem<string>(accessToken.Token, tokenExpiration < maxExpiration ? tokenExpiration : maxExpiration);
            };

            return TokenProvider.cache.Obtain(keyName, createItem);
        }
    }
}
