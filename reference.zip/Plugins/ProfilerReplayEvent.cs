﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;
using System.Runtime.Serialization;

using Microsoft.Xrm.Sdk;

namespace PluginProfiler.Plugins
{
	#region Replay Events
	/// <summary>
	/// Base class for all events that need to be reported
	/// </summary>
	[DataContract]
	[KnownType(typeof(OrganizationServiceReplayEvent))]
	[KnownType(typeof(ServiceEndpointNotificationReplayEvent))]
	public abstract class ProfilerReplayEvent
	{
		/// <summary>
		/// Instantiates an instance of the ProfilerReplayEvent class
		/// </summary>
		/// <param name="elapsedTime">Time that has elapsed for the operation to complete</param>
		protected ProfilerReplayEvent(TimeSpan elapsedTime)
		{
			this.DurationInMilliseconds = elapsedTime.TotalMilliseconds;
		}

		/// <summary>
		/// Duration of the calls that were sent to the server
		/// </summary>
		[DataMember]
		public double DurationInMilliseconds { get; private set; }
	}

	/// <summary>
	/// Represents events that occur in the IServiceEndpointNotificationService interface
	/// </summary>
	[DataContract(Name = "ServiceEndpointNotificationReplayEvent", Namespace = "PluginProfiler.Plugins")]
	public sealed class ServiceEndpointNotificationReplayEvent : ProfilerReplayEvent
	{
		/// <summary>
		/// Instantiates an instance of the ServiceEndpointNotificationReplayEvent class
		/// </summary>
		/// <param name="fault">Fault that occurred</param>
		/// <param name="elapsedTime">Time that has elapsed for the operation to complete</param>
		internal ServiceEndpointNotificationReplayEvent(OrganizationServiceFault fault, TimeSpan elapsedTime)
			: base(elapsedTime)
		{
			if (null == fault)
			{
				throw new ArgumentNullException("fault");
			}

			this.Fault = fault;
		}

		/// <summary>
		/// Instantiates an instance of the ServiceEndpointNotificationReplayEvent class
		/// </summary>
		/// <param name="result">Result that was returned from the server</param>
		/// <param name="elapsedTime">Time that has elapsed for the operation to complete</param>
		internal ServiceEndpointNotificationReplayEvent(string result, TimeSpan elapsedTime)
			: base(elapsedTime)
		{
			this.Result = result;
		}

		[DataMember]
		public string Result { get; private set; }

		[DataMember]
		public OrganizationServiceFault Fault { get; private set; }
	}

	[DataContract(Name = "OrganizationServiceReplayEvent", Namespace = "PluginProfiler.Plugins")]
	public sealed class OrganizationServiceReplayEvent : ProfilerReplayEvent
	{
		/// <summary>
		/// Instantiates an instance of the OrganizationServiceReplayEvent class
		/// </summary>
		/// <param name="operationName">Operation that was executed</param>
		/// <param name="elapsedTime">Time that elapsed during the execution of the event</param>
		/// <param name="inputs">Inputs that were provided to the operation</param>
		/// <param name="result">Result of the call to the server</param>
		internal OrganizationServiceReplayEvent(string operationName, TimeSpan elapsedTime, IDictionary<string, object> inputs, object result)
			: base(elapsedTime)
		{
			if (string.IsNullOrWhiteSpace(operationName))
			{
				throw new ArgumentNullException("operationName");
			}

			this.OperationName = operationName;

			//Add the inputs to the operation to the replay
			if (null != inputs)
			{
				//Loop through the provided inputs and convert them into a list of serializable values
				Collection<SerializedValue> operationInputs = new Collection<SerializedValue>();
				foreach (KeyValuePair<string, object> input in inputs)
				{
					operationInputs.Add(new SerializedValue(input.Key, input.Value));
				}
				this.Inputs = operationInputs;
			}

			//The result has to be serialized at this point. If it isn't, then any changes to the object
			//after it is reported will also effect the object that is stored in result.
			if (null == result)
			{
				this.Result = null;
			}
			else
			{
				this.Result = new SerializedValue(result);
			}
		}

		/// <summary>
		/// Instantiates an instance of the OrganizationServiceReplayEvent class
		/// </summary>
		/// <param name="operationName">Operation that was executed</param>
		/// <param name="elapsedTime">Time that elapsed during the execution of the event</param>
		/// <param name="inputs">Inputs that were provided to the operation</param>
		/// <param name="fault">Fault that occurred</param>
		internal OrganizationServiceReplayEvent(string operationName, TimeSpan elapsedTime, IDictionary<string, object> inputs, OrganizationServiceFault fault)
			: this(operationName, elapsedTime, inputs, (object)fault)
		{
			if (null == fault)
			{
				throw new ArgumentNullException("fault");
			}

			this.IsFault = true;
		}

		/// <summary>
		/// Operation that was executed
		/// </summary>
		[DataMember]
		public string OperationName { get; private set; }

		/// <summary>
		/// Fault that occurred during the call
		/// </summary>
		[DataMember]
		public bool IsFault { get; private set; }

		/// <summary>
		/// Assembly qualified name for the serialization result
		/// </summary>
		[DataMember]
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
		public string SerializedResultAssemblyQualifiedName { get; private set; }

		/// <summary>
		/// Inputs to the operation
		/// </summary>
		[DataMember]
		public Collection<SerializedValue> Inputs { get; private set; }

		/// <summary>
		/// Result of the call (if successful) or a fault (if a failure)
		/// </summary>
		[DataMember]
		public SerializedValue Result { get; private set; }
	}
	#endregion

	#region Supporting Classes
	/// <summary>
	/// Generic wrapper for unknown types that need to be serializable
	/// </summary>
	[DataContract]
	public sealed class SerializedValue
	{
		#region Constructors
		/// <summary>
		/// Instantiate an instance of the Serialized Value class
		/// </summary>
		/// <param name="value">Serialized Value</param>
		internal SerializedValue(object value)
		{
			//If no value is specified, then nothing should be recorded.
			if (null == value)
			{
				return;
			}

			//If this is an entity, the fall-back type should be the root XRM entity class. This will be the case for cases where the
			//strongly-typed classes aren't loaded
			Type valueType = value.GetType();
			if (typeof(Entity).IsAssignableFrom(valueType))
			{
				this.SecondaryAssemblyQualifiedName = typeof(Entity).AssemblyQualifiedName;
			}

			//Serialize the value and store it
			this.AssemblyQualifiedName = valueType.AssemblyQualifiedName;
			this.Value = PartialTrustSerializer.Serialize(valueType, value);
		}

		/// <summary>
		/// Instantiate an instance of the Serialized Value class
		/// </summary>
		/// <param name="name">Name (or key) for the value</param>
		/// <param name="value">Serialized Value</param>
		internal SerializedValue(string name, object value)
			: this(value)
		{
			if (string.IsNullOrWhiteSpace(name))
			{
				throw new ArgumentNullException("name");
			}

			this.Name = name;
		}
		#endregion

		#region Properties
		/// <summary>
		/// Name for the serialized value
		/// </summary>
		[DataMember]
		public string Name { get; private set; }

		/// <summary>
		/// Assembly qualified name to be used if the given assembly qualified name is not found
		/// </summary>
		[DataMember]
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
		public string SecondaryAssemblyQualifiedName { get; private set; }

		/// <summary>
		/// Assembly qualified name for the serialized value
		/// </summary>
		[DataMember]
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
		public string AssemblyQualifiedName { get; private set; }

		/// <summary>
		/// Serialized Value
		/// </summary>
		[DataMember]
		[System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
		public string Value { get; private set; }
		#endregion

		#region Methods
		/// <summary>
		/// Deserializes the serialized result
		/// </summary>
		/// <param name="proxyTypesAssembly">Assembly for the proxy types</param>
		/// <returns>Deserialized result</returns>
		public object GetDeserializedValue(Assembly proxyTypesAssembly)
		{
			if (string.IsNullOrWhiteSpace(this.AssemblyQualifiedName) ||
				string.IsNullOrWhiteSpace(this.Value))
			{
				return null;
			}

			//Attempt to locate the type that was originally specified. If the secondary assembly information is null, it
			//means that there isn't a fallback plan. In that case, an exception should be thrown if the type can't be found. Otherwise,
			//attempt to load the secondary assembly.
			bool isSecondaryAssemblySet = string.IsNullOrWhiteSpace(this.SecondaryAssemblyQualifiedName);
			Type serializedType = Type.GetType(this.AssemblyQualifiedName, !isSecondaryAssemblySet);
			if (isSecondaryAssemblySet && null == serializedType)
			{
				serializedType = Type.GetType(this.AssemblyQualifiedName, true);
			}

			//Based on the specified type, deserialize the value
			return PartialTrustSerializer.Deserialize(serializedType, this.Value, proxyTypesAssembly);
		}
		#endregion
	}
	#endregion
}
