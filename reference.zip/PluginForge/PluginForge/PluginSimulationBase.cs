﻿using System;
using System.IO;
using System.Reflection;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Xrm.Sdk;
using ProjectOperationsDualWriteIntegrationTests;

namespace Microsoft.Dynamics.ProjectOperations.PluginForge
{
    public class PluginSimulationBase<TPlugin>
            where TPlugin : class, IPlugin
    {
        private ServiceCollection serviceCollection;

        public PluginSimulationBase()
        {
            IConnectionSettings connectionSettings = ReadSettingsFromJsonFile();
            DataverseService dataverseService = new DataverseService(connectionSettings);
            this.OrganizationService = dataverseService.GetOrganizationService();

            var response = OrganizationService.Execute(new OrganizationRequest("WhoAmI"));
            Console.WriteLine($"Connected to Dataverse. User ID: {response["UserId"]}");

            this.UserId = Guid.Parse(response["UserId"].ToString());
            this.serviceCollection = new ServiceCollection();
            this.serviceCollection.ConfigurePluginCommonAttributes(this.OrganizationService);
        }
        public Guid UserId { get; private set; }
        public LocalPluginExecutionContext LocalPluginExecutionContext { get; private set; }
        public IOrganizationService OrganizationService { get; }

        public void Execute()
        {
            this.serviceCollection.ConfigurePluginExecutionContext(this.LocalPluginExecutionContext);
            var serviceProvider = this.serviceCollection.BuildServiceProvider();

            TPlugin plugin = Initialize<TPlugin>("", "");

            plugin.Execute(serviceProvider);
        }

        public void SetExecutionContext(LocalPluginExecutionContext localPluginExecutionContext)
        {
            localPluginExecutionContext.UserId = this.UserId;
            this.LocalPluginExecutionContext = localPluginExecutionContext;
        }

        public static IConnectionSettings ReadSettingsFromJsonFile()
        {
            string binFolderPath = AppDomain.CurrentDomain.BaseDirectory;

            // Path to the JSON file in the bin folder
            string filePath = Path.Combine(binFolderPath, "settings.json");
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException($"The settings file was not found at path: {filePath}");
            }

            string jsonContent = File.ReadAllText(filePath);

            // Deserialize JSON content into the Settings object

            var result = Newtonsoft.Json.JsonConvert.DeserializeObject<SettingsFileConnectionSettings>(jsonContent);
            return result;
        }



        public T Initialize<T>(params object[] constructorArgs) where T : class
        {
            // Get the type of the generic type T
            Type type = typeof(T);

            // Get the constructor that matches the types of the provided arguments
            ConstructorInfo constructor = type.GetConstructor(BindingFlags.Public | BindingFlags.Instance, null, Array.ConvertAll(constructorArgs, arg => arg.GetType()), null);

            if (constructor == null)
            {
                throw new InvalidOperationException($"No matching constructor found for type '{type.FullName}' with the provided arguments.");
            }

            // Invoke the constructor and create an instance
            return (T)constructor.Invoke(constructorArgs);
        }
    }
}
