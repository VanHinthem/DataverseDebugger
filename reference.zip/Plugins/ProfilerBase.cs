﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.ServiceModel;

using Microsoft.Xrm.Sdk;

using PluginProfiler.Plugins.ServiceWrappers;

namespace PluginProfiler.Plugins
{
	/// <summary>
	/// Entry point for the server-side profiler component
	/// </summary>
	/// <typeparam name="T">Context wrapper data type</typeparam>
	public abstract class ProfilerBase<T>
		where T : ExecutionContextWrapper
	{
		/// <summary>
		/// Instantiates an instance of the PluginProfilerPlugin class.
		/// </summary>
		/// <param name="configuration">Configuration for the profiler</param>
		protected ProfilerBase(string configuration)
		{
			if (string.IsNullOrWhiteSpace(configuration))
			{
				throw new ArgumentNullException("configuration", "Configuration must be set for the Plug-in Profiler step.");
			}

			try
			{
				this.Configuration = ProfilerConfiguration.Deserialize(configuration);
			}
			catch (Exception ex)
			{
				throw new InvalidPluginExecutionException("Unable to deserialize the plug-in's configuration.", ex);
			}
		}

		#region Protected Properties
		/// <summary>
		/// Configuration for the Profiler
		/// </summary>
		protected ProfilerConfiguration Configuration { get; private set; }

		/// <summary>
		/// Initialization Context for the Profiler Activity or Plug-in
		/// </summary>
		internal PluginInitializationContext InitializationContext { get; private set; }
		#endregion

		#region Protected Methods
		/// <summary>
		/// Executes the profiler plug-in
		/// </summary>
		/// <param name="operationContext">Context for the plug-in</param>
		/// <param name="context">Context for the profiler</param>
		/// <param name="report">Report for the profiler</param>
		/// <param name="inputParameter">Input parameter for the execution</param>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes",
			Justification = "Any exception that occurs as part of plug-in execution should be logged to the report.")]
		internal object Execute(T operationContext, ProfilerPluginContext context, ProfilerPluginReport report, object inputParameter)
		{
			if (null == this.Configuration)
			{
				throw new InvalidPluginExecutionException("Configuration was not set or parsed in the Plug-in Profiler step.");
			}
			else if (null == operationContext)
			{
				throw new ArgumentNullException("operationContext");
			}
			else if (null == context)
			{
				throw new ArgumentNullException("context");
			}
			else if (null == report)
			{
				throw new ArgumentNullException("report");
			}

			object result = null;
			if (null != context)
			{
				#region Execute Operation
				if (null != this.InitializationContext && this.InitializationContext.Instantiate(report))
				{
					Stopwatch watch = new Stopwatch();

					//Execute the plug-in while instrumenting the execution
					DateTime executionStartTime = DateTime.UtcNow;
					Exception executionException = null;
					try
					{
						this.ExecuteInternal(watch, context, report, inputParameter, ref result);
					}
					catch (Exception ex)
					{
						watch.Stop();

						// Store the exception so that it can be reported in the results
						executionException = ex;
					}

					//Set the performance values for the execution
					report.SetExecutionResult(executionStartTime, watch.ElapsedMilliseconds, executionException);
				}
				#endregion
			}

			#region Report Results
			if (this.Configuration.IsProfilePersistedToEntity.GetValueOrDefault())
			{
				IOrganizationServiceFactory factory = context.ServiceProvider.GetService<IOrganizationServiceFactory>();
				IOrganizationService service = factory.CreateOrganizationService(null);

				try
				{
					service.Create(PopulateProfileEntity(operationContext, report));
				}
				catch (FaultException<OrganizationServiceFault> ex)
				{
					ITracingService tracing = context.ServiceProvider.GetService<ITracingService>();
					tracing.Trace("Unexpected Exception occurred in Profiler while persisting the profile:");
					tracing.Trace(ProfilerSharedUtility.ConvertExceptionToString(ex));

					throw new InvalidPluginExecutionException(ProfilerSharedUtility.DefaultExceptionStatus, "Unable to persist the profile.");
				}

				return result;
			}
			else
			{
				throw new InvalidPluginExecutionException(ProfilerSharedUtility.DefaultExceptionStatus, string.Format(CultureInfo.InvariantCulture,
					ProfilerSharedUtility.ProfilerErrorMessageFormat, ProfilerSharedUtility.Compress(report.ToString())));
			}
			#endregion
		}

		/// <summary>
		/// Execute the operation
		/// </summary>
		/// <param name="watch">Watch that should record the time for the operation</param>
		/// <param name="context">Context for the profiler</param>
		/// <param name="report">Report for the profiling session</param>
		/// <param name="inputParameter">Input parameter that should be passed to the internal execution</param>
		/// <param name="result">Result that will be returned to the caller when the result is persisted to an entity.</param>
		/// <remarks>
		/// Exceptions that should be reported to the user should not be caught by this method as they are handled generically for all
		/// operations.
		/// </remarks>
		internal abstract void ExecuteInternal(Stopwatch watch, ProfilerPluginContext context, ProfilerPluginReport report,
			object inputParameter, ref object result);

		/// <summary>
		/// Initializes the Profiler
		/// </summary>
		/// <param name="services">Services that are available</param>
		/// <param name="operationContext">Context that is available</param>
		/// <param name="context">Profiler context that will be output</param>
		/// <returns>Report for the profiling session</returns>
		internal ProfilerPluginReport InitializeProfiler(Dictionary<Type, object> services, T operationContext,
			out ProfilerPluginContext context)
		{
			IOrganizationServiceFactory factory;
			ITracingService tracing;

			#region Extract Required Services
			{
				// Extract the services 
				object service;
				if (!services.TryGetValue(typeof(IOrganizationServiceFactory), out service))
				{
					throw new ArgumentException("IOrganizationServiceFactory must be available.", "services");
				}

				factory = (IOrganizationServiceFactory)service;

				if (!services.TryGetValue(typeof(ITracingService), out service))
				{
					throw new ArgumentException("ITracingService must be available.", "services");
				}

				tracing = (ITracingService)service;
			}
			#endregion

			try
			{
				ProfilerPluginReport report;
				if (this.Configuration.IsContextReplay.GetValueOrDefault())
				{
					report = new ProfilerPluginReport(operationContext, this.Configuration.WorkflowStepId);
					context = new ProfilerPluginContext(this.Configuration, new ProxyTypesWrapper(this.GetType().Assembly), report,
						operationContext, services);
				}
				else
				{
					// Refresh the context (in case the assembly has changed)
					this.InitializationContext = PluginLoaderUtility.RefreshPluginInitializationContext(
						factory, this.Configuration, this.InitializationContext);

					// Initialize the plug-in report with the given values
					report = new ProfilerPluginReport(this.Configuration.TypeName, operationContext,
						this.Configuration.WorkflowStepId, this.InitializationContext.Configuration,
						this.Configuration.IncludeSecureInformation.GetValueOrDefault() ? this.InitializationContext.SecureConfiguration : null);

					// Initialize the constructors for the class
					this.InitializationContext.InitializePluginConstructors(this.Configuration);
					context = new ProfilerPluginContext(this.Configuration, this.InitializationContext.ProxyWrapper, report, operationContext,
						services);
				}

				if (services.ContainsKey(typeof(IServiceEndpointNotificationService)))
				{
					report.HasServiceEndpointNotificationService = true;
				}

				return report;
			}
			catch (NotSupportedException ex)
			{
				tracing.Trace("Unsupported configuration was detected during the initialization of the Plug-in Profiler.");
				tracing.Trace(ProfilerSharedUtility.ConvertExceptionToString(ex));

				throw new InvalidPluginExecutionException(ProfilerSharedUtility.DefaultExceptionStatus,
					"Unsupported Configuration Detected: " + ex.Message);
			}
			catch (Exception ex)
			{
				tracing.Trace("An exception occurred during the initialization of the Plug-in Profiler.");
				tracing.Trace(ProfilerSharedUtility.ConvertExceptionToString(ex));

				throw new InvalidPluginExecutionException(ProfilerSharedUtility.DefaultExceptionStatus,
					"Unexpected Exception in the Plug-in Profiler");
			}
		}
		#endregion

		#region Private Methods
		private Entity PopulateProfileEntity(T context, ProfilerPluginReport report)
		{
			Entity profileEntity = new Entity("mbs_pluginprofile");
			profileEntity["mbs_configuration"] = report.Configuration;
			profileEntity["mbs_correlationid"] = context.CorrelationId.ToString();
			profileEntity["mbs_depth"] = context.Depth;
			profileEntity["mbs_initiatinguserid"] = new EntityReference("systemuser", context.InitiatingUserId);
			profileEntity["mbs_label"] = string.Format(CultureInfo.InvariantCulture,
				"{0} of {1} at {2:s}", context.MessageName, context.PrimaryEntityName, DateTime.UtcNow);
			profileEntity["mbs_messagename"] = context.MessageName;
			profileEntity["mbs_mode"] = new OptionSetValue(context.Mode + ProfilerSharedUtility.BaseOptionSetValue);
			profileEntity["mbs_performanceconstructorduration"] = (int)report.ConstructorDurationInMilliseconds;
			profileEntity["mbs_performanceconstructorstarttime"] = report.ConstructorStartTime;
			profileEntity["mbs_performanceexecutionduration"] = (int)report.ExecutionDurationInMilliseconds;
			profileEntity["mbs_performanceexecutionstarttime"] = report.ExecutionStartTime;
			profileEntity["mbs_persistencekey"] = this.Configuration.PersistenceSessionKey;
			profileEntity["mbs_primaryentity"] = context.PrimaryEntityName;
			profileEntity["mbs_requestid"] = context.RequestId.ToString();
			profileEntity["mbs_secureconfiguration"] = report.SecureConfiguration;
			profileEntity["mbs_operationtype"] = new OptionSetValue((int)report.OperationType);
			profileEntity["mbs_profile"] = ProfilerSharedUtility.Compress(report.ToString());
			if (!string.IsNullOrWhiteSpace(report.WorkflowStepId) && report.WorkflowStepId.Length > 100)
			{
				profileEntity["mbs_workflowstepid"] = report.WorkflowStepId.Substring(0, 97) + "...";
			}

			return profileEntity;
		}
		#endregion
	}
}
