﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Net;
using System.ServiceModel.Description;
using System.Text;

using PluginProfiler.Library;
using PluginProfiler.Library.Reporting;

using Microsoft.Crm.Services.Utility;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;

namespace PluginProfiler.Debugger
{
	/// <summary>
	/// Core debugger class that consumes the ProfilerLibrary
	/// </summary>
	internal sealed class PluginDebugger
	{
		internal const string SdkMessageProcessingStepEntityName = "sdkmessageprocessingstep";
		internal const string WorkflowEntityName = "workflow";

		/// <summary>
		/// Instantiates an instance of the PluginDebugger class
		/// </summary>
		/// <param name="parameters">Parameters that were parsed in the command-line</param>
		public PluginDebugger(PluginDebuggerParameters parameters)
		{
			if (null == parameters)
			{
				throw new ArgumentNullException("parameters");
			}

			this.Parameters = parameters;
		}

		#region Properties
		private PluginDebuggerParameters Parameters { get; set; }
		#endregion

		#region Methods
		/// <summary>
		/// Executes the requested operation
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes",
			Justification = "Exception is caught and logged to the command-line.")]
		public void Execute()
		{
			try
			{
				switch (this.Parameters.DebuggerOperation)
				{
					case DebuggerOperation.Install:
						this.Install();
						break;
					case DebuggerOperation.Debug:
						this.Debug();
						break;
					case DebuggerOperation.Replay:
						this.Replay();
						break;
					case DebuggerOperation.Enable:
						this.Enable();
						break;
					case DebuggerOperation.Disable:
						this.Disable();
						break;
					case DebuggerOperation.Uninstall:
						this.Uninstall();
						break;
					case DebuggerOperation.ListSteps:
						this.ListSteps();
						break;
					default:
						throw new NotImplementedException("DebuggerOperation = " + this.Parameters.DebuggerOperation);
				}

				Console.WriteLine("Execution Completed Successfully.");
			}
			catch (Exception ex)
			{
				WriteError("An unexpected error occurred in the debugger:{0}{1}", Environment.NewLine,
					ProfilerSharedUtility.ConvertExceptionToString(ex));
			}
		}
		#endregion

		#region Operation Methods
		private void Install()
		{
			using (OrganizationServiceProxy proxy = this.CreateProxy(false))
			{
				ProfilerManagementUtility.InstallProfiler(proxy);
			}

			Console.Out.WriteLine("Profiler was installed on the system (URI: {0}).", this.Parameters.Url);
		}

		private void Debug()
		{
			ProfilerExecutionUtility.Execute(this.Parameters.Permissions,
				this.Parameters.OperationHandler.GetOperationConfiguration(),
				new ProfilerReportingConfiguration(new ProfilerConsoleTracingService()),
				this.CreateProxy(false), new ProfilerConsoleTracingService());
		}

		private void Replay()
		{
			ProfilerExecutionUtility.Replay(this.Parameters.Permissions,
				this.Parameters.OperationHandler.GetOperationConfiguration(),
				new ProfilerReportingConfiguration(new ProfilerConsoleTracingService()),
				new ProfilerConsoleTracingService());
		}

		private void Enable()
		{
			using (OrganizationServiceProxy proxy = this.CreateProxy(false))
			{
				// Update the id based on the name
				this.UpdateEnableDisableId(proxy, this.Parameters.OperationHandler);

				// Enable the profiler
				this.Parameters.OperationHandler.Enable(proxy);
			}

			Console.Out.WriteLine("Profiling was enabled for {0}.", this.Parameters.OperationHandler.Id.Id);
		}

		private void Disable()
		{
			using (OrganizationServiceProxy proxy = this.CreateProxy(false))
			{
				// Update the id based on the name
				this.UpdateEnableDisableId(proxy, this.Parameters.OperationHandler);

				// Disable the profiler
				this.Parameters.OperationHandler.Disable(proxy);
			}

			Console.Out.WriteLine("Profiling was disabled for {0}.", this.Parameters.OperationHandler.Id.Id);
		}

		private void Uninstall()
		{
			using (OrganizationServiceProxy proxy = this.CreateProxy(false))
			{
				ProfilerManagementUtility.UninstallProfiler(proxy);
			}

			Console.Out.WriteLine("Profiler was uninstalled from the system (URI: {0}).", this.Parameters.Url);
		}

		private void ListSteps()
		{
			using (OrganizationServiceProxy proxy = this.CreateProxy(false))
			{
				// Update the id based on the name
				this.UpdateEnableDisableId(proxy, this.Parameters.OperationHandler);

				// Retrieve the list of steps from the handler
				Console.Out.WriteLine();
				Console.Out.WriteLine(this.Parameters.OperationHandler.ListSteps(proxy));
				Console.Out.WriteLine();
			}
		}
		#endregion

		#region Private Methods
		private void UpdateEnableDisableId(OrganizationServiceProxy proxy, OperationHandlerBase handler)
		{
			// If it has already been found, return it
			if (null != handler.Id)
			{
				return;
			}

			// Retrieve all records that have the given name
			QueryBase query = handler.GenerateNameQuery(this.Parameters.DebuggerOperation);
			EntityCollection results = proxy.RetrieveMultiple(query);

			// There should be one, and only one, step matching the name (unless the caller has specified that all steps should be used).
			// If that is not the case, the name provided is not unique and cannot be used.
			if (1 == results.Entities.Count)
			{
				handler.Id = results[0].ToEntityReference();

				Console.Out.WriteLine("Found Id \"{0}\" for the given name: \"{1}\"", handler.Id.Id, handler.Name);
				return;
			}
			else if (0 == results.Entities.Count)
			{
				throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
					"Name \"{0}\" does not match any valid {1} in the system.", handler.Name, handler.PluralRecordName));
			}

			// An error has occurred. The exception will include all of the steps that matched the given name.
			StringBuilder resultError = new StringBuilder();
			resultError.AppendFormat(CultureInfo.InvariantCulture, "Multiple {0} matched the name \"{1}\":{2}",
				handler.PluralRecordName, handler.Name, Environment.NewLine);

			foreach (Entity step in results.Entities)
			{
				resultError.AppendFormat(CultureInfo.InvariantCulture, "- {0}", step.Id);
			}

			throw new InvalidOperationException(resultError.ToString());
		}

		[SuppressMessage("Microsoft.Usage", "CA9888:DisposeObjectsCorrectly", MessageId = "proxy",
			Justification = "Object is disposed by the caller. In the case of an exception, it is disposed in a try/catch.")]
		private OrganizationServiceProxy CreateProxy(bool enableProxyTypes)
		{
			IServiceConfiguration<IOrganizationService> config =
				ServiceConfigurationFactory.CreateConfiguration<IOrganizationService>(new Uri(this.Parameters.Url));

			OrganizationServiceProxy proxy;
			ClientCredentials userCredentials = CreateUserCredentials();
			SecurityTokenResponse deviceToken = null;
			switch (config.AuthenticationType)
			{
				case AuthenticationProviderType.LiveId:
					deviceToken = config.AuthenticateDevice(DeviceIdManager.LoadOrRegisterDevice(config.CurrentIssuer.IssuerAddress.Uri));
					goto case AuthenticationProviderType.Federation;
				case AuthenticationProviderType.Federation:
					proxy = new OrganizationServiceProxy(config,
						config.Authenticate(userCredentials, deviceToken));
					break;
				case AuthenticationProviderType.ActiveDirectory:
					proxy = new OrganizationServiceProxy(config, userCredentials);
					break;
				default:
					throw new NotImplementedException("AuthenticationProviderType: " + config.AuthenticationType);
			}

			try
			{
				if (enableProxyTypes)
				{
					proxy.EnableProxyTypes(this.GetType().Assembly);
				}
			}
			catch (Exception)
			{
				proxy.Dispose();
				throw;
			}

			return proxy;
		}

		private ClientCredentials CreateUserCredentials()
		{
			ClientCredentials userCredentials = new ClientCredentials();
			if (string.IsNullOrWhiteSpace(this.Parameters.Domain))
			{
				if (string.IsNullOrWhiteSpace(this.Parameters.UserName))
				{
					return new ClientCredentials();
				}
				else
				{
					userCredentials.UserName.UserName = this.Parameters.UserName;
					userCredentials.UserName.Password = this.Parameters.Password;
				}
			}
			else
			{
				userCredentials.Windows.ClientCredential =
					new NetworkCredential(this.Parameters.UserName, this.Parameters.Password, this.Parameters.Domain);
			}

			return userCredentials;
		}

		private void WriteError(string format, params object[] args)
		{
			ConsoleColor currentColor = Console.ForegroundColor;
			try
			{
				if (null == args || 0 == args.Length)
				{
					Console.Error.WriteLine(format);
				}
				else
				{
					Console.Error.WriteLine(format, args);
				}
			}
			finally
			{
				Console.ForegroundColor = currentColor;
			}
		}
		#endregion
	}
}
