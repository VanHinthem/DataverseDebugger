# Reference Projects — Usage Rules (Read-Only)

The projects included in the reference ZIP are provided **for conceptual inspiration only**.

They exist to help understand *intent*, *patterns*, and *responsibilities*, not to be reused
or depended upon directly.

---

## Strict Prohibitions (Non-Negotiable)

The AI **must NOT**:

- Add project references to any reference project
- Copy class names, namespaces, or file structures verbatim
- Copy method signatures line-by-line
- Import or reuse code directly
- Recreate reference project architectures inside the Runner
- Assume reference behavior overrides Runner documentation

Violating any of the above is considered a failure of the task.

---

## Allowed Usage

The AI **may**:

- Study the reference projects to understand patterns and responsibilities
- Use them to clarify *why* certain logic exists
- Re-express ideas in **runner-owned abstractions**
- Adapt concepts to the existing `DataverseDebugger.Runner` architecture

All resulting code must be:
- original
- runner-owned
- consistent with the PR documents and v2 architecture

---

## Priority rule
If there is any conflict between:
- reference projects
- your own assumptions
- any document not listed above

👉 **The Runner documents always win.**
If a conflict, ambiguity, or decision cannot be resolved *unambiguously* using the Runner documents:
- **Stop**
- **Do not guess**
- **Ask the repository owner for clarification before proceeding**

---

_End of document_
