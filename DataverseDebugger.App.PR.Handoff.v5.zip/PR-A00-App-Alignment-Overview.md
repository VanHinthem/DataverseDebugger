# PR-A00 – DataverseDebugger.App Alignment Overview

## Purpose
Align DataverseDebugger.App with the finalized Runner architecture (PR01–PR06). The App must remain a thin host while the Runner owns execution semantics.

## Invariants (Non-Negotiable)
- Preserve existing behavior unless explicitly changed by an App PR in this series.
- The App must not implement execution semantics (Offline/Hybrid/Online logic must be delegated to the Runner).
- Live writes must remain opt-in and guarded.
- Runner binaries must be present deterministically in App output.

## Default Settings (Pinned)
- `ExecutionMode = Hybrid`
- `AllowLiveWrites = false`
Rationale: safe default; aligns with the App’s current “no live writes by default” posture.

## App Code Topology (Current)
Key files involved in this series (App-side only):
- `Models/RunnerSettingsModel.cs`
- `Views/SettingsView.xaml`
- `MainWindow.xaml.cs`
- `RunnerProcessManager.cs`
- `DataverseDebugger.App.csproj`

## ExecutionMode vs WriteMode (Compatibility Contract)
ExecutionMode is the primary selection:
- `Offline`, `Hybrid`, `Online`

WriteMode is legacy compatibility and must be derived:
- If `ExecutionMode == Online` AND `AllowLiveWrites == true` => `WriteMode = LiveWrites`
- Else => `WriteMode = FakeWrites`

## Settings Migration (From Existing App Settings)
- If existing settings indicate `WriteMode == LiveWrites`:
  - Set `ExecutionMode = Online`
  - Set `AllowLiveWrites = true`
- Else:
  - Set `ExecutionMode = Hybrid`
  - Set `AllowLiveWrites = false`

## Passing Mode/Gate to Runner (Confirmed Contract)
The Runner receives configuration via two channels:

### A) Process-start configuration (environment variables)
Confirmed from Runner source:
- `DATAVERSE_DEBUGGER_HOST_PID`
- `DATAVERSE_DEBUGGER_ALLOW_LIVE_WRITES`

### B) Per-request execution mode (protocol fields)
ExecutionMode is resolved in Runner from request payload (e.g., `PluginInvokeRequest.ExecutionMode`),
with legacy fallback to `WriteMode`.

## Definition of Done
- App UI exposes ExecutionMode and (guarded) AllowLiveWrites.
- App sets `DATAVERSE_DEBUGGER_ALLOW_LIVE_WRITES` at Runner process start.
- App ensures requests carry ExecutionMode explicitly (and still sets legacy WriteMode).
- Runner is copied to App output on Build (not only Publish).
- App contains no execution semantics beyond UX gating and passing configuration to Runner.
