# PR-A01 – ExecutionMode-First App Model

## Objective
Replace WriteMode-centric UI with ExecutionMode-first semantics.

## Invariants
- Preserve behavior.
- No Runner changes.

## Scope
- Introduce ExecutionMode.
- Derive WriteMode.

## Illegal Changes
- Adding new modes
- Changing execution behavior
