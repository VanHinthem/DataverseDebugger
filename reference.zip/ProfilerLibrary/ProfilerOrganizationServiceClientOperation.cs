﻿using System;
using System.Diagnostics.CodeAnalysis;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Runtime.Serialization;

namespace PluginProfiler.Library.Reporting
{
	[DataContract]
	public abstract class ProfilerOrganizationServiceClientOperationBase : ProfilerClientOperationBase
	{
		protected internal ProfilerOrganizationServiceClientOperationBase(ProfilerOrganizationServiceClientOperation operation,
			OrganizationServiceFault fault)
			: base(ProfilerOperationType.OrganizationService)
		{
			this.Operation = operation;
			this.Fault = fault;
		}

		#region Properties
		[DataMember]
		public ProfilerOrganizationServiceClientOperation Operation { get; private set; }

		[DataMember]
		public OrganizationServiceFault Fault { get; internal set; }
		#endregion
	}

	#region Enum
	[DataContract]
	public enum ProfilerOrganizationServiceClientOperation
	{
		[EnumMember]
		Associate,

		[EnumMember]
		Disassociate,

		[EnumMember]
		Create,

		[EnumMember]
		Retrieve,

		[EnumMember]
		RetrieveMultiple,

		[EnumMember]
		Update,

		[EnumMember]
		Delete,

		[EnumMember]
		Execute
	}
	#endregion

	#region Operation Classes
	[DataContract]
	public sealed class ProfilerAssociateClientOperation : ProfilerOrganizationServiceClientOperationBase
	{
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		internal ProfilerAssociateClientOperation(OrganizationServiceFault fault, string inputEntityName, Guid inputEntityId,
			Relationship inputRelationship, EntityReferenceCollection inputRelatedEntities)
			: base(ProfilerOrganizationServiceClientOperation.Associate, fault)
		{
			this.InputEntityName = inputEntityName;
			this.InputEntityId = inputEntityId;
			this.InputRelationship = inputRelationship;
			this.InputRelatedEntities = inputRelatedEntities;
		}

		#region Properties
		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public string InputEntityName { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public Guid InputEntityId { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public Relationship InputRelationship { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public EntityReferenceCollection InputRelatedEntities { get; private set; }
		#endregion
	}

	[DataContract]
	public sealed class ProfilerDisassociateClientOperation : ProfilerOrganizationServiceClientOperationBase
	{
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		internal ProfilerDisassociateClientOperation(OrganizationServiceFault fault, string inputEntityName, Guid inputEntityId,
			Relationship inputRelationship, EntityReferenceCollection inputRelatedEntities)
			: base(ProfilerOrganizationServiceClientOperation.Disassociate, fault)
		{
			this.InputEntityName = inputEntityName;
			this.InputEntityId = inputEntityId;
			this.InputRelationship = inputRelationship;
			this.InputRelatedEntities = inputRelatedEntities;
		}

		#region Properties
		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public string InputEntityName { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public Guid InputEntityId { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public Relationship InputRelationship { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public EntityReferenceCollection InputRelatedEntities { get; private set; }
		#endregion
	}

	[DataContract]
	public sealed class ProfilerCreateClientOperation : ProfilerOrganizationServiceClientOperationBase
	{
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		internal ProfilerCreateClientOperation(OrganizationServiceFault fault, Entity inputEntity, Guid output)
			: base(ProfilerOrganizationServiceClientOperation.Create, fault)
		{
			this.InputEntity = inputEntity;
			this.Output = output;
		}

		#region Properties
		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public Entity InputEntity { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public Guid Output { get; internal set; }
		#endregion
	}

	[DataContract]
	public sealed class ProfilerRetrieveClientOperation : ProfilerOrganizationServiceClientOperationBase
	{
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		internal ProfilerRetrieveClientOperation(OrganizationServiceFault fault, string inputEntityName, Guid inputId,
			ColumnSet inputColumnSet, Entity output)
			: base(ProfilerOrganizationServiceClientOperation.Retrieve, fault)
		{
			this.InputEntityName = inputEntityName;
			this.InputId = inputId;
			this.InputColumnSet = inputColumnSet;
			this.Output = output;
		}

		#region Properties
		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public string InputEntityName { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public Guid InputId { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public ColumnSet InputColumnSet { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public Entity Output { get; internal set; }
		#endregion
	}

	[DataContract]
	public sealed class ProfilerRetrieveMultipleClientOperation : ProfilerOrganizationServiceClientOperationBase
	{
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		internal ProfilerRetrieveMultipleClientOperation(OrganizationServiceFault fault, QueryBase inputQuery, EntityCollection output)
			: base(ProfilerOrganizationServiceClientOperation.RetrieveMultiple, fault)
		{
			this.InputQuery = inputQuery;
			this.Output = output;
		}

		#region Properties
		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public QueryBase InputQuery { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public EntityCollection Output { get; internal set; }
		#endregion
	}

	[DataContract]
	public sealed class ProfilerUpdateClientOperation : ProfilerOrganizationServiceClientOperationBase
	{
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		internal ProfilerUpdateClientOperation(OrganizationServiceFault fault, Entity inputEntity)
			: base(ProfilerOrganizationServiceClientOperation.Update, fault)
		{
			this.InputEntity = inputEntity;
		}

		#region Properties
		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public Entity InputEntity { get; private set; }
		#endregion
	}

	[DataContract]
	public sealed class ProfilerDeleteClientOperation : ProfilerOrganizationServiceClientOperationBase
	{
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		internal ProfilerDeleteClientOperation(OrganizationServiceFault fault, string inputEntityName, Guid inputId)
			: base(ProfilerOrganizationServiceClientOperation.Delete, fault)
		{
			this.InputEntityName = inputEntityName;
			this.InputId = inputId;
		}

		#region Properties
		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public string InputEntityName { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public Guid InputId { get; private set; }
		#endregion
	}

	[DataContract]
	public sealed class ProfilerExecuteClientOperation : ProfilerOrganizationServiceClientOperationBase
	{
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		internal ProfilerExecuteClientOperation(OrganizationServiceFault fault, OrganizationRequest inputRequest, OrganizationResponse output)
			: base(ProfilerOrganizationServiceClientOperation.Execute, fault)
		{
			this.InputRequest = inputRequest;
			this.Output = output;
		}

		#region Properties
		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public OrganizationRequest InputRequest { get; private set; }

		[DataMember]
		[SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",
			Justification = "Called via Reflection by the IOrganizationService implementations.")]
		public OrganizationResponse Output { get; internal set; }
		#endregion
	}
	#endregion
}