﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Reflection;
using System.Security;
using System.Security.Permissions;
using System.ServiceModel;

using Microsoft.Xrm.Sdk;

using PluginProfiler.Library.Reporting;
using PluginProfiler.Plugins;
using PluginProfiler.Plugins.ServiceWrappers;

namespace PluginProfiler.Library
{
	/// <summary>
	/// Proxy to the partial trust that is used to replay or debug the operation
	/// </summary>
	internal abstract class AppDomainProxy : MarshalByRefObject
	{
		private readonly Dictionary<string, string> TrustedAssemblies;
		private object _operationInstance;

		/// <summary>
		/// Instantiate an instance of the PluginAppDomainProxy
		/// </summary>
		/// <param name="trustedAssemblies">List of assemblies that are trusted</param>
		protected AppDomainProxy(Dictionary<string, string> trustedAssemblies)
		{
			this.TrustedAssemblies = trustedAssemblies;
		}

		#region Event Handlers
		private Assembly AppDomainAssemblyResolveHandler(object sender, ResolveEventArgs args)
		{
			if (!string.IsNullOrWhiteSpace(args.Name))
			{
				AssemblyName name = new AssemblyName(args.Name);

				// This method will verify that this assembly actually should be trusted.
				return LoadTrustedAssembly(name);
			}

			return null;
		}
		#endregion

		#region Methods
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes",
			Justification = "Exception is returned to the user without failing the operation.")]
		[SuppressMessage("Microsoft.Security", "CA2106:SecureAsserts",
			Justification = "Code is executed by the user on their box in full-trust.")]
		public void Execute(ProfilerExecutionConfiguration configuration, ProfilerExecutionReport report)
		{
			if (null == configuration)
			{
				throw new ArgumentNullException("configuration");
			}
			else if (null == report)
			{
				throw new ArgumentNullException("report");
			}

			if (configuration.ReportingConfiguration.IncludeProxyTypes)
			{
				report.ProxyTypesAssembly = this.ProxyTypesAssembly;
			}

			PermissionSet permissions = new PermissionSet(PermissionState.Unrestricted);
			permissions.Assert();

			IExecutionContext context;
			object executionParameter;
			try
			{
				//Serialize the plug-in report again in order to ensure that there are no proxy types in it
				report.SetSerializedProfilerReport(this.SerializedPluginReport);

				//Deserialize the Plug-in Context
				context = ExecutionContextWrapper.Deserialize(this.Type, this.PluginReport.Context);
				report.SetSerializedContext(this.Type, this.PluginReport.Context);

				// Prepare the execution
				executionParameter = this.PrepareExecution(configuration, context, report);
			}
			finally
			{
				CodeAccessPermission.RevertAssert();
			}

			configuration.ProfilerTracingService.Trace("Parsed Profiler File Successfully.");

			Stopwatch watch = new Stopwatch();
			try
			{
				//Execute the constructor
				this.InstantiateInstance(configuration);

				configuration.ProfilerTracingService.Trace("Profiler Execution Started: {0}", DateTime.Now);

				this.ExecuteCore(watch, report, this._operationInstance, executionParameter);

				//Output the Results
				configuration.ProfilerTracingService.Trace("Profiler Execution Completed Successfully (Duration = {0}ms).",
					watch.ElapsedMilliseconds);
			}
			catch (FaultException<OrganizationServiceFault> ex)
			{
				watch.Stop();

				report.Fault = ex.Detail;
				configuration.ProfilerTracingService.Trace("Profiler Execution Completed with a Fault (Duration = {0}ms).",
					watch.ElapsedMilliseconds);
			}
			catch (Exception ex)
			{
				watch.Stop();

				configuration.ProfilerTracingService.Trace("Profiler Execution Completed with an Unexcepted Exception Type (Duration = {0}ms): {1}.",
					watch.ElapsedMilliseconds, ex.GetType());
				report.Fault = ProfilerUtility.ConvertToFault(ex);
			}
		}

		/// <summary>
		/// Creates a proxy an AppDomain that serves as a shim for a operation
		/// </summary>
		/// <param name="type">Type of proxy to be instantiated</param>
		/// <param name="domain">Domain that should contain the operation</param>
		/// <param name="configuration">Configuration for the operation</param>
		/// <param name="trustedAssemblies">Assemblies that should be loaded in full-trust</param>
		/// <exception cref="System.InvalidOperationException">Occurs when a proxy has already been configured for the given AppDomain</exception>
		/// <remarks>
		/// Only a single proxy should be configured per AppDomain. If this is not the case, the proxy behavior is undefined.
		/// </remarks>
		public static AppDomainProxy CreateProxy(Type type, AppDomain domain, OperationConfiguration configuration,
			IList<Assembly> trustedAssemblies)
		{
			if (null == configuration)
			{
				throw new ArgumentNullException("configuration");
			}

			// Create a map of the trusted assembly full names and the location for the assembly so that
			// they can be loaded if requested by the plug-in.
			Dictionary<string, string> assemblyPathMapping = new Dictionary<string, string>();
			foreach (Assembly assembly in trustedAssemblies)
			{
				assemblyPathMapping[assembly.FullName] = assembly.Location;
			}

			// Instantiate the proxy in the Domain
			AppDomainProxy proxy = InstantiateInAppDomain(type, domain, assemblyPathMapping);

			// Initialize the proxy in the AppDomain
			proxy.InitializeProxy(configuration.AssemblyFilePath, configuration.TypeName, configuration.ProfilerLogPath);

			return proxy;
		}
		#endregion

		#region Protected Methods
		/// <summary>
		/// Configures the proxy with the given configuration
		/// </summary>
		/// <param name="configuration">Configuration that should be used</param>
		protected virtual void ConfigureProxy(ProfilerExecutionConfiguration configuration)
		{
		}

		/// <summary>
		/// Process the report to extract any required values from it
		/// </summary>
		/// <param name="report">Report that was generated</param>
		protected virtual void ProcessReport(ProfilerPluginReport report)
		{
		}

		/// <summary>
		/// Retrieve the configuration that is to be used to instantiate the operation
		/// </summary>
		/// <param name="configuration">Configuration to be used</param>
		/// <param name="parameters">Parameters that should be provided when constructing the object</param>
		/// <returns>Constructor info</returns>
		protected abstract ConstructorInfo FindConstructor(ProfilerExecutionConfiguration configuration, out object[] parameters);

		/// <summary>
		/// Prepare execution for the proxy
		/// </summary>
		/// <param name="configuration">Configuration to be used</param>
		/// <param name="context">Context for the oepration</param>
		/// <param name="report">Execution report for the given execution</param>
		/// <returns>Execution Parameter</returns>
		protected abstract object PrepareExecution(ProfilerExecutionConfiguration configuration, IExecutionContext context,
			ProfilerExecutionReport report);

		/// <param name="watch">Watch to be used while counting time</param>
		/// <param name="report">Execution report for the given execution</param>
		/// <param name="instance">Instance of the operation that should be used during execution</param>
		/// <param name="executionParameter">Parameter that should be used during execution</param>
		protected abstract void ExecuteCore(Stopwatch watch, ProfilerExecutionReport report, object instance, object executionParameter);
		#endregion

		#region Properties
		/// <summary>
		/// If Proxy Types have been enabled for this plug-in, the proxy types assembly will be represented by this property
		/// </summary>
		public Assembly ProxyTypesAssembly { get; protected set; }

		/// <summary>
		/// Type for the Plug-in
		/// </summary>
		public Type OperationInstanceType { get; protected set; }

		/// <summary>
		/// PluginReport for the plug-in
		/// </summary>
		public ProfilerPluginReport PluginReport { get; protected set; }

		/// <summary>
		/// Type of operation that was executed by the operation
		/// </summary>
		internal OperationType Type { get; set; }

		/// <summary>
		/// Contains the serialized plug-in report
		/// </summary>
		protected string SerializedPluginReport { get; set; }
		#endregion

		#region Private Methods
		private static AppDomainProxy InstantiateInAppDomain(Type type, AppDomain domain, Dictionary<string, string> trustedAssemblies)
		{
			if (null == domain)
			{
				throw new ArgumentNullException("domain");
			}

			return (AppDomainProxy)Activator.CreateInstanceFrom(domain, type.Assembly.Location,
				type.FullName, false, BindingFlags.NonPublic | BindingFlags.Instance, null,
				new object[] { trustedAssemblies }, CultureInfo.InvariantCulture, null).Unwrap();
		}

		[SuppressMessage("Microsoft.Security", "CA2106:SecureAsserts",
			Justification = "Code is executed by the user on their box in full-trust.")]
		private void InitializeProxy(string assemblyFilePath, string typeName, string logFilePath)
		{
			// Setup the event handlers
			AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(AppDomainAssemblyResolveHandler);

			PermissionSet permissions = new PermissionSet(PermissionState.Unrestricted);
			permissions.Assert();

			try
			{
				// Deserialize the Profiler Report in order to setup the environment.
				DeserializedProfilerReport deserializedReport = ProfilerUtility.DeserializeProfilerReport(assemblyFilePath, logFilePath);

				// Store the values from the report
				this.PluginReport = deserializedReport.Report;
				this.SerializedPluginReport = deserializedReport.SerializedReport;
				this.ProxyTypesAssembly = deserializedReport.ProxyTypesAssembly;
				this.Type = deserializedReport.Report.OperationType;

				//Find the type name that should be used for the plug-in
				if (string.IsNullOrWhiteSpace(typeName))
				{
					if (this.PluginReport.IsContextReplay)
					{
						throw new ArgumentNullException("typeName", "The name of the plug-in must be specified when using \"context replay\".");
					}
					else
					{
						typeName = this.PluginReport.TypeName;
						if (string.IsNullOrWhiteSpace(typeName))
						{
							throw new ArgumentException("TypeName has not been specified.", "typeName");
						}
					}
				}

				// Do any processing for the deserialized report
				this.ProcessReport(deserializedReport.Report);

				//Load the plug-in type
				Type pluginType = deserializedReport.PluginAssembly.GetType(typeName);
				if (null == pluginType)
				{
					throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
						"The plug-in type \"{0}\" does not exist in the specified assembly.", typeName));
				}

				this.OperationInstanceType = pluginType;
			}
			finally
			{
				CodeAccessPermission.RevertAssert();
			}
		}

		[SuppressMessage("Microsoft.Security", "CA2106:SecureAsserts",
			Justification = "Code is executed by the user on their box in full-trust.")]
		private void InstantiateInstance(ProfilerExecutionConfiguration configuration)
		{
			if (null != this._operationInstance)
			{
				return;
			}

			object[] args;
			ConstructorInfo constructor = this.FindConstructor(configuration, out args);
			if (null == constructor)
			{
				throw new InvalidOperationException("No valid constructor could be located.");
			}

			PermissionSet permissions = new PermissionSet(PermissionState.Unrestricted);
			permissions.Assert();

			Stopwatch watch = new Stopwatch();
			try
			{
				configuration.ProfilerTracingService.Trace("Constructor Execution Started: {0}", DateTime.Now);

				//Execute the constructor
				watch.Start();
				this._operationInstance = constructor.Invoke(args);
				watch.Stop();

				//Output the Results
				configuration.ProfilerTracingService.Trace("Constructor Execution Completed Successfully (Duration = {0}ms).",
					watch.ElapsedMilliseconds);
			}
			catch (Exception)
			{
				watch.Stop();
				configuration.ProfilerTracingService.Trace("Constructor Execution Failed due to an Exception (Duration = {0}ms).",
					watch.ElapsedMilliseconds);

				throw;
			}
			finally
			{
				CodeAccessPermission.RevertAssert();
			}
		}

		[SuppressMessage("Microsoft.Security", "CA2106:SecureAsserts",
			Justification = "Code is being called from the initialization and is initialized by the system.")]
		[SuppressMessage("Microsoft.Reliability", "CA2001:AvoidCallingProblematicMethods",
			Justification = "Required due to loading the assembly from a file during the Assembly Resolver.")]
		private Assembly LoadTrustedAssembly(AssemblyName name)
		{
			// This assumes that the full name (including the version). This is a valid assumption until the version is changed.
			// A similar issue exists in the Sandbox and is being tracked by Microsoft CRM #143955. That bug will also address 
			// this issue.
			string assemblyPath;
			if (!this.TrustedAssemblies.TryGetValue(name.FullName, out assemblyPath))
			{
				return null;
			}

			// Create the permissions that are required to load the assembly and assert them.
			PermissionSet permissions = new PermissionSet(PermissionState.None);
			permissions.AddPermission(new SecurityPermission(SecurityPermissionFlag.ControlEvidence));
			permissions.AddPermission(new FileIOPermission(PermissionState.Unrestricted));

			permissions.Assert();

			Assembly trustedAssembly;
			try
			{
				// The path to the assembly was specified when the AppDomain was setup.
				trustedAssembly = Assembly.LoadFrom(assemblyPath);
			}
			finally
			{
				CodeAccessPermission.RevertAssert();
			}

			return trustedAssembly;
		}
		#endregion
	}
}