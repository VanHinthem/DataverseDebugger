﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.ServiceModel;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace PluginProfiler.Plugins.ServiceWrappers
{
	/// <summary>
	/// Wrapper for the IOrganizationService provided by the IOrganizationServiceFactory during execution of a plug-in.
	/// </summary>
	internal sealed class OrganizationServiceWrapper : ServiceWrapperBase<IOrganizationService>, IOrganizationService
	{
		private readonly string ServiceLabel;

		/// <summary>
		/// Instantiates an instance of the OrganizationServiceWrapper
		/// </summary>
		/// <param name="service">Actual service provided by the original IServiceProvider instance.</param>
		/// <param name="context">Context for execution in the plug-in profiler.</param>
		/// <param name="userId">User ID for the IOrganizationService. This value is used during logging.</param>
		public OrganizationServiceWrapper(IOrganizationService service, ProfilerPluginContext context, Guid userId)
			: base(service, context)
		{
			string userName;
			if (Guid.Empty == userId)
			{
				userName = "SYSTEM";
			}
			else
			{
				userName = userId.ToString();
			}

			this.ServiceLabel = string.Format(CultureInfo.InvariantCulture, "SDK({0})", userName);
		}

		#region IOrganizationService Members
		public Guid Create(Entity entity)
		{
			const string OperationName = "Create";

			IDictionary<string, object> inputs = this.ConvertToInputs(
				new KeyValuePair<string, object>("entity", entity));

			Stopwatch watch = new Stopwatch();
			try
			{
				watch.Start();
				Guid id = this.InternalService.Create((Entity)this.Context.ProxyWrapper.ConvertToLateBound(entity));
				watch.Stop();

				this.AddSuccessReplayEvent(OperationName, watch, inputs, id);

				return id;
			}
			catch (Exception ex)
			{
				watch.Stop();

				this.AddExceptionReplayEvent(OperationName, watch, inputs, ex);
				throw;
			}
		}

		public Entity Retrieve(string entityName, Guid id, ColumnSet columnSet)
		{
			const string OperationName = "Retrieve";

			IDictionary<string, object> inputs = this.ConvertToInputs(
				new KeyValuePair<string, object>("entityName", entityName),
				new KeyValuePair<string, object>("id", id),
				new KeyValuePair<string, object>("ColumnSet", columnSet));

			Stopwatch watch = new Stopwatch();
			try
			{
				watch.Start();
				Entity entity = (Entity)this.Context.ProxyWrapper.ConvertToEarlyBound(
					this.InternalService.Retrieve(entityName, id, columnSet));
				watch.Stop();

				this.AddSuccessReplayEvent(OperationName, watch, inputs, entity);

				return entity;
			}
			catch (Exception ex)
			{
				watch.Stop();

				this.AddExceptionReplayEvent(OperationName, watch, inputs, ex);
				throw;
			}
		}

		public EntityCollection RetrieveMultiple(QueryBase query)
		{
			const string OperationName = "RetrieveMultiple";

			IDictionary<string, object> inputs = this.ConvertToInputs(
				new KeyValuePair<string, object>("query", query));

			Stopwatch watch = new Stopwatch();
			try
			{
				watch.Start();
				EntityCollection collection = (EntityCollection)this.Context.ProxyWrapper.ConvertToEarlyBound(
					this.InternalService.RetrieveMultiple(query));
				watch.Stop();

				this.AddSuccessReplayEvent(OperationName, watch, inputs, collection);

				return collection;
			}
			catch (Exception ex)
			{
				watch.Stop();

				this.AddExceptionReplayEvent(OperationName, watch, inputs, ex);
				throw;
			}
		}

		public void Update(Entity entity)
		{
			const string OperationName = "Update";

			IDictionary<string, object> inputs = this.ConvertToInputs(
				new KeyValuePair<string, object>("entity", entity));

			Stopwatch watch = new Stopwatch();
			try
			{
				watch.Start();
				this.InternalService.Update((Entity)this.Context.ProxyWrapper.ConvertToLateBound(entity));
				watch.Stop();

				this.AddSuccessReplayEvent(OperationName, watch, inputs);
			}
			catch (Exception ex)
			{
				watch.Stop();

				this.AddExceptionReplayEvent(OperationName, watch, inputs, ex);
				throw;
			}
		}

		public void Delete(string entityName, Guid id)
		{
			const string OperationName = "Delete";

			IDictionary<string, object> inputs = this.ConvertToInputs(
				new KeyValuePair<string, object>("entityName", entityName),
				new KeyValuePair<string, object>("id", id));

			Stopwatch watch = new Stopwatch();
			try
			{
				watch.Start();
				this.InternalService.Delete(entityName, id);
				watch.Stop();

				this.AddSuccessReplayEvent(OperationName, watch, inputs);
			}
			catch (Exception ex)
			{
				watch.Stop();

				this.AddExceptionReplayEvent(OperationName, watch, inputs, ex);
				throw;
			}
		}

		public void Associate(string entityName, Guid id, Relationship relationship, EntityReferenceCollection relatedEntities)
		{
			const string OperationName = "Associate";

			IDictionary<string, object> inputs = this.ConvertToInputs(
				new KeyValuePair<string, object>("entityName", entityName),
				new KeyValuePair<string, object>("id", id),
				new KeyValuePair<string, object>("relationship", relationship),
				new KeyValuePair<string, object>("relatedEntities", relatedEntities));

			Stopwatch watch = new Stopwatch();
			try
			{
				watch.Start();
				this.InternalService.Associate(entityName, id, relationship, relatedEntities);
				watch.Stop();

				this.AddSuccessReplayEvent(OperationName, watch, inputs);
			}
			catch (Exception ex)
			{
				watch.Stop();

				this.AddExceptionReplayEvent(OperationName, watch, inputs, ex);
				throw;
			}
		}

		public void Disassociate(string entityName, Guid id, Relationship relationship, EntityReferenceCollection relatedEntities)
		{
			const string OperationName = "Disassociate";

			IDictionary<string, object> inputs = this.ConvertToInputs(
				new KeyValuePair<string, object>("entityName", entityName),
				new KeyValuePair<string, object>("id", id),
				new KeyValuePair<string, object>("relationship", relationship),
				new KeyValuePair<string, object>("relatedEntities", relatedEntities));

			Stopwatch watch = new Stopwatch();
			try
			{
				watch.Start();
				this.InternalService.Disassociate(entityName, id, relationship, relatedEntities);
				watch.Stop();

				this.AddSuccessReplayEvent(OperationName, watch, inputs);
			}
			catch (Exception ex)
			{
				watch.Stop();

				this.AddExceptionReplayEvent(OperationName, watch, inputs, ex);
				throw;
			}
		}

		public OrganizationResponse Execute(OrganizationRequest request)
		{
			if (null == request)
			{
				throw new ArgumentNullException("request");
			}

			const string OperationName = "Execute";

			IDictionary<string, object> inputs = this.ConvertToInputs(
				new KeyValuePair<string, object>("request", request));

			Stopwatch watch = new Stopwatch();
			try
			{
				//The ProxyWrapper doesn't know how to process an OrganizationRequest object. A clone has to be created in order to
				//avoid changing the reference that the plug-in still knows about.
				OrganizationRequest clonedRequest = (OrganizationRequest)Activator.CreateInstance(request.GetType());
				clonedRequest.Parameters = (ParameterCollection)this.Context.ProxyWrapper.ConvertToLateBound(request.Parameters);
				clonedRequest.RequestId = request.RequestId;
				clonedRequest.RequestName = request.RequestName;

				watch.Start();
				OrganizationResponse response = this.InternalService.Execute(clonedRequest);
				watch.Stop();

				//The ProxyWrapper doesn't know how to process an OrganizationResponse object. Since the plug-in does not have
				//any awareness of the response, there is no need to create a clone.
				response.Results = (ParameterCollection)this.Context.ProxyWrapper.ConvertToEarlyBound(response.Results);

				this.AddSuccessReplayEvent(OperationName, watch, inputs, response);
				return response;
			}
			catch (Exception ex)
			{
				watch.Stop();

				this.AddExceptionReplayEvent(OperationName, watch, inputs, ex);
				throw;
			}
		}
		#endregion

		#region Methods
		public override string ToString()
		{
			return this.ServiceLabel;
		}
		#endregion

		#region Private Methods
		private IDictionary<string, object> ConvertToInputs(params KeyValuePair<string, object>[] inputs)
		{
			Dictionary<string, object> processedInputs = new Dictionary<string, object>();
			if (null != inputs && 0 != inputs.Length)
			{
				foreach (KeyValuePair<string, object> pair in inputs)
				{
					processedInputs[pair.Key] = pair.Value;
				}
			}

			return processedInputs;
		}

		private void AddSuccessReplayEvent(string operationName, Stopwatch watch, IDictionary<string, object> inputs)
		{
			this.AddSuccessReplayEvent(operationName, watch, inputs, null);
		}

		private void AddSuccessReplayEvent(string operationName, Stopwatch watch, IDictionary<string, object> inputs, object result)
		{
			this.Context.Report.AddReplayEvent(new OrganizationServiceReplayEvent(operationName, watch.Elapsed, inputs, result));
		}

		private void AddExceptionReplayEvent(string operationName, Stopwatch watch, IDictionary<string, object> inputs, Exception exception)
		{
			FaultException<OrganizationServiceFault> ex = exception as FaultException<OrganizationServiceFault>;
			if (null != ex)
			{
				this.Context.Report.AddReplayEvent(new OrganizationServiceReplayEvent(operationName, watch.Elapsed, inputs, ex.Detail));
				return;
			}

			this.Context.Report.AddReplayEvent(new OrganizationServiceReplayEvent(operationName, watch.Elapsed, inputs,
				new OrganizationServiceFault() { Message = exception.GetType().FullName + ": " + exception.Message }));
		}
		#endregion
	}
}
