﻿using System;
using System.Threading.Tasks;
using Microsoft.Dynamics.ProjectOperations.PluginForge;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;

namespace ProjectOperationsDualWriteIntegrationTests
{
    public class DataverseService
    {
        private readonly string _connectionString;
        private readonly IConnectionSettings settings;

        // Constructor to accept the connection string
        public DataverseService(string connectionString)
        {
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
        }

        public DataverseService(IConnectionSettings settings)
        {
            this.settings = settings;
        }


        private static ServiceClient CreateWithCba(IConnectionSettings settings, bool testUser)
        {

            return new ServiceClient(
                        instanceUrl: new Uri(settings.OrganizationUrl),
                        tokenProviderFunction: ObtainToken);

            Task<string> ObtainToken(string _)
            {
                var redirectUri = "https://localhost";
                var authorityUri = $"https://login.microsoftonline.com/{settings.TenantId}";

                return Task.FromResult(
                                TokenProvider.ObtainNonInteractiveCba(
                                        baseUrl: settings.OrganizationUrl,
                                        username: !testUser ? settings.UserPrincipalName : settings.TestUserPrincipalName,
                                        clientId: "51f81489-12ee-4a9e-aaae-a2591f45987d",
                                        aadAuthority: authorityUri,
                                        certName: !testUser ? settings.SubjectName : settings.TestUserSubjectName,
                                        redirectUri: redirectUri,
                                        tenantId: settings.TenantId));
            }
        }

        // Method to initialize and return IOrganizationService
        public IOrganizationService GetOrganizationService()
        {
            try
            {
                // Create a ServiceClient instance using the connection string
                ServiceClient serviceClient = CreateWithCba(this.settings, false);

                // Check for connection errors
                if (!serviceClient.IsReady)
                {
                    throw new InvalidOperationException($"Unable to connect to Dataverse: {serviceClient.LastError}");
                }

                return serviceClient;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"An error occurred while initializing the IOrganizationService: {ex.Message}", ex);
            }
        }
    }
}
