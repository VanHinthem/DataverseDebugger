﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

using PluginProfiler.Library;

namespace PluginProfiler.Debugger
{
	/// <summary>
	/// Workflow operation type to be handled by the Profiler
	/// </summary>
	internal sealed class WorkflowActivityOperationHandler : OperationHandlerBase
	{
		private const string EntityName = "workflow";

		#region Constructors
		/// <summary>
		/// Instantiate an instance of the WorkflowActivityOperationHandler class
		/// </summary>
		/// <param name="assemblyFilePath">Path to the assembly to be used</param>
		/// <param name="typeName">Name of the type that should be used</param>
		/// <param name="profilePath">Path to the profile</param>
		/// <param name="keyFileName">File name for the key file that will be used for compilation</param>
		/// <param name="persistToEntity">Indicates that the profile should be persisted to an entity</param>
		/// <param name="persistenceSessionKey">Session key to be used when persisting the entity</param>
		/// <param name="excludeSecureInformation">Excludes secure information from the profile.</param>
		/// <param name="workflowId">Id for the workflow</param>
		/// <param name="name">Name of the workflow</param>
		/// <param name="workflowStepIds">Individual steps within the workflow that should be profiled</param>
		internal WorkflowActivityOperationHandler(string assemblyFilePath, string typeName, string profilePath,
			string keyFileName, bool persistToEntity, string persistenceSessionKey,
			bool excludeSecureInformation, Guid workflowId, string name, string[] workflowStepIds)
			: base(assemblyFilePath, typeName, profilePath, persistToEntity, persistenceSessionKey, excludeSecureInformation,
					Guid.Empty == workflowId ? null : new EntityReference(EntityName, workflowId), name)
		{
			this.KeyFileName = keyFileName;
			this.WorkflowStepIds = workflowStepIds;
		}
		#endregion

		#region Methods
		/// <summary>
		/// Retrieves the application configuration
		/// </summary>
		internal override OperationConfiguration GetOperationConfiguration()
		{
			return new WorkflowOperationConfiguration(this.AssemblyFilePath, this.TypeName, this.ProfilePath);
		}

		/// <summary>
		/// Enables profiling on the operation
		/// </summary>
		/// <param name="service">Service that should be used to enable the profiler.</param>
		/// <returns>Id for the profiled version of the operation</returns>
		internal override Guid Enable(IOrganizationService service)
		{
			return ProfilerManagementUtility.EnableWorkflow(service, this.KeyFileName, this.Id.Id, this.PersistToEntity,
				this.PersistenceSessionKey, !this.ExcludeSecureInformation, false, this.WorkflowStepIds);
		}

		/// <summary>
		/// Enables profiling on the operation
		/// </summary>
		/// <param name="service">Service that should be used to disable the profiler.</param>
		internal override void Disable(IOrganizationService service)
		{
			ProfilerManagementUtility.DisableWorkflow(service, this.Id.Id);
		}

		/// <summary>
		/// Lists steps that exist for the current operation
		/// </summary>
		/// <param name="service">Service that should be used to list steps.</param>
		internal override string ListSteps(IOrganizationService service)
		{
			ICollection<CustomActivityStep> steps = ProfilerManagementUtility.GetWorkflowActivitySteps(service, this.Id.Id).Values;

			StringBuilder stepIds = new StringBuilder();
			stepIds.AppendFormat(CultureInfo.InvariantCulture, "Workflow \"{0}\" contains {1} Workflow Activity Step(s):", this.Id, steps.Count);
			stepIds.AppendLine();

			foreach (CustomActivityStep step in steps)
			{
				stepIds.AppendFormat("  Type = {0} (Id = {1}){2}", step.TypeName, step.StepId);
				stepIds.AppendLine();
			}

			return stepIds.ToString();
		}

		/// <summary>
		/// Generates a query for debugger operations based on the operation type
		/// </summary>
		/// <param name="operation">Operation that will be executed by the debugger</param>
		/// <returns>QueryExpression that will retrieve existing operations</returns>
		internal override QueryBase GenerateNameQuery(DebuggerOperation operation)
		{
			QueryByAttribute query = new QueryByAttribute(EntityName);
			query.ColumnSet = new ColumnSet();

			switch (operation)
			{
				case DebuggerOperation.Enable:
					query.AddAttributeValue("name", this.Name);
					break;
				case DebuggerOperation.Disable:

					// All workflows that are profiled will have the profiler suffix added
					query.AddAttributeValue("name", this.Name + ProfilerManagementUtility.ProfiledStepNameSuffix);
					break;
				default:
					throw new NotSupportedException("DebuggerOperation = " + operation);
			}

			return query;
		}

		/// <summary>
		/// Validate the operation's parameters
		/// </summary>
		/// <param name="operation">Operation to be executed</param>
		/// <param name="errors">Errors that should be returned</param>
		/// <returns>True if the validation succeeded</returns>
		internal override bool Validate(DebuggerOperation operation, StringBuilder errors)
		{
			switch (operation)
			{
				case DebuggerOperation.Enable:
				case DebuggerOperation.Disable:
					if (string.IsNullOrWhiteSpace(this.KeyFileName))
					{
						errors.AppendLine("KeyFileName hasn't been specified.");
						return false;
					}

					return true;
				case DebuggerOperation.ListSteps:
					return true;
				default:
					errors.AppendFormat("Workflows don't support {0} operations.{1}", operation, Environment.NewLine);
					return false;
			}
		}
		#endregion

		#region Properties
		private string KeyFileName { get; set; }

		private string[] WorkflowStepIds { get; set; }

		/// <summary>
		/// Plural Name for the record type
		/// </summary>
		internal override string PluralRecordName
		{
			get
			{
				return "workflows";
			}
		}
		#endregion
	}
}
