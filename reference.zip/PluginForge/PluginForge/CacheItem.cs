﻿using System;

namespace Microsoft.Dynamics.ProjectOperations.PluginForge
{
    /// <summary>
    /// Class definition of a cacheable item.
    /// </summary>
    /// <typeparam name="TItem">The type of item.</typeparam>
    internal sealed class CacheItem<TItem>
        where TItem : class
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CacheItem{TItem}"/> class.
        /// </summary>
        /// <param name="item">A cacheable item.</param>
        /// <param name="expiration">Absolute expiration time of <paramref name="item"/>.</param>
        /// <exception cref="ArgumentNullException">Thrown when <paramref name="item"/> is null.</exception>
        public CacheItem(TItem item, DateTimeOffset expiration)
        {
            this.Item = item ?? throw new ArgumentNullException(nameof(item));
            this.Expiration = expiration;
        }

        /// <summary>
        /// Gets the absolute expiration time of <see cref="CacheItem{TItem}.Item"/>.
        /// </summary>
        public DateTimeOffset Expiration { get; }

        /// <summary>
        /// A cacheable item.
        /// </summary>
        public TItem Item { get; }
    }

    /// <summary>
    /// Delegate definition for a method capable of creating a cacheable item from a given key.
    /// </summary>
    /// <typeparam name="TItem">The type of item.</typeparam>
    /// <param name="key">A key value which uniquely describes a cacheable item.</param>
    /// <returns>A new instance of <see cref="CacheItem{TItem}"/>.</returns>
    delegate CacheItem<TItem> CreateCacheItem<TItem>(string key)
        where TItem : class;
}
