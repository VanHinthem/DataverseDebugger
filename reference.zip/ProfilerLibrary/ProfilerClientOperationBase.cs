﻿using System;
using System.Runtime.Serialization;

namespace PluginProfiler.Library.Reporting
{
	/// <summary>
	/// Base Class for Operations that occurred on the client
	/// </summary>
	[DataContract]
	public abstract class ProfilerClientOperationBase
	{
		protected internal ProfilerClientOperationBase(ProfilerOperationType type)
		{
			this.OperationType = type;
		}

		#region Properties
		[DataMember]
		public ProfilerOperationType OperationType { get; private set; }
		#endregion
	}

	#region Enum
	[DataContract]
	public enum ProfilerOperationType
	{
		[EnumMember]
		OrganizationService
	}
	#endregion
}