﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;

using Microsoft.Xrm.Sdk;

using PluginProfiler.Library.Reporting;

namespace PluginProfiler.Library
{
	/// <summary>
	/// AppDomainProxy that is used to replay or debug the plug-in
	/// </summary>
	internal sealed class PluginAppDomainProxy : AppDomainProxy
	{
		/// <summary>
		/// Instantiate an instance of the PluginAppDomainProxy
		/// </summary>
		/// <param name="trustedAssemblies">List of assemblies that are trusted</param>
		private PluginAppDomainProxy(Dictionary<string, string> trustedAssemblies)
			: base(trustedAssemblies)
		{
		}

		#region Protected Methods
		/// <summary>
		/// Configures the proxy with the given configuration
		/// </summary>
		/// <param name="configuration">Configuration that should be used</param>
		protected override void ConfigureProxy(ProfilerExecutionConfiguration configuration)
		{
			PluginOperationConfiguration pluginConfiguration = configuration.OperationConfiguration as PluginOperationConfiguration;
			if (null == pluginConfiguration)
			{
				throw new NotSupportedException(string.Format(CultureInfo.InvariantCulture,
					"Plug-in Configuration is required when configuring a plug-in AppDomainProxy, but \"{0}\" is used instead.",
					configuration.GetType().FullName));
			}

			if (pluginConfiguration.IgnoreProfilerPluginReportConfiguration)
			{
				this.UnsecureConfiguration = pluginConfiguration.UnsecureConfiguration;
				this.SecureConfiguration = pluginConfiguration.SecureConfiguration;
			}
		}

		/// <summary>
		/// Retrieve the configuration that is to be used to instantiate the operation
		/// </summary>
		/// <param name="configuration">Configuration to be used</param>
		/// <param name="parameters">Parameters that should be provided when constructing the object</param>
		/// <returns>Constructor info</returns>
		protected override ConstructorInfo FindConstructor(ProfilerExecutionConfiguration configuration, out object[] parameters)
		{
			ConstructorInfo constructor;
			if ((constructor = this.OperationInstanceType.GetConstructor(new Type[] { typeof(string), typeof(string) })) != null)
			{
				parameters = new object[] { this.UnsecureConfiguration, this.SecureConfiguration };
			}
			else if ((constructor = this.OperationInstanceType.GetConstructor(new Type[] { typeof(string) })) != null)
			{
				parameters = new object[] { this.UnsecureConfiguration };
			}
			else if ((constructor = this.OperationInstanceType.GetConstructor(new Type[0])) != null)
			{
				parameters = new object[0];
			}
			else
			{
				throw new InvalidOperationException("Plug-in does not have a valid constructor.");
			}

			return constructor;
		}

		/// <summary>
		/// Retrieve the configuration that is to be used to instantiate the operation
		/// </summary>
		/// <param name="configuration">Configuration to be used</param>
		/// <param name="context">Context for the oepration</param>
		/// <param name="report">Execution report for the given execution</param>
		/// <returns>Constructor info</returns>
		protected override object PrepareExecution(ProfilerExecutionConfiguration configuration, IExecutionContext context,
			ProfilerExecutionReport report)
		{
			return new ProfilerServiceProvider(context, configuration.GetServices(this, configuration, report, context.UserId));
		}

		/// <summary>
		/// Execute the operation
		/// </summary>
		/// <param name="watch">Watch to be used while counting time</param>
		/// <param name="report">Execution report for the given execution</param>
		/// <param name="instance">Instance of the operation that should be used during execution</param>
		/// <param name="executionParameter">Parameter that should be used during execution</param>
		protected override void ExecuteCore(Stopwatch watch, ProfilerExecutionReport report, object instance, object executionParameter)
		{
			watch.Start();
			((IPlugin)instance).Execute((IServiceProvider)executionParameter);
			watch.Stop();
		}
		#endregion

		#region Properties
		/// <summary>
		/// Unsecure configuration that should be provided to the plug-in
		/// </summary>
		public string UnsecureConfiguration { get; private set; }

		/// <summary>
		/// Secure configuration that should be provided to the plug-in
		/// </summary>
		public string SecureConfiguration { get; private set; }
		#endregion
	}
}