﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.ServiceModel.Description;

using Microsoft.Crm.Sdk.Messages;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System.Diagnostics.CodeAnalysis;
using PluginProfiler.Library.Reporting;
using System.Security;
using System.Security.Permissions;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.Globalization;
using System.ServiceModel;

namespace PluginProfiler.Library
{
	/// <summary>
	/// IOrganizationServiceFactory that connects back to the server for any given user.
	/// </summary>
	internal sealed class ProfilerContextAppDomainOrganizationService : IOrganizationService
	{
		private readonly ProfilerContextOrganizationService InnerService;
		private readonly Assembly ProxyTypesAssembly;
		private readonly Assembly DefaultDomainProxyTypesAssembly;

		/// <summary>
		/// Instantiates an instance of the ProfilerContextOrganizationService class.
		/// </summary>
		public ProfilerContextAppDomainOrganizationService(ProfilerContextOrganizationService service, Assembly proxyTypesAssembly,
			bool includeProxyTypesInDefaultDomain)
		{
			if (null == service)
			{
				throw new ArgumentNullException("service");
			}

			this.InnerService = service;
			this.ProxyTypesAssembly = proxyTypesAssembly;

			if (includeProxyTypesInDefaultDomain)
			{
				this.DefaultDomainProxyTypesAssembly = proxyTypesAssembly;
			}
		}

		#region IOrganizationService Members
		public void Associate(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
		{
			//Assert full trust in order to instantiate the operation
			PermissionSet set = new PermissionSet(PermissionState.Unrestricted);
			set.Assert();

			try
			{
				//Create the operation
				ProfilerAssociateClientOperation operation = new ProfilerAssociateClientOperation(null, entityName, entityId,
					relationship, relatedEntities);

				//Execute the operation
				Tuple<Type, string> result = this.InnerService.Associate(this.SerializeRequest(operation),
					this.DefaultDomainProxyTypesAssembly);

				//Deserialize and process the response
				this.DeserializeResponse(result);
			}
			finally
			{
				CodeAccessPermission.RevertAssert();
			}
		}

		public Guid Create(Entity entity)
		{
			//Assert full trust in order to instantiate the operation
			PermissionSet set = new PermissionSet(PermissionState.Unrestricted);
			set.Assert();

			try
			{
				//Create the operation
				ProfilerCreateClientOperation operation = new ProfilerCreateClientOperation(null, entity, Guid.Empty);

				//Execute the operation
				Tuple<Type, string> result = this.InnerService.Create(this.SerializeRequest(operation), this.DefaultDomainProxyTypesAssembly);

				//Deserialize and process the response
				return (Guid)this.DeserializeResponse(result);
			}
			finally
			{
				CodeAccessPermission.RevertAssert();
			}
		}

		public void Delete(string entityName, Guid id)
		{
			//Assert full trust in order to instantiate the operation
			PermissionSet set = new PermissionSet(PermissionState.Unrestricted);
			set.Assert();

			try
			{
				//Create the operation
				ProfilerDeleteClientOperation operation = new ProfilerDeleteClientOperation(null, entityName, id);

				//Execute the operation
				Tuple<Type, string> result = this.InnerService.Delete(this.SerializeRequest(operation), this.DefaultDomainProxyTypesAssembly);

				//Deserialize and process the response
				this.DeserializeResponse(result);
			}
			finally
			{
				CodeAccessPermission.RevertAssert();
			}
		}

		public void Disassociate(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
		{
			//Assert full trust in order to instantiate the operation
			PermissionSet set = new PermissionSet(PermissionState.Unrestricted);
			set.Assert();

			try
			{
				//Create the operation
				ProfilerDisassociateClientOperation operation = new ProfilerDisassociateClientOperation(null, entityName, entityId,
					relationship, relatedEntities);

				//Execute the operation
				Tuple<Type, string> result = this.InnerService.Disassociate(this.SerializeRequest(operation),
					this.DefaultDomainProxyTypesAssembly);

				//Deserialize and process the response
				this.DeserializeResponse(result);
			}
			finally
			{
				CodeAccessPermission.RevertAssert();
			}
		}

		public OrganizationResponse Execute(OrganizationRequest request)
		{
			//Assert full trust in order to instantiate the operation
			PermissionSet set = new PermissionSet(PermissionState.Unrestricted);
			set.Assert();

			try
			{
				//Create the operation
				ProfilerExecuteClientOperation operation = new ProfilerExecuteClientOperation(null, request, null);

				//Execute the operation
				Tuple<Type, string> result = this.InnerService.Execute(this.SerializeRequest(operation),
					this.DefaultDomainProxyTypesAssembly);

				//Deserialize and process the response
				return (OrganizationResponse)this.DeserializeResponse(result);
			}
			finally
			{
				CodeAccessPermission.RevertAssert();
			}
		}

		public Entity Retrieve(string entityName, Guid id, ColumnSet columnSet)
		{
			//Assert full trust in order to instantiate the operation
			PermissionSet set = new PermissionSet(PermissionState.Unrestricted);
			set.Assert();

			try
			{
				//Create the operation
				ProfilerRetrieveClientOperation operation = new ProfilerRetrieveClientOperation(null, entityName, id, columnSet, null);

				//Execute the operation
				Tuple<Type, string> result = this.InnerService.Retrieve(this.SerializeRequest(operation),
					this.DefaultDomainProxyTypesAssembly);

				//Deserialize and process the response
				return (Entity)this.DeserializeResponse(result);
			}
			finally
			{
				CodeAccessPermission.RevertAssert();
			}
		}

		public EntityCollection RetrieveMultiple(QueryBase query)
		{
			//Assert full trust in order to instantiate the operation
			PermissionSet set = new PermissionSet(PermissionState.Unrestricted);
			set.Assert();

			try
			{
				//Create the operation
				ProfilerRetrieveMultipleClientOperation operation = new ProfilerRetrieveMultipleClientOperation(null, query, null);

				//Execute the operation
				Tuple<Type, string> result = this.InnerService.RetrieveMultiple(this.SerializeRequest(operation),
					this.DefaultDomainProxyTypesAssembly);

				//Deserialize and process the response
				return (EntityCollection)this.DeserializeResponse(result);
			}
			finally
			{
				CodeAccessPermission.RevertAssert();
			}
		}

		public void Update(Entity entity)
		{
			//Assert full trust in order to instantiate the operation
			PermissionSet set = new PermissionSet(PermissionState.Unrestricted);
			set.Assert();

			try
			{
				//Create the operation
				ProfilerUpdateClientOperation operation = new ProfilerUpdateClientOperation(null, entity);

				//Execute the operation
				Tuple<Type, string> result = this.InnerService.Update(this.SerializeRequest(operation),
					this.DefaultDomainProxyTypesAssembly);

				//Deserialize and process the response
				this.DeserializeResponse(result);
			}
			finally
			{
				CodeAccessPermission.RevertAssert();
			}
		}
		#endregion

		#region Private Methods
		private Tuple<Type, string> SerializeRequest<T>(T request)
			where T : ProfilerOrganizationServiceClientOperationBase
		{
			return new Tuple<Type, string>(typeof(T), ProfilerSharedUtility.Serialize(typeof(T), request));
		}

		private object DeserializeResponse(Tuple<Type, string> serializedValue)
		{
			if (null == serializedValue || null == serializedValue.Item2)
			{
				return null;
			}

			//Assert full trust in order to instantiate the operation
			PermissionSet set = new PermissionSet(PermissionState.Unrestricted);
			set.Assert();

			object result = ProfilerSharedUtility.Deserialize(serializedValue.Item1, serializedValue.Item2, this.ProxyTypesAssembly);

			OrganizationServiceFault fault = result as OrganizationServiceFault;
			if (null != fault)
			{
				throw new FaultException<OrganizationServiceFault>(fault, fault.Message);
			}

			return result;
		}
		#endregion
	}
}
