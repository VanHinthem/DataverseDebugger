# PR-A04 – Centralized Runner Start Configuration (Mode + Gate)

## Objective
Centralize Runner configuration so that:
- AllowLiveWrites is passed at process start (env var)
- ExecutionMode is passed explicitly on each request (protocol field)
- Runner is restarted whenever AllowLiveWrites changes
- Requests always carry explicit ExecutionMode (no reliance on legacy fallback)

## Invariants
- No Runner changes.
- No Protocol changes.
- Do not scatter runner config across views.

## Target Files (In-Scope)
- `RunnerProcessManager.cs` (process start env vars)
- `MainWindow.xaml.cs` (restart Runner on AllowLiveWrites change)
- App request construction points (where requests are created/sent), to ensure ExecutionMode is set consistently

## Confirmed Runner Environment Variables (Authoritative)
Set these in `RunnerProcessManager.StartAsync()`:
- `DATAVERSE_DEBUGGER_HOST_PID` (already present today)
- `DATAVERSE_DEBUGGER_ALLOW_LIVE_WRITES` = `true|false`

NOTE:
Runner does not read ExecutionMode from env vars. ExecutionMode is resolved from request payload.

## Required Request Behavior (Authoritative)
For any request type that supports execution mode:
- Always set `ExecutionMode` field to the selected mode (`Offline|Hybrid|Online`)
- Also set legacy `WriteMode` derived per PR-A00 mapping to preserve backward compatibility

Minimum requirement:
- `PluginInvokeRequest.ExecutionMode` must be set (Runner resolves mode from this field first).

## Restart Rules
- Changes to AllowLiveWrites must restart the Runner to ensure `DATAVERSE_DEBUGGER_ALLOW_LIVE_WRITES` takes effect.
- ExecutionMode changes may not require a restart (since it’s per-request), but restarting is acceptable if that is your existing pattern.
  Prefer: restart on ExecutionMode change only if your App currently assumes “single global runner state.”

## Acceptance Criteria (Manual)
- Toggle AllowLiveWrites ON/OFF:
  - Runner restarts
  - subsequent invocations honor gate
- Change ExecutionMode between Offline/Hybrid/Online:
  - subsequent invocations reflect selected mode (validated by behavior and/or runner traces)
- Verify (optional) that Runner process environment contains `DATAVERSE_DEBUGGER_ALLOW_LIVE_WRITES`.
